<?php

return [
    'imagerSystemPath' => '@webroot/cache/images/',
    'imagerUrl' => '@web/cache/images/'
];
