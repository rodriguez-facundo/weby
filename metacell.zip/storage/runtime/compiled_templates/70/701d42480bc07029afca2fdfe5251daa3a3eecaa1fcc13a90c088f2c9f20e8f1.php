<?php

/* _components/fieldtypes/Matrix/input */
class __TwigTemplate_c8c99bd91c56afa55f36e85cfbf95545894b5d7159e13f4b403863c524773d22 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<input type=\"hidden\" name=\"";
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 1, $this->source); })()), "html", null, true);
        echo "\" value=\"\">

<div class=\"matrix matrix-field\" id=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "\">
    <div class=\"blocks\">
        ";
        // line 5
        $context["totalNewBlocks"] = 0;
        // line 6
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["blocks"]) || array_key_exists("blocks", $context) ? $context["blocks"] : (function () { throw new Twig_Error_Runtime('Variable "blocks" does not exist.', 6, $this->source); })()));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["block"]) {
            // line 7
            echo "            ";
            $context["blockId"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "id", []);
            // line 8
            echo "            ";
            if ( !(isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 8, $this->source); })())) {
                // line 9
                echo "                ";
                $context["totalNewBlocks"] = ((isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 9, $this->source); })()) + 1);
                // line 10
                echo "                ";
                $context["blockId"] = ("new" . (isset($context["totalNewBlocks"]) || array_key_exists("totalNewBlocks", $context) ? $context["totalNewBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "totalNewBlocks" does not exist.', 10, $this->source); })()));
                // line 11
                echo "            ";
            }
            // line 12
            echo "
            <div class=\"matrixblock";
            // line 13
            if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "enabled", [])) {
                echo " disabled";
            }
            echo "\" data-id=\"";
            echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 13, $this->source); })()), "html", null, true);
            echo "\"";
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "collapsed", [])) {
                echo " data-collapsed";
            }
            echo " data-type=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "getType", [], "method"), "handle", []), "html", null, true);
            echo "\">
                ";
            // line 14
            if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 14, $this->source); })())) {
                // line 15
                echo "                    <input type=\"hidden\" name=\"";
                echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 15, $this->source); })()), "html", null, true);
                echo "[";
                echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 15, $this->source); })()), "html", null, true);
                echo "][type]\" value=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "getType", [], "method"), "handle", []), "html", null, true);
                echo "\">
                    <input type=\"hidden\" name=\"";
                // line 16
                echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 16, $this->source); })()), "html", null, true);
                echo "[";
                echo twig_escape_filter($this->env, (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 16, $this->source); })()), "html", null, true);
                echo "][enabled]\" value=\"";
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "enabled", [])) {
                    echo "1";
                }
                echo "\">
                    <div class=\"titlebar\">
                        <div class=\"blocktype";
                // line 18
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "hasErrors", [], "method")) {
                    echo " error";
                }
                echo "\">
                            ";
                // line 19
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "getType", [], "method"), "name", []), "site"), "html", null, true);
                echo "
                            ";
                // line 20
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "hasErrors", [], "method")) {
                    echo "<span data-icon=\"alert\"></span>";
                }
                // line 21
                echo "                        </div>
                        <div class=\"preview\"></div>
                    </div>
                    <div class=\"checkbox\" title=\"";
                // line 24
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Select", "app"), "html", null, true);
                echo "\"></div>
                    <div class=\"actions\">
                        <div class=\"status off\" title=\"";
                // line 26
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Disabled", "app"), "html", null, true);
                echo "\"></div>
                        <a class=\"settings icon menubtn\" title=\"";
                // line 27
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Actions", "app"), "html", null, true);
                echo "\" role=\"button\"></a>
                        <div class=\"menu\">
                            <ul class=\"padded\">
                                <li><a data-icon=\"collapse\" data-action=\"collapse\">";
                // line 30
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Collapse", "app"), "html", null, true);
                echo "</a></li>
                                <li class=\"hidden\"><a data-icon=\"expand\" data-action=\"expand\">";
                // line 31
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Expand", "app"), "html", null, true);
                echo "</a></li>
                                <li";
                // line 32
                if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "enabled", [])) {
                    echo " class=\"hidden\"";
                }
                echo "><a data-icon=\"disabled\" data-action=\"disable\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Disable", "app"), "html", null, true);
                echo "</a></li>
                                <li";
                // line 33
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["block"], "enabled", [])) {
                    echo " class=\"hidden\"";
                }
                echo "><a data-icon=\"enabled\" data-action=\"enable\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Enable", "app"), "html", null, true);
                echo "</a></li>
                            </ul>
                            ";
                // line 35
                if ( !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 35, $this->source); })())) {
                    // line 36
                    echo "                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    <li><a class=\"error\" data-icon=\"remove\" data-action=\"delete\">";
                    // line 38
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "</a></li>
                                </ul>
                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    ";
                    // line 42
                    $context['_parent'] = $context;
                    $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypes" does not exist.', 42, $this->source); })()));
                    foreach ($context['_seq'] as $context["_key"] => $context["blockType"]) {
                        // line 43
                        echo "                                        <li><a data-icon=\"plus\" data-action=\"add\" data-type=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["blockType"], "handle", []), "html", null, true);
                        echo "\">";
                        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Add {type} above", "app", ["type" => $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["blockType"], "name", []), "site")]), "html", null, true);
                        echo "</a></li>
                                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blockType'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent) + $_parent;
                    // line 45
                    echo "                                </ul>
                            ";
                }
                // line 47
                echo "                        </div>
                        <a class=\"move icon\" title=\"";
                // line 48
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\" role=\"button\"></a>
                    </div>
                ";
            }
            // line 51
            echo "                <div class=\"fields\">
                    ";
            // line 52
            $this->loadTemplate("_includes/fields", "_components/fieldtypes/Matrix/input", 52)->display(array_merge($context, ["namespace" => (((            // line 53
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 53, $this->source); })()) . "[") . (isset($context["blockId"]) || array_key_exists("blockId", $context) ? $context["blockId"] : (function () { throw new Twig_Error_Runtime('Variable "blockId" does not exist.', 53, $this->source); })())) . "][fields]"), "element" =>             // line 54
$context["block"], "fields" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 55
$context["block"], "getType", [], "method"), "getFieldLayout", [], "method"), "getFields", [], "method"), "static" =>             // line 56
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 56, $this->source); })())]));
            // line 58
            echo "                </div>
            </div>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['block'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "    </div>
    ";
        // line 62
        if (( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 62, $this->source); })()) &&  !(isset($context["staticBlocks"]) || array_key_exists("staticBlocks", $context) ? $context["staticBlocks"] : (function () { throw new Twig_Error_Runtime('Variable "staticBlocks" does not exist.', 62, $this->source); })()))) {
            // line 63
            echo "        <div class=\"buttons\">
            <div class=\"btngroup\">
                ";
            // line 65
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypes" does not exist.', 65, $this->source); })()));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["blockType"]) {
                // line 66
                echo "                    <div class=\"btn";
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "first", [])) {
                    echo " add icon";
                }
                echo "\" data-type=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["blockType"], "handle", []), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["blockType"], "name", []), "site"), "html", null, true);
                echo "</div>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blockType'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 68
            echo "            </div>

            <div class=\"btn add icon menubtn hidden\">";
            // line 70
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Add a block", "app"), "html", null, true);
            echo "</div>
            <div class=\"menu\">
                <ul>
                    ";
            // line 73
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["blockTypes"]) || array_key_exists("blockTypes", $context) ? $context["blockTypes"] : (function () { throw new Twig_Error_Runtime('Variable "blockTypes" does not exist.', 73, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["blockType"]) {
                // line 74
                echo "                        <li><a data-type=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["blockType"], "handle", []), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["blockType"], "name", []), "site"), "html", null, true);
                echo "</a></li>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['blockType'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 76
            echo "                </ul>
            </div>
        </div>
    ";
        }
        // line 80
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "_components/fieldtypes/Matrix/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  313 => 80,  307 => 76,  296 => 74,  292 => 73,  286 => 70,  282 => 68,  259 => 66,  242 => 65,  238 => 63,  236 => 62,  233 => 61,  217 => 58,  215 => 56,  214 => 55,  213 => 54,  212 => 53,  211 => 52,  208 => 51,  202 => 48,  199 => 47,  195 => 45,  184 => 43,  180 => 42,  173 => 38,  169 => 36,  167 => 35,  158 => 33,  150 => 32,  146 => 31,  142 => 30,  136 => 27,  132 => 26,  127 => 24,  122 => 21,  118 => 20,  114 => 19,  108 => 18,  97 => 16,  88 => 15,  86 => 14,  72 => 13,  69 => 12,  66 => 11,  63 => 10,  60 => 9,  57 => 8,  54 => 7,  36 => 6,  34 => 5,  29 => 3,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<input type=\"hidden\" name=\"{{ name }}\" value=\"\">

<div class=\"matrix matrix-field\" id=\"{{ id }}\">
    <div class=\"blocks\">
        {% set totalNewBlocks = 0 %}
        {% for block in blocks %}
            {% set blockId = block.id %}
            {% if not blockId %}
                {% set totalNewBlocks = totalNewBlocks + 1 %}
                {% set blockId = 'new'~totalNewBlocks %}
            {% endif %}

            <div class=\"matrixblock{% if not block.enabled %} disabled{% endif %}\" data-id=\"{{ blockId }}\"{% if block.collapsed %} data-collapsed{% endif %} data-type=\"{{ block.getType().handle }}\">
                {% if not static %}
                    <input type=\"hidden\" name=\"{{ name }}[{{ blockId }}][type]\" value=\"{{ block.getType().handle }}\">
                    <input type=\"hidden\" name=\"{{ name }}[{{ blockId }}][enabled]\" value=\"{% if block.enabled %}1{% endif %}\">
                    <div class=\"titlebar\">
                        <div class=\"blocktype{% if block.hasErrors() %} error{% endif %}\">
                            {{ block.getType().name|t('site') }}
                            {% if block.hasErrors() %}<span data-icon=\"alert\"></span>{% endif %}
                        </div>
                        <div class=\"preview\"></div>
                    </div>
                    <div class=\"checkbox\" title=\"{{ 'Select'|t('app') }}\"></div>
                    <div class=\"actions\">
                        <div class=\"status off\" title=\"{{ 'Disabled'|t('app') }}\"></div>
                        <a class=\"settings icon menubtn\" title=\"{{ 'Actions'|t('app') }}\" role=\"button\"></a>
                        <div class=\"menu\">
                            <ul class=\"padded\">
                                <li><a data-icon=\"collapse\" data-action=\"collapse\">{{ \"Collapse\"|t('app') }}</a></li>
                                <li class=\"hidden\"><a data-icon=\"expand\" data-action=\"expand\">{{ \"Expand\"|t('app') }}</a></li>
                                <li{% if not block.enabled %} class=\"hidden\"{% endif %}><a data-icon=\"disabled\" data-action=\"disable\">{{ \"Disable\"|t('app') }}</a></li>
                                <li{% if block.enabled %} class=\"hidden\"{% endif %}><a data-icon=\"enabled\" data-action=\"enable\">{{ \"Enable\"|t('app') }}</a></li>
                            </ul>
                            {% if not staticBlocks %}
                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    <li><a class=\"error\" data-icon=\"remove\" data-action=\"delete\">{{ \"Delete\"|t('app') }}</a></li>
                                </ul>
                                <hr class=\"padded\">
                                <ul class=\"padded\">
                                    {% for blockType in blockTypes %}
                                        <li><a data-icon=\"plus\" data-action=\"add\" data-type=\"{{ blockType.handle }}\">{{ \"Add {type} above\"|t('app', { type: blockType.name|t('site') }) }}</a></li>
                                    {% endfor %}
                                </ul>
                            {% endif %}
                        </div>
                        <a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\" role=\"button\"></a>
                    </div>
                {% endif %}
                <div class=\"fields\">
                    {% include \"_includes/fields\" with {
                        namespace: name~'['~blockId~'][fields]',
                        element: block,
                        fields: block.getType().getFieldLayout().getFields(),
                        static: static
                    } %}
                </div>
            </div>
        {% endfor %}
    </div>
    {% if not static and not staticBlocks %}
        <div class=\"buttons\">
            <div class=\"btngroup\">
                {% for blockType in blockTypes %}
                    <div class=\"btn{% if loop.first %} add icon{% endif %}\" data-type=\"{{ blockType.handle }}\">{{ blockType.name|t('site') }}</div>
                {% endfor %}
            </div>

            <div class=\"btn add icon menubtn hidden\">{{ \"Add a block\"|t('app') }}</div>
            <div class=\"menu\">
                <ul>
                    {% for blockType in blockTypes %}
                        <li><a data-type=\"{{ blockType.handle }}\">{{ blockType.name|t('site') }}</a></li>
                    {% endfor %}
                </ul>
            </div>
        </div>
    {% endif %}
</div>
", "_components/fieldtypes/Matrix/input", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\_components\\fieldtypes\\Matrix\\input.html");
    }
}
