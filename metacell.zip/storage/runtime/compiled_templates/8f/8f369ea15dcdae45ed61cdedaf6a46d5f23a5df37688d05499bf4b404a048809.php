<?php

/* __string_template__1cfab861b8edc77725101b67f0bab1d4452fbba7d7e80cf527a25094267d6d2a */
class __TwigTemplate_9114d97837045c42b17a31a61db17ff8ff180a02ccb2b84650028b4446f2ca2f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "resource-type/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "slug", [])));
    }

    public function getTemplateName()
    {
        return "__string_template__1cfab861b8edc77725101b67f0bab1d4452fbba7d7e80cf527a25094267d6d2a";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("resource-type/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__1cfab861b8edc77725101b67f0bab1d4452fbba7d7e80cf527a25094267d6d2a", "");
    }
}
