<?php

/* _includes/forms */
class __TwigTemplate_ed3cff8e7e4d92d06391f7fef894840eeb8873ae73e5aa03123708a315f089b2 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 4
        echo "

";
        // line 7
        echo "

";
        // line 12
        echo "

";
        // line 17
        echo "

";
        // line 22
        echo "

";
        // line 27
        echo "

";
        // line 32
        echo "

";
        // line 37
        echo "

";
        // line 42
        echo "

";
        // line 47
        echo "

";
        // line 52
        echo "

";
        // line 57
        echo "

";
        // line 62
        echo "

";
        // line 67
        echo "

";
        // line 72
        echo "

";
        // line 77
        echo "

";
        // line 82
        echo "

";
        // line 87
        echo "

";
        // line 92
        echo "

";
        // line 97
        echo "

";
        // line 102
        echo "

";
        // line 105
        echo "

";
        // line 110
        echo "

";
        // line 126
        echo "

";
        // line 132
        echo "

";
        // line 138
        echo "

";
        // line 144
        echo "

";
        // line 150
        echo "

";
        // line 162
        echo "

";
        // line 168
        echo "

";
        // line 174
        echo "

";
        // line 180
        echo "

";
        // line 200
        echo "

";
        // line 206
        echo "

";
        // line 212
        echo "

";
        // line 218
        echo "

";
        // line 224
        echo "

";
        // line 234
        echo "

";
        // line 241
        echo "

";
        // line 247
        echo "

";
        // line 271
        echo "

";
        // line 274
        echo "

";
    }

    // line 1
    public function macro_errorList($__errors__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "errors" => $__errors__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 2
            echo "    ";
            $this->loadTemplate("_includes/forms/errorList", "_includes/forms", 2)->display($context);

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 9
    public function macro_hidden($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 10
            $this->loadTemplate("_includes/forms/hidden", "_includes/forms", 10)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 10, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 14
    public function macro_text($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 15
            echo "    ";
            $this->loadTemplate("_includes/forms/text", "_includes/forms", 15)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 15, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 19
    public function macro_password($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 20
            echo "    ";
            $this->loadTemplate("_includes/forms/text", "_includes/forms", 20)->display(twig_array_merge((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 20, $this->source); })()), ["type" => "password"]));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 24
    public function macro_date($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 25
            echo "    ";
            $this->loadTemplate("_includes/forms/date", "_includes/forms", 25)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 25, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 29
    public function macro_time($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 30
            echo "    ";
            $this->loadTemplate("_includes/forms/time", "_includes/forms", 30)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 30, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 34
    public function macro_color($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 35
            echo "    ";
            $this->loadTemplate("_includes/forms/color", "_includes/forms", 35)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 35, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 39
    public function macro_textarea($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 40
            echo "    ";
            $this->loadTemplate("_includes/forms/textarea", "_includes/forms", 40)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 40, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 44
    public function macro_select($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 45
            echo "    ";
            $this->loadTemplate("_includes/forms/select", "_includes/forms", 45)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 45, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 49
    public function macro_multiselect($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 50
            echo "    ";
            $this->loadTemplate("_includes/forms/multiselect", "_includes/forms", 50)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 50, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 54
    public function macro_checkbox($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 55
            echo "    ";
            $this->loadTemplate("_includes/forms/checkbox", "_includes/forms", 55)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 55, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 59
    public function macro_checkboxGroup($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 60
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxGroup", "_includes/forms", 60)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 60, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 64
    public function macro_checkboxSelect($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 65
            echo "    ";
            $this->loadTemplate("_includes/forms/checkboxSelect", "_includes/forms", 65)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 65, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 69
    public function macro_radio($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 70
            echo "    ";
            $this->loadTemplate("_includes/forms/radio", "_includes/forms", 70)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 70, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 74
    public function macro_radioGroup($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 75
            echo "    ";
            $this->loadTemplate("_includes/forms/radioGroup", "_includes/forms", 75)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 75, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 79
    public function macro_file($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 80
            echo "    ";
            $this->loadTemplate("_includes/forms/file", "_includes/forms", 80)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 80, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 84
    public function macro_lightswitch($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 85
            echo "    ";
            $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms", 85)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 85, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 89
    public function macro_editableTable($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 90
            echo "    ";
            $this->loadTemplate("_includes/forms/editableTable", "_includes/forms", 90)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 90, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 94
    public function macro_elementSelect($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 95
            echo "    ";
            $this->loadTemplate("_includes/forms/elementSelect", "_includes/forms", 95)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 95, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 99
    public function macro_autosuggest($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 100
            echo "    ";
            $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms", 100)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 100, $this->source); })()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 107
    public function macro_field($__config__ = null, $__input__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "input" => $__input__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 108
            echo "    ";
            $this->loadTemplate("_includes/forms/field", "_includes/forms", 108)->display(twig_array_merge((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 108, $this->source); })()), ["input" => (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new Twig_Error_Runtime('Variable "input" does not exist.', 108, $this->source); })())]));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 112
    public function macro_textField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 113
            echo "    ";
            $context["forms"] = $this;
            // line 114
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "unit", [], "any", true, true)) {
                // line 115
                echo "        ";
                ob_start();
                // line 116
                echo "            <div class=\"flex\">
                <div class=\"textwrapper\">";
                // line 117
                echo $context["forms"]->macro_text((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 117, $this->source); })()));
                echo "</div>
                <div class=\"label light\">";
                // line 118
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 118, $this->source); })()), "unit", []), "html", null, true);
                echo "</div>
            </div>
        ";
                $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
                // line 121
                echo "    ";
            } else {
                // line 122
                echo "        ";
                $context["input"] = $context["forms"]->macro_text((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 122, $this->source); })()));
                // line 123
                echo "    ";
            }
            // line 124
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 124, $this->source); })()), (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new Twig_Error_Runtime('Variable "input" does not exist.', 124, $this->source); })()));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 128
    public function macro_passwordField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 129
            echo "    ";
            $context["forms"] = $this;
            // line 130
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 130, $this->source); })()), $context["forms"]->macro_password((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 130, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 134
    public function macro_dateField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 135
            echo "    ";
            $context["forms"] = $this;
            // line 136
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 136, $this->source); })()), $context["forms"]->macro_date((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 136, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 140
    public function macro_timeField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 141
            echo "    ";
            $context["forms"] = $this;
            // line 142
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 142, $this->source); })()), $context["forms"]->macro_time((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 142, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 146
    public function macro_colorField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 147
            echo "    ";
            $context["forms"] = $this;
            // line 148
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 148, $this->source); })()), $context["forms"]->macro_color((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 148, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 152
    public function macro_dateTimeField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 153
            echo "    ";
            $context["forms"] = $this;
            // line 154
            echo "    ";
            ob_start();
            // line 155
            echo "        <div class=\"datetimewrapper\">
            ";
            // line 156
            echo $context["forms"]->macro_date((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 156, $this->source); })()));
            echo "
            ";
            // line 157
            echo $context["forms"]->macro_time((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 157, $this->source); })()));
            echo "
        </div>
    ";
            $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
            // line 160
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 160, $this->source); })()), (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new Twig_Error_Runtime('Variable "input" does not exist.', 160, $this->source); })()));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 164
    public function macro_textareaField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 165
            echo "    ";
            $context["forms"] = $this;
            // line 166
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 166, $this->source); })()), $context["forms"]->macro_textarea((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 166, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 170
    public function macro_selectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 171
            echo "    ";
            $context["forms"] = $this;
            // line 172
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 172, $this->source); })()), $context["forms"]->macro_select((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 172, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 176
    public function macro_multiselectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 177
            echo "    ";
            $context["forms"] = $this;
            // line 178
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 178, $this->source); })()), $context["forms"]->macro_multiselect((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 178, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 182
    public function macro_checkboxField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 183
            echo "    ";
            $context["forms"] = $this;
            // line 184
            echo "    ";
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldLabel", [], "any", true, true)) {
                // line 185
                echo "        ";
                echo $context["forms"]->macro_field(twig_array_merge((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 185, $this->source); })()), ["label" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 185, $this->source); })()), "fieldLabel", [])]), $context["forms"]->macro_checkbox((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 185, $this->source); })())));
                echo "
    ";
            } else {
                // line 187
                echo "        ";
                $context["instructions"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "instructions", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "instructions", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "instructions", [])) : (null));
                // line 188
                $context["warning"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "warning", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "warning", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "warning", [])) : (null));
                // line 189
                echo "<div class=\"field checkboxfield";
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "first", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 189, $this->source); })()), "first", []))) {
                    echo " first";
                }
                if ((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new Twig_Error_Runtime('Variable "instructions" does not exist.', 189, $this->source); })())) {
                    echo " has-instructions";
                }
                echo "\"";
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "id", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 189, $this->source); })()), "id", []))) {
                    echo " id=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 189, $this->source); })()), "id", []), "html", null, true);
                    echo "-field\"";
                }
                echo ">
            ";
                // line 190
                echo $context["forms"]->macro_checkbox((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 190, $this->source); })()));
                echo "
            ";
                // line 191
                if ((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new Twig_Error_Runtime('Variable "instructions" does not exist.', 191, $this->source); })())) {
                    // line 192
                    echo "                <div class=\"instructions\">";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->markdownFilter((isset($context["instructions"]) || array_key_exists("instructions", $context) ? $context["instructions"] : (function () { throw new Twig_Error_Runtime('Variable "instructions" does not exist.', 192, $this->source); })())), "html", null, true);
                    echo "</div>
            ";
                }
                // line 194
                echo "            ";
                if ((isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new Twig_Error_Runtime('Variable "warning" does not exist.', 194, $this->source); })())) {
                    // line 195
                    echo "                <p class=\"warning\">";
                    echo twig_escape_filter($this->env, (isset($context["warning"]) || array_key_exists("warning", $context) ? $context["warning"] : (function () { throw new Twig_Error_Runtime('Variable "warning" does not exist.', 195, $this->source); })()), "html", null, true);
                    echo "</p>
            ";
                }
                // line 197
                echo "        </div>
    ";
            }

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 202
    public function macro_checkboxGroupField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 203
            echo "    ";
            $context["forms"] = $this;
            // line 204
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 204, $this->source); })()), $context["forms"]->macro_checkboxGroup((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 204, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 208
    public function macro_checkboxSelectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 209
            echo "    ";
            $context["forms"] = $this;
            // line 210
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 210, $this->source); })()), $context["forms"]->macro_checkboxSelect((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 210, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 214
    public function macro_radioGroupField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 215
            echo "    ";
            $context["forms"] = $this;
            // line 216
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 216, $this->source); })()), $context["forms"]->macro_radioGroup((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 216, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 220
    public function macro_fileField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 221
            echo "    ";
            $context["forms"] = $this;
            // line 222
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 222, $this->source); })()), $context["forms"]->macro_file((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 222, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 226
    public function macro_lightswitchField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 227
            echo "    ";
            $context["forms"] = $this;
            // line 228
            echo "    ";
            if (( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "labelId", [], "any", true, true) ||  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 228, $this->source); })()), "labelId", []))) {
                // line 229
                echo "        ";
                $context["config"] = twig_array_merge((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 229, $this->source); })()), ["labelId" => ("label" . twig_random($this->env))]);
                // line 230
                echo "    ";
            }
            // line 231
            echo "    ";
            $context["config"] = twig_array_merge((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 231, $this->source); })()), ["fieldClass" => ("lightswitch-field " . (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldClass", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldClass", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "fieldClass", [])) : ("")))]);
            // line 232
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 232, $this->source); })()), $context["forms"]->macro_lightswitch((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 232, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 236
    public function macro_editableTableField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 237
            echo "    ";
            $context["forms"] = $this;
            // line 238
            echo "    ";
            ob_start();
            $this->loadTemplate("_includes/forms/editableTable", "_includes/forms", 238)->display((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 238, $this->source); })()));
            $context["input"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
            // line 239
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 239, $this->source); })()), (isset($context["input"]) || array_key_exists("input", $context) ? $context["input"] : (function () { throw new Twig_Error_Runtime('Variable "input" does not exist.', 239, $this->source); })()));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 243
    public function macro_elementSelectField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 244
            echo "    ";
            $context["forms"] = $this;
            // line 245
            echo "    ";
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 245, $this->source); })()), $context["forms"]->macro_elementSelect((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 245, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 249
    public function macro_autosuggestField($__config__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "config" => $__config__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 250
            echo "    ";
            $context["forms"] = $this;
            // line 251
            echo "
    ";
            // line 253
            echo "    ";
            if ((((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "suggestEnvVars", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "suggestEnvVars", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "suggestEnvVars", [])) : (false))) {
                // line 254
                echo "        ";
                $context["value"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "value", [])) : (""));
                // line 255
                echo "        ";
                if (( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "tip", [], "any", true, true) && !twig_in_filter(twig_slice($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 255, $this->source); })()), 0, 1), [0 => "\$", 1 => "@"]))) {
                    // line 256
                    echo "            ";
                    $context["config"] = twig_array_merge((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 256, $this->source); })()), ["tip" => ((((((((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 257
($context["config"] ?? null), "suggestAliases", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "suggestAliases", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "suggestAliases", [])) : (false))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable, or begin with an alias.", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("This can be set to an environment variable.", "app"))) . " <a href=\"https://docs.craftcms.com/v3/config/environments.html\" class=\"go\">") . $this->extensions['craft\web\twig\Extension']->translateFilter("Learn more", "app")) . "</a>")]);
                    // line 262
                    echo "        ";
                } elseif (( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["config"] ?? null), "warning", [], "any", true, true) && (((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 262, $this->source); })()) == "@web") || (twig_slice($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 262, $this->source); })()), 0, 5) == "@web/")))) {
                    // line 263
                    echo "            ";
                    $context["config"] = twig_array_merge((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 263, $this->source); })()), ["warning" => $this->extensions['craft\web\twig\Extension']->translateFilter("The `@web` alias is not recommended.", "app")]);
                    // line 266
                    echo "        ";
                }
                // line 267
                echo "    ";
            }
            // line 268
            echo "
    ";
            // line 269
            echo $context["forms"]->macro_field((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 269, $this->source); })()), $context["forms"]->macro_autosuggest((isset($context["config"]) || array_key_exists("config", $context) ? $context["config"] : (function () { throw new Twig_Error_Runtime('Variable "config" does not exist.', 269, $this->source); })())));
            echo "
";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 276
    public function macro_optionShortcutLabel($__key__ = null, $__shift__ = null, $__alt__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "key" => $__key__,
            "shift" => $__shift__,
            "alt" => $__alt__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 277
            ob_start();
            // line 278
            echo "        ";
            switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 278, $this->source); })()), "app", []), "request", []), "getClientOs", [], "method")) {
                case "Mac":
                {
                    // line 280
                    echo "                <span class=\"shortcut\">";
                    echo twig_escape_filter($this->env, ((((((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new Twig_Error_Runtime('Variable "alt" does not exist.', 280, $this->source); })())) ? ("⌥") : ("")) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new Twig_Error_Runtime('Variable "shift" does not exist.', 280, $this->source); })())) ? ("⇧") : (""))) . "⌘") . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new Twig_Error_Runtime('Variable "key" does not exist.', 280, $this->source); })())), "html", null, true);
                    echo "</span>
            ";
                    break;
                }
                default:
                {
                    // line 282
                    echo "                <span class=\"shortcut\">";
                    echo twig_escape_filter($this->env, ((("Ctrl+" . (((isset($context["alt"]) || array_key_exists("alt", $context) ? $context["alt"] : (function () { throw new Twig_Error_Runtime('Variable "alt" does not exist.', 282, $this->source); })())) ? ("Alt+") : (""))) . (((isset($context["shift"]) || array_key_exists("shift", $context) ? $context["shift"] : (function () { throw new Twig_Error_Runtime('Variable "shift" does not exist.', 282, $this->source); })())) ? ("Shift+") : (""))) . (isset($context["key"]) || array_key_exists("key", $context) ? $context["key"] : (function () { throw new Twig_Error_Runtime('Variable "key" does not exist.', 282, $this->source); })())), "html", null, true);
                    echo "</span>
        ";
                }
            }
            // line 284
            echo "    ";
            echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1319 => 284,  1312 => 282,  1303 => 280,  1298 => 278,  1296 => 277,  1282 => 276,  1271 => 269,  1268 => 268,  1265 => 267,  1262 => 266,  1259 => 263,  1256 => 262,  1254 => 257,  1252 => 256,  1249 => 255,  1246 => 254,  1243 => 253,  1240 => 251,  1237 => 250,  1225 => 249,  1213 => 245,  1210 => 244,  1198 => 243,  1186 => 239,  1181 => 238,  1178 => 237,  1166 => 236,  1154 => 232,  1151 => 231,  1148 => 230,  1145 => 229,  1142 => 228,  1139 => 227,  1127 => 226,  1115 => 222,  1112 => 221,  1100 => 220,  1088 => 216,  1085 => 215,  1073 => 214,  1061 => 210,  1058 => 209,  1046 => 208,  1034 => 204,  1031 => 203,  1019 => 202,  1008 => 197,  1002 => 195,  999 => 194,  993 => 192,  991 => 191,  987 => 190,  971 => 189,  969 => 188,  966 => 187,  960 => 185,  957 => 184,  954 => 183,  942 => 182,  930 => 178,  927 => 177,  915 => 176,  903 => 172,  900 => 171,  888 => 170,  876 => 166,  873 => 165,  861 => 164,  849 => 160,  843 => 157,  839 => 156,  836 => 155,  833 => 154,  830 => 153,  818 => 152,  806 => 148,  803 => 147,  791 => 146,  779 => 142,  776 => 141,  764 => 140,  752 => 136,  749 => 135,  737 => 134,  725 => 130,  722 => 129,  710 => 128,  698 => 124,  695 => 123,  692 => 122,  689 => 121,  683 => 118,  679 => 117,  676 => 116,  673 => 115,  670 => 114,  667 => 113,  655 => 112,  645 => 108,  632 => 107,  622 => 100,  610 => 99,  600 => 95,  588 => 94,  578 => 90,  566 => 89,  556 => 85,  544 => 84,  534 => 80,  522 => 79,  512 => 75,  500 => 74,  490 => 70,  478 => 69,  468 => 65,  456 => 64,  446 => 60,  434 => 59,  424 => 55,  412 => 54,  402 => 50,  390 => 49,  380 => 45,  368 => 44,  358 => 40,  346 => 39,  336 => 35,  324 => 34,  314 => 30,  302 => 29,  292 => 25,  280 => 24,  270 => 20,  258 => 19,  248 => 15,  236 => 14,  227 => 10,  215 => 9,  205 => 2,  193 => 1,  187 => 274,  183 => 271,  179 => 247,  175 => 241,  171 => 234,  167 => 224,  163 => 218,  159 => 212,  155 => 206,  151 => 200,  147 => 180,  143 => 174,  139 => 168,  135 => 162,  131 => 150,  127 => 144,  123 => 138,  119 => 132,  115 => 126,  111 => 110,  107 => 105,  103 => 102,  99 => 97,  95 => 92,  91 => 87,  87 => 82,  83 => 77,  79 => 72,  75 => 67,  71 => 62,  67 => 57,  63 => 52,  59 => 47,  55 => 42,  51 => 37,  47 => 32,  43 => 27,  39 => 22,  35 => 17,  31 => 12,  27 => 7,  23 => 4,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro errorList(errors) %}
    {% include \"_includes/forms/errorList\" %}
{% endmacro %}


{# Inputs #}


{% macro hidden(config) -%}
    {% include \"_includes/forms/hidden\" with config only %}
{%- endmacro %}


{% macro text(config) %}
    {% include \"_includes/forms/text\" with config only %}
{% endmacro %}


{% macro password(config) %}
    {% include \"_includes/forms/text\" with config|merge({ type: 'password' }) only %}
{% endmacro %}


{% macro date(config) %}
    {% include \"_includes/forms/date\" with config only %}
{% endmacro %}


{% macro time(config) %}
    {% include \"_includes/forms/time\" with config only %}
{% endmacro %}


{% macro color(config) %}
    {% include \"_includes/forms/color\" with config only %}
{% endmacro %}


{% macro textarea(config) %}
    {% include \"_includes/forms/textarea\" with config only %}
{% endmacro %}


{% macro select(config) %}
    {% include \"_includes/forms/select\" with config only %}
{% endmacro %}


{% macro multiselect(config) %}
    {% include \"_includes/forms/multiselect\" with config only %}
{% endmacro %}


{% macro checkbox(config) %}
    {% include \"_includes/forms/checkbox\" with config only %}
{% endmacro %}


{% macro checkboxGroup(config) %}
    {% include \"_includes/forms/checkboxGroup\" with config only %}
{% endmacro %}


{% macro checkboxSelect(config) %}
    {% include \"_includes/forms/checkboxSelect\" with config only %}
{% endmacro %}


{% macro radio(config) %}
    {% include \"_includes/forms/radio\" with config only %}
{% endmacro %}


{% macro radioGroup(config) %}
    {% include \"_includes/forms/radioGroup\" with config only %}
{% endmacro %}


{% macro file(config) %}
    {% include \"_includes/forms/file\" with config only %}
{% endmacro %}


{% macro lightswitch(config) %}
    {% include \"_includes/forms/lightswitch\" with config only %}
{% endmacro %}


{% macro editableTable(config) %}
    {% include \"_includes/forms/editableTable\" with config only %}
{% endmacro %}


{% macro elementSelect(config) %}
    {% include \"_includes/forms/elementSelect\" with config only %}
{% endmacro %}


{% macro autosuggest(config) %}
    {% include \"_includes/forms/autosuggest\" with config only %}
{% endmacro %}


{# Fields #}


{% macro field(config, input) %}
    {% include \"_includes/forms/field\" with config|merge({ input: input }) only %}
{% endmacro %}


{% macro textField(config) %}
    {% import _self as forms %}
    {% if config.unit is defined %}
        {% set input %}
            <div class=\"flex\">
                <div class=\"textwrapper\">{{ forms.text(config) }}</div>
                <div class=\"label light\">{{ config.unit }}</div>
            </div>
        {% endset %}
    {% else %}
        {% set input = forms.text(config) %}
    {% endif %}
    {{ forms.field(config, input) }}
{% endmacro %}


{% macro passwordField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.password(config)) }}
{% endmacro %}


{% macro dateField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.date(config)) }}
{% endmacro %}


{% macro timeField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.time(config)) }}
{% endmacro %}


{% macro colorField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.color(config)) }}
{% endmacro %}


{% macro dateTimeField(config) %}
    {% import _self as forms %}
    {% set input %}
        <div class=\"datetimewrapper\">
            {{ forms.date(config) }}
            {{ forms.time(config) }}
        </div>
    {% endset %}
    {{ forms.field(config, input) }}
{% endmacro %}


{% macro textareaField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.textarea(config)) }}
{% endmacro %}


{% macro selectField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.select(config)) }}
{% endmacro %}


{% macro multiselectField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.multiselect(config)) }}
{% endmacro %}


{% macro checkboxField(config) %}
    {% import _self as forms %}
    {% if config.fieldLabel is defined %}
        {{ forms.field(config|merge({label: config.fieldLabel}), forms.checkbox(config)) }}
    {% else %}
        {% set instructions = config.instructions ?? null -%}
        {% set warning = config.warning ?? null -%}
        <div class=\"field checkboxfield{% if config.first is defined and config.first %} first{% endif %}{% if instructions %} has-instructions{% endif %}\"{% if config.id is defined and config.id %} id=\"{{ config.id }}-field\"{% endif %}>
            {{ forms.checkbox(config) }}
            {% if instructions %}
                <div class=\"instructions\">{{ instructions|md }}</div>
            {% endif %}
            {% if warning %}
                <p class=\"warning\">{{ warning }}</p>
            {% endif %}
        </div>
    {% endif %}
{% endmacro %}


{% macro checkboxGroupField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.checkboxGroup(config)) }}
{% endmacro %}


{% macro checkboxSelectField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.checkboxSelect(config)) }}
{% endmacro %}


{% macro radioGroupField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.radioGroup(config)) }}
{% endmacro %}


{% macro fileField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.file(config)) }}
{% endmacro %}


{% macro lightswitchField(config) %}
    {% import _self as forms %}
    {% if config.labelId is not defined or not config.labelId %}
        {% set config = config|merge({ labelId: 'label'~random() }) %}
    {% endif %}
    {% set config = config|merge({ fieldClass: 'lightswitch-field ' ~ (config.fieldClass ?? '') }) %}
    {{ forms.field(config, forms.lightswitch(config)) }}
{% endmacro %}


{% macro editableTableField(config) %}
    {% import _self as forms %}
    {% set input %}{% include \"_includes/forms/editableTable\" with config only %}{% endset %}
    {{ forms.field(config, input) }}
{% endmacro %}


{% macro elementSelectField(config) %}
    {% import _self as forms %}
    {{ forms.field(config, forms.elementSelect(config)) }}
{% endmacro %}


{% macro autosuggestField(config) %}
    {% import _self as forms %}

    {# Suggest an environment variable / alias? #}
    {% if (config.suggestEnvVars ?? false) %}
        {% set value = config.value ?? '' %}
        {% if config.tip is not defined and value[0:1] not in ['\$', '@'] %}
            {% set config = config|merge({
                tip: ((config.suggestAliases ?? false)
                    ? 'This can be set to an environment variable, or begin with an alias.'|t('app')
                    : 'This can be set to an environment variable.'|t('app'))
                    ~ ' <a href=\"https://docs.craftcms.com/v3/config/environments.html\" class=\"go\">' ~ 'Learn more'|t('app') ~ '</a>'
            }) %}
        {% elseif config.warning is not defined and (value == '@web' or value[0:5] == '@web/') %}
            {% set config = config|merge({
                warning: 'The `@web` alias is not recommended.'|t('app')
            }) %}
        {% endif %}
    {% endif %}

    {{ forms.field(config, forms.autosuggest(config)) }}
{% endmacro %}


{# Other #}


{% macro optionShortcutLabel(key, shift, alt) %}
    {%- spaceless %}
        {% switch craft.app.request.getClientOs() %}
            {% case 'Mac' %}
                <span class=\"shortcut\">{{ (alt ? '⌥') ~ (shift ? '⇧') ~ '⌘' ~ key }}</span>
            {% default %}
                <span class=\"shortcut\">{{ 'Ctrl+' ~ (alt ? 'Alt+') ~ (shift ? 'Shift+') ~ key }}</span>
        {% endswitch %}
    {% endspaceless -%}
{% endmacro %}
", "_includes/forms", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\_includes\\forms.html");
    }
}
