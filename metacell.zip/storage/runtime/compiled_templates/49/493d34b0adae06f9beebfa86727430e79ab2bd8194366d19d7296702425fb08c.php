<?php

/* _components/portfolio/default.twig */
class __TwigTemplate_03765cd7f82e27b263e3472f01b83f85208f1c4630a4f975317d84956196389a extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/portfolio/default.twig", 1);
        // line 2
        echo "<div class=\"container list-content\">
    <h6>
        ";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 4, $this->source); })()), "heading", []), "html", null, true);
        echo "
    </h6>
    ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 6, $this->source); })()), "items", []), "all", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 7
            echo "        <div class=\"portfolio-item\">
            ";
            // line 8
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index", []) % 2 == 1)) {
                // line 9
                echo "                <div class=\"row image-right\">
                    <div class=\"col-6\">
                        <div class=\"content\">
                            <h2>
                                ";
                // line 13
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "title", []), "html", null, true);
                echo "
                            </h2>
                            ";
                // line 15
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "description", []), "html", null, true);
                echo "
                            ";
                // line 16
                if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "downloadLink", []), "isEmpty", [], "method")) {
                    // line 17
                    echo "                                <a class=\"button-download\" href=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "downloadLink", []), "getUrl", []), "html", null, true);
                    echo "\">
                                    ";
                    // line 18
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "downloadLink", []), "getText", [], "method"), "html", null, true);
                    echo "</a>
                            ";
                }
                // line 20
                echo "                        </div>
                    </div>
                    <div class=\"col-6\">
                        <div class=\"video-wrapper rounded\">
                            <iframe allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\" frameborder=\"0\" src=\"";
                // line 24
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 24, $this->source); })()), "videoEmbedder", []), "getEmbedUrl", [0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "videoLink", [])], "method"), "html", null, true);
                echo "\"></iframe>
                        </div>
                        ";
                // line 26
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "partners", []), "all", [], "method"));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["partner"]) {
                    // line 27
                    echo "                            ";
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "first", [])) {
                        // line 28
                        echo "                                <div class=\"logos\">
                                    <span>In coloboration with</span>
                                ";
                    }
                    // line 31
                    echo "                                ";
                    echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["partner"], "logo", []), "one", [], "method"), ["ratio" => "", "srcset" => [0 => ["height" => 55, "jpegQuality" => 65]]]);
                    // line 38
                    echo "
                                ";
                    // line 39
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "last", [])) {
                        // line 40
                        echo "                                </div>
                            ";
                    }
                    // line 42
                    echo "                        ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['partner'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 43
                echo "                    </div>
                </div>
                ";
            } else {
                // line 46
                echo "                <div class=\"row\">
                    <div class=\"col-6\">
                        <div class=\"video-wrapper rounded\">
                            <iframe allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\" frameborder=\"0\" src=\"";
                // line 49
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 49, $this->source); })()), "videoEmbedder", []), "getEmbedUrl", [0 => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "videoLink", [])], "method"), "html", null, true);
                echo "\"></iframe>
                        </div>
                        ";
                // line 51
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "partners", []), "all", [], "method"));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["partner"]) {
                    // line 52
                    echo "                            ";
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "first", [])) {
                        // line 53
                        echo "                                <div class=\"logos\">
                                    <span>In coloboration with</span>
                                ";
                    }
                    // line 56
                    echo "                                ";
                    echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["partner"], "logo", []), "one", [], "method"), ["ratio" => "", "srcset" => [0 => ["height" => 55, "jpegQuality" => 65]]]);
                    // line 63
                    echo "
                                ";
                    // line 64
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "last", [])) {
                        // line 65
                        echo "                                </div>
                            ";
                    }
                    // line 67
                    echo "                        ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['partner'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 68
                echo "                    </div>
                    <div class=\"col-6\">
                        <div class=\"content\">
                            <h2>
                                ";
                // line 72
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "title", []), "html", null, true);
                echo "
                            </h2>
                            ";
                // line 74
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "description", []), "html", null, true);
                echo "
                            ";
                // line 75
                if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "downloadLink", []), "isEmpty", [], "method")) {
                    // line 76
                    echo "                                <a class=\"button-download\" href=\"";
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "downloadLink", []), "getUrl", []), "html", null, true);
                    echo "\">
                                    ";
                    // line 77
                    echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "downloadLink", []), "getText", [], "method"), "html", null, true);
                    echo "</a>
                            ";
                }
                // line 79
                echo "                        </div>
                    </div>
                </div>
            ";
            }
            // line 83
            echo "        </div>
    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 85
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "_components/portfolio/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  259 => 85,  244 => 83,  238 => 79,  233 => 77,  228 => 76,  226 => 75,  222 => 74,  217 => 72,  211 => 68,  197 => 67,  193 => 65,  191 => 64,  188 => 63,  185 => 56,  180 => 53,  177 => 52,  160 => 51,  155 => 49,  150 => 46,  145 => 43,  131 => 42,  127 => 40,  125 => 39,  122 => 38,  119 => 31,  114 => 28,  111 => 27,  94 => 26,  89 => 24,  83 => 20,  78 => 18,  73 => 17,  71 => 16,  67 => 15,  62 => 13,  56 => 9,  54 => 8,  51 => 7,  34 => 6,  29 => 4,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}
<div class=\"container list-content\">
    <h6>
        {{ component.heading }}
    </h6>
    {% for item in component.items.all() %}
        <div class=\"portfolio-item\">
            {% if loop.index is odd %}
                <div class=\"row image-right\">
                    <div class=\"col-6\">
                        <div class=\"content\">
                            <h2>
                                {{ item.title }}
                            </h2>
                            {{ item.description }}
                            {% if not item.downloadLink.isEmpty() %}
                                <a class=\"button-download\" href=\"{{ item.downloadLink.getUrl }}\">
                                    {{ item.downloadLink.getText() }}</a>
                            {% endif %}
                        </div>
                    </div>
                    <div class=\"col-6\">
                        <div class=\"video-wrapper rounded\">
                            <iframe allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\" frameborder=\"0\" src=\"{{ craft.videoEmbedder.getEmbedUrl(item.videoLink) }}\"></iframe>
                        </div>
                        {% for partner in item.partners.all() %}
                            {% if loop.first %}
                                <div class=\"logos\">
                                    <span>In coloboration with</span>
                                {% endif %}
                                {{ imageMacros.image(partner.logo.one(), {
                                            ratio: \"\",
                                            srcset: [
                                                { height: 55, jpegQuality: 65 },
                                            ]
                                        }
                                    )   
                                }}
                                {% if loop.last %}
                                </div>
                            {% endif %}
                        {% endfor %}
                    </div>
                </div>
                {% else %}
                <div class=\"row\">
                    <div class=\"col-6\">
                        <div class=\"video-wrapper rounded\">
                            <iframe allow=\"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture\" allowfullscreen=\"\" frameborder=\"0\" src=\"{{ craft.videoEmbedder.getEmbedUrl(item.videoLink) }}\"></iframe>
                        </div>
                        {% for partner in item.partners.all() %}
                            {% if loop.first %}
                                <div class=\"logos\">
                                    <span>In coloboration with</span>
                                {% endif %}
                                {{ imageMacros.image(partner.logo.one(), {
                                            ratio: \"\",
                                            srcset: [
                                                { height: 55, jpegQuality: 65 },
                                            ]
                                        }
                                    )   
                                }}
                                {% if loop.last %}
                                </div>
                            {% endif %}
                        {% endfor %}
                    </div>
                    <div class=\"col-6\">
                        <div class=\"content\">
                            <h2>
                                {{ item.title }}
                            </h2>
                            {{ item.description }}
                            {% if not item.downloadLink.isEmpty() %}
                                <a class=\"button-download\" href=\"{{ item.downloadLink.getUrl }}\">
                                    {{ item.downloadLink.getText() }}</a>
                            {% endif %}
                        </div>
                    </div>
                </div>
            {% endif %}
        </div>
    {% endfor %}
</div>", "_components/portfolio/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\portfolio\\default.twig");
    }
}
