<?php

/* typedlinkfield/_settings-element */
class __TwigTemplate_403f51120cb96d8689c86c0230b2f6ff065aeb3d2ce2f63b94fc90fc21743038 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_settings-element", 1);
        // line 2
        echo "
";
        // line 3
        echo $context["forms"]->macro_checkboxSelectField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("{elementName} sources", "typedlinkfield", ["elementName" =>         // line 4
(isset($context["elementName"]) || array_key_exists("elementName", $context) ? $context["elementName"] : (function () { throw new Twig_Error_Runtime('Variable "elementName" does not exist.', 4, $this->source); })())]), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select the available sources.", "typedlinkfield"), "id" => (("typeSettings-" .         // line 6
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 6, $this->source); })())) . "-sources"), "name" => (("typeSettings[" .         // line 7
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 7, $this->source); })())) . "][sources]"), "options" =>         // line 8
(isset($context["sources"]) || array_key_exists("sources", $context) ? $context["sources"] : (function () { throw new Twig_Error_Runtime('Variable "sources" does not exist.', 8, $this->source); })()), "values" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 9
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 9, $this->source); })()), "sources", []), "showAllOption" => true]);
        // line 11
        echo "

";
        // line 13
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow users to enter custom queries that will be appended to the url", "typedlinkfield"), "name" => "allowCustomQuery", "id" => (("typeSettings-" .         // line 16
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 16, $this->source); })())) . "-allowCustomQuery"), "name" => (("typeSettings[" .         // line 17
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 17, $this->source); })())) . "][allowCustomQuery]"), "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 18
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 18, $this->source); })()), "allowCustomQuery", [])]);
        // line 19
        echo "
";
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_settings-element";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 19,  42 => 18,  41 => 17,  40 => 16,  39 => 13,  35 => 11,  33 => 9,  32 => 8,  31 => 7,  30 => 6,  29 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{{ forms.checkboxSelectField({
  label: '{elementName} sources'|t('typedlinkfield', { 'elementName': elementName }),
  instructions: 'Select the available sources.'|t('typedlinkfield'),
  id: 'typeSettings-'~linkTypeName~'-sources',
  name: 'typeSettings['~linkTypeName~'][sources]',
  options: sources,
  values: settings.sources,
  showAllOption: true,
})}}

{{ forms.checkboxField({
  label: 'Allow users to enter custom queries that will be appended to the url'|t('typedlinkfield'),
  name: 'allowCustomQuery',
  id: 'typeSettings-'~linkTypeName~'-allowCustomQuery',
  name: 'typeSettings['~linkTypeName~'][allowCustomQuery]',
  checked: settings.allowCustomQuery
}) }}
", "typedlinkfield/_settings-element", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_settings-element.twig");
    }
}
