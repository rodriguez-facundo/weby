<?php

/* plugin-store/_index */
class __TwigTemplate_b56e7d921bd9147976f3ab6a49db469f8418b4a1e3a402d12284590770dc2375 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "plugin-store/_index", 1);
        $this->blocks = [
            'actionButton' => [$this, 'block_actionButton'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 3
        $context["title"] = $this->extensions['craft\web\twig\Extension']->translateFilter("Plugin Store", "app");
        // line 5
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 5, $this->source); })()), "registerTranslations", [0 => "app", 1 => [0 => "Active installs", 1 => "Active Trials", 2 => "Add all to cart", 3 => "Add to cart", 4 => "Added to cart", 5 => "Address Line 1", 6 => "Address Line 2", 7 => "Already in your cart", 8 => "Ascending", 9 => "Back", 10 => "Billing", 11 => "Business Name", 12 => "Business Tax ID", 13 => "Buy later", 14 => "Buy now for {price}", 15 => "Buy now", 16 => "Card number", 17 => "Cart", 18 => "Categories", 19 => "Changelog", 20 => "Checkout", 21 => "City", 22 => "Cloud Storage Integration", 23 => "Community Support (Slack, Stack Exchange)", 24 => "Compatibility", 25 => "Connect to your Craft ID", 26 => "Contact", 27 => "Content Modeling", 28 => "Continue as guest", 29 => "Continue", 30 => "Coupon Code", 31 => "CVC", 32 => "Descending", 33 => "Description", 34 => "Developer Support", 35 => "Documentation", 36 => "Features", 37 => "First Name", 38 => "For when you’re building a website for yourself or a friend.", 39 => "For when you’re building something professionally for a client or team.", 40 => "Free", 41 => "Includes Custom login screen logo, Custom site icon, Custom HTML email template, Custom email message wording", 42 => "Includes Multiple locales, Section and entry locale targeting, Content translations", 43 => "Includes Sections, Global sets, Category groups, Tag groups, Asset volumes, Custom fields, Entry versioning, and Entry drafts", 44 => "Includes User accounts, User groups, User permissions, Public user registration", 45 => "Information", 46 => "Install", 47 => "Installed as a trial", 48 => "Installed", 49 => "Item", 50 => "Items in your cart", 51 => "Last Name", 52 => "Last update", 53 => "Last Update", 54 => "Less", 55 => "License", 56 => "Licensed", 57 => "Loading Plugin Store…", 58 => "Manage plugins", 59 => "MM / YY", 60 => "More", 61 => "Multi-site Multi-lingual", 62 => "Name", 63 => "Page not found.", 64 => "Pay", 65 => "Payment Method", 66 => "Payment", 67 => "Plugin Name", 68 => "Plugin Store", 69 => "Popularity", 70 => "Price includes 1 year of updates.", 71 => "Price", 72 => "Pro Rate Discount", 73 => "Reactivate", 74 => "Remove", 75 => "Renewal price", 76 => "Save as my new credit card", 77 => "Screenshots", 78 => "Search plugins", 79 => "Security & Bug Fixes", 80 => "See all", 81 => "Showing results for “{searchQuery}”", 82 => "Staff Picks", 83 => "Subtotal", 84 => "Support", 85 => "System Branding", 86 => "Thank You!", 87 => "The Plugin Store is not available, please try again later.", 88 => "Total Price", 89 => "Total", 90 => "Try for free", 91 => "Try", 92 => "Try", 93 => "Updates until {date} ({sign}{price})", 94 => "Updates until {date}", 95 => "Updates", 96 => "Upgrade Craft CMS", 97 => "Use a new credit card", 98 => "Use card {cardDetails}", 99 => "Use your Craft ID", 100 => "User Accounts", 101 => "Version {version}", 102 => "Version", 103 => "Website", 104 => "Your order has been processed successfully.", 105 => "Zip Code", 106 => "{price} plus {renewalPrice}/year for updates", 107 => "{price}/year", 108 => "{renewalPrice}/year per site for updates after that.", 109 => "Your are currently using the {currentEdition} edition, and your licensed edition is {licensedEdition}.", 110 => "This license is tied to another Craft install. Purchase a license for this install.", 111 => "Your license key is invalid.", 112 => "Critical", 113 => "Couldn’t add all items to the cart."]], "method");
        // line 155
        $context["content"] = ('' === $tmp = "    <div id=\"app\"></div>
") ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 122
    public function block_actionButton($context, array $blocks = [])
    {
        // line 123
        echo "    <div id=\"pluginstore-actions-spinner\" class=\"spinner hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">";
        // line 127
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->svgFunction("@app/icons/shopping-cart.svg", null, true), "html", null, true);
        echo " <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">";
        // line 129
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->svgFunction("@app/icons/craftid.svg", null, true), "html", null, true);
        echo "</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"";
        // line 133
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 133, $this->source); })()), "cp", []), "craftIdAccountUrl", [], "method"), "html", null, true);
        echo "\" rel=\"noopener\" target=\"_blank\">";
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Manage your Craft ID", "app"), "html", null, true);
        echo "</a></li>
                <li>
                    <form method=\"post\" id=\"disconnect\">
                        ";
        // line 136
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
        echo "
                        <input type=\"hidden\" name=\"action\" value=\"plugin-store/disconnect\">
                        <a onclick=\"document.getElementById('disconnect').submit();\">";
        // line 138
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign out from Craft ID", "app"), "html", null, true);
        echo "</a>
                    </form>
                </li>
            </ul>
        </div>

        <form id=\"craftid-connect-form\" method=\"post\">
            ";
        // line 145
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->csrfInputFunction(), "html", null, true);
        echo "
            <input type=\"hidden\" name=\"action\" value=\"plugin-store/connect\">
            <div class=\"ssl-status light\" title=\"";
        // line 147
        echo twig_escape_filter($this->env, ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 147, $this->source); })()), "app", []), "request", []), "isSecureConnection", [])) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is secure", "app")) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Your connection is insecure", "app"))), "html", null, true);
        echo "\">
                <i class=\"";
        // line 148
        echo ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 148, $this->source); })()), "app", []), "request", []), "isSecureConnection", [])) ? ("secure") : ("insecure"));
        echo " icon\"></i>
            </div>
            <a onclick=\"document.getElementById('craftid-connect-form').submit();\">";
        // line 150
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Sign into Craft ID", "app"), "html", null, true);
        echo "</a>
        </form>
    </div>
";
    }

    public function getTemplateName()
    {
        return "plugin-store/_index";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 150,  93 => 148,  89 => 147,  84 => 145,  74 => 138,  69 => 136,  61 => 133,  54 => 129,  49 => 127,  43 => 123,  40 => 122,  36 => 1,  33 => 155,  31 => 5,  29 => 3,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"_layouts/cp\" %}

{% set title = 'Plugin Store'|t('app') %}

{% do view.registerTranslations('app', [
    \"Active installs\",
    \"Active Trials\",
    \"Add all to cart\",
    \"Add to cart\",
    \"Added to cart\",
    \"Address Line 1\",
    \"Address Line 2\",
    \"Already in your cart\",
    \"Ascending\",
    \"Back\",
    \"Billing\",
    \"Business Name\",
    \"Business Tax ID\",
    \"Buy later\",
    \"Buy now for {price}\",
    \"Buy now\",
    \"Card number\",
    \"Cart\",
    \"Categories\",
    \"Changelog\",
    \"Checkout\",
    \"City\",
    \"Cloud Storage Integration\",
    \"Community Support (Slack, Stack Exchange)\",
    \"Compatibility\",
    \"Connect to your Craft ID\",
    \"Contact\",
    \"Content Modeling\",
    \"Continue as guest\",
    \"Continue\",
    \"Coupon Code\",
    \"CVC\",
    \"Descending\",
    \"Description\",
    \"Developer Support\",
    \"Documentation\",
    \"Features\",
    \"First Name\",
    \"For when you’re building a website for yourself or a friend.\",
    \"For when you’re building something professionally for a client or team.\",
    \"Free\",
    \"Includes Custom login screen logo, Custom site icon, Custom HTML email template, Custom email message wording\",
    \"Includes Multiple locales, Section and entry locale targeting, Content translations\",
    \"Includes Sections, Global sets, Category groups, Tag groups, Asset volumes, Custom fields, Entry versioning, and Entry drafts\",
    \"Includes User accounts, User groups, User permissions, Public user registration\",
    \"Information\",
    \"Install\",
    \"Installed as a trial\",
    \"Installed\",
    \"Item\",
    \"Items in your cart\",
    \"Last Name\",
    \"Last update\",
    \"Last Update\",
    \"Less\",
    \"License\",
    \"Licensed\",
    \"Loading Plugin Store…\",
    \"Manage plugins\",
    \"MM / YY\",
    \"More\",
    \"Multi-site Multi-lingual\",
    \"Name\",
    \"Page not found.\",
    \"Pay\",
    \"Payment Method\",
    \"Payment\",
    \"Plugin Name\",
    \"Plugin Store\",
    \"Popularity\",
    \"Price includes 1 year of updates.\",
    \"Price\",
    \"Pro Rate Discount\",
    \"Reactivate\",
    \"Remove\",
    \"Renewal price\",
    \"Save as my new credit card\",
    \"Screenshots\",
    \"Search plugins\",
    \"Security & Bug Fixes\",
    \"See all\",
    \"Showing results for “{searchQuery}”\",
    \"Staff Picks\",
    \"Subtotal\",
    \"Support\",
    \"System Branding\",
    \"Thank You!\",
    \"The Plugin Store is not available, please try again later.\",
    \"Total Price\",
    \"Total\",
    \"Try for free\",
    \"Try\",
    \"Try\",
    \"Updates until {date} ({sign}{price})\",
    \"Updates until {date}\",
    \"Updates\",
    \"Upgrade Craft CMS\",
    \"Use a new credit card\",
    \"Use card {cardDetails}\",
    \"Use your Craft ID\",
    \"User Accounts\",
    \"Version {version}\",
    \"Version\",
    \"Website\",
    \"Your order has been processed successfully.\",
    \"Zip Code\",
    \"{price} plus {renewalPrice}/year for updates\",
    \"{price}/year\",
    \"{renewalPrice}/year per site for updates after that.\",
    \"Your are currently using the {currentEdition} edition, and your licensed edition is {licensedEdition}.\",
    \"This license is tied to another Craft install. Purchase a license for this install.\",
    \"Your license key is invalid.\",
    \"Critical\",
    \"Couldn’t add all items to the cart.\",
]) %}

{% block actionButton %}
    <div id=\"pluginstore-actions-spinner\" class=\"spinner hidden\"></div>

    <div id=\"pluginstore-actions\" class=\"hidden\">

        <a id=\"cart-button\" role=\"button\" tabindex=\"0\">{{ svg('@app/icons/shopping-cart.svg', namespace=true) }} <span class=\"badge\">0</span></a>

        <a id=\"craftid-account\" class=\"menubtn hidden\"><span class=\"photo\">{{ svg('@app/icons/craftid.svg', namespace=true) }}</span><span class=\"label\">Account</span></a>

        <div class=\"menu\">
            <ul>
                <li><a href=\"{{ craft.cp.craftIdAccountUrl() }}\" rel=\"noopener\" target=\"_blank\">{{ \"Manage your Craft ID\"|t('app') }}</a></li>
                <li>
                    <form method=\"post\" id=\"disconnect\">
                        {{ csrfInput() }}
                        <input type=\"hidden\" name=\"action\" value=\"plugin-store/disconnect\">
                        <a onclick=\"document.getElementById('disconnect').submit();\">{{ \"Sign out from Craft ID\"|t('app') }}</a>
                    </form>
                </li>
            </ul>
        </div>

        <form id=\"craftid-connect-form\" method=\"post\">
            {{ csrfInput() }}
            <input type=\"hidden\" name=\"action\" value=\"plugin-store/connect\">
            <div class=\"ssl-status light\" title=\"{{ craft.app.request.isSecureConnection ? \"Your connection is secure\"|t('app') : \"Your connection is insecure\"|t('app') }}\">
                <i class=\"{{ craft.app.request.isSecureConnection ? \"secure\" : \"insecure\" }} icon\"></i>
            </div>
            <a onclick=\"document.getElementById('craftid-connect-form').submit();\">{{ 'Sign into Craft ID'|t('app') }}</a>
        </form>
    </div>
{% endblock %}

{% set content %}
    <div id=\"app\"></div>
{% endset %}
", "plugin-store/_index", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\plugin-store\\_index.html");
    }
}
