<?php

/* simplemap/settings */
class __TwigTemplate_a05c1e16bb8a9db113598075a2740bd0957faa6369ea451604f8bba97b542029 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "simplemap/settings", 1);
        // line 2
        echo "
";
        // line 3
        echo $context["forms"]->macro_textField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Google Maps API Key", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("<a href=\"https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key\" target=\"_blank\">Get an API key.</a>", "simplemap"), "id" => "apiKey", "name" => "apiKey", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 8
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 8, $this->source); })()), "apiKey", []), "type" => "text", "required" => true]);
        // line 11
        echo "

";
        // line 13
        echo $context["forms"]->macro_textField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Alternate Server API Key", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("If you are using the above API key publically and need to add restrictions to it, you will need to pass an unrestricted API key here for exclusive use by the server. <a href=\"https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key\" target=\"_blank\">Get an API key.</a>", "simplemap"), "id" => "unrestrictedApiKey", "name" => "unrestrictedApiKey", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 18
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 18, $this->source); })()), "unrestrictedApiKey", []), "type" => "text", "required" => false]);
    }

    public function getTemplateName()
    {
        return "simplemap/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  36 => 18,  35 => 13,  31 => 11,  29 => 8,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{{ forms.textField({
\tlabel: \"Google Maps API Key\"|t(\"simplemap\"),
\tinstructions: '<a href=\"https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key\" target=\"_blank\">Get an API key.</a>'|t(\"simplemap\"),
\tid: 'apiKey',
\tname: 'apiKey',
\tvalue: settings.apiKey,
\ttype: 'text',
\trequired: true
}) }}

{{ forms.textField({
\tlabel: \"Alternate Server API Key\"|t(\"simplemap\"),
\tinstructions: 'If you are using the above API key publically and need to add restrictions to it, you will need to pass an unrestricted API key here for exclusive use by the server. <a href=\"https://developers.google.com/maps/documentation/javascript/get-api-key#get-an-api-key\" target=\"_blank\">Get an API key.</a>'|t(\"simplemap\"),
\tid: 'unrestrictedApiKey',
\tname: 'unrestrictedApiKey',
\tvalue: settings.unrestrictedApiKey,
\ttype: 'text',
\trequired: false
}) }}", "simplemap/settings", "E:\\Code\\Craft\\metacell\\vendor\\ether\\simplemap\\src\\templates\\settings.twig");
    }
}
