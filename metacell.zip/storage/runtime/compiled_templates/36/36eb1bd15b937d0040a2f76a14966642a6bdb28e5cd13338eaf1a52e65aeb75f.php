<?php

/* super-table/fields */
class __TwigTemplate_2b7c2b0a3b6644a4d706c56efcb3d5b6b8118470c5eabde96ba10fde33bc2a56 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        try {
            $this->loadTemplate((("super-table/" . craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 1, $this->source); })()), "fieldLayout", [])) . "/fields"), "super-table/fields", 1)->display($context);
        } catch (Twig_Error_Loader $e) {
            // ignore missing template
        }

    }

    public function getTemplateName()
    {
        return "super-table/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% include 'super-table/' ~ settings.fieldLayout ~ '/fields' ignore missing %}
", "super-table/fields", "E:\\Code\\Craft\\metacell\\vendor\\verbb\\super-table\\src\\templates\\fields.html");
    }
}
