<?php

/* simplemap/field-settings */
class __TwigTemplate_9aa5a1850bb5950b7d4140f11a92908bf4ba49c6597b306855250db34859b9dd extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "simplemap/field-settings", 1);
        // line 2
        echo "
";
        // line 3
        echo $context["forms"]->macro_lightswitchField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Hide Map", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("When on, the map will be hidden leaving just the address search field", "simplemap"), "id" => "hideMap", "name" => "hideMap", "on" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 8
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 8, $this->source); })()), "hideMap", [])]);
        // line 9
        echo "

";
        // line 11
        echo $context["forms"]->macro_lightswitchField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Hide Lat/Lng", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("When on, the latitude & longitude fields will be hidden", "simplemap"), "id" => "hideLatLng", "name" => "hideLatLng", "on" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 16
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 16, $this->source); })()), "hideLatLng", [])]);
        // line 17
        echo "

<input type=\"hidden\" id=\"lat\" name=\"lat\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 19, $this->source); })()), "lat", []), "html", null, true);
        echo "\">
<input type=\"hidden\" id=\"lng\" name=\"lng\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 20, $this->source); })()), "lng", []), "html", null, true);
        echo "\">
<input type=\"hidden\" id=\"zoom\" name=\"zoom\" value=\"";
        // line 21
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 21, $this->source); })()), "zoom", []), "html", null, true);
        echo "\">
<input type=\"hidden\" id=\"height\" name=\"height\" value=\"";
        // line 22
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 22, $this->source); })()), "height", []), "html", null, true);
        echo "\">

";
        // line 24
        ob_start();
        // line 25
        echo "\t<div
\t\tid=\"settingsMap\"
\t\tclass=\"simplemap-settings--settings-map\"
\t\tstyle=\"height:";
        // line 28
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 28, $this->source); })()), "height", []), "html", null, true);
        echo "px\"
\t></div>
\t<div
\t\tid=\"settingsMapHeight\"
\t\tclass=\"simplemap-settings--resize\"
\t\ttitle=\"Drag to resize\"
\t></div>
";
        $context["settingsMap"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 36
        echo "<div
\tid=\"settingsMapWrap\"
\tclass=\"simplemap-settings--wrap ";
        // line 38
        echo ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 38, $this->source); })()), "hideMap", [])) ? ("hide") : (""));
        echo "\"
>
\t";
        // line 40
        echo $context["forms"]->macro_field(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Configure Map", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Move, zoom, and resize the map", "simplemap")],         // line 43
(isset($context["settingsMap"]) || array_key_exists("settingsMap", $context) ? $context["settingsMap"] : (function () { throw new Twig_Error_Runtime('Variable "settingsMap" does not exist.', 43, $this->source); })()));
        echo "
</div>

<hr>

";
        // line 48
        echo $context["forms"]->macro_selectField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Restrict by Country", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Restrict the address search to a specific country", "simplemap"), "id" => "countryRestriction", "name" => "countryRestriction", "options" =>         // line 53
(isset($context["countries"]) || array_key_exists("countries", $context) ? $context["countries"] : (function () { throw new Twig_Error_Runtime('Variable "countries" does not exist.', 53, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 54
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 54, $this->source); })()), "countryRestriction", [])]);
        // line 55
        echo "

";
        // line 57
        echo $context["forms"]->macro_selectField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Restrict by Type", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Restrict the address search to a specific type", "simplemap"), "id" => "typeRestriction", "name" => "typeRestriction", "options" =>         // line 62
(isset($context["types"]) || array_key_exists("types", $context) ? $context["types"] : (function () { throw new Twig_Error_Runtime('Variable "types" does not exist.', 62, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 63
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 63, $this->source); })()), "typeRestriction", [])]);
        // line 64
        echo "

<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionNELat\"
\tname=\"boundaryRestrictionNELat\"
\tvalue=\"";
        // line 70
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 70, $this->source); })()), "boundaryRestrictionNELat", []), "html", null, true);
        echo "\"
>
<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionNELng\"
\tname=\"boundaryRestrictionNELng\"
\tvalue=\"";
        // line 76
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 76, $this->source); })()), "boundaryRestrictionNELng", []), "html", null, true);
        echo "\"
>
<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionSWLat\"
\tname=\"boundaryRestrictionSWLat\"
\tvalue=\"";
        // line 82
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 82, $this->source); })()), "boundaryRestrictionSWLat", []), "html", null, true);
        echo "\"
>
<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionSWLng\"
\tname=\"boundaryRestrictionSWLng\"
\tvalue=\"";
        // line 88
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 88, $this->source); })()), "boundaryRestrictionSWLng", []), "html", null, true);
        echo "\"
>

";
        // line 91
        ob_start();
        // line 92
        echo "\t<button
\t\tid=\"boundaryButton\"
\t\tclass=\"simplemap-settings--boundary-button\"
\t\ttype=\"button\"
\t>
\t\t";
        // line 97
        echo ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 97, $this->source); })()), "boundaryRestrictionNELat", [])) ? ("Clear") : ("Draw"));
        echo " Boundaries
\t</button>
\t<div class=\"simplemap-settings--boundary-map-wrap\">
\t\t<div
\t\t\tid=\"boundaryMap\"
\t\t\tclass=\"simplemap-settings--boundary-map\"
\t\t></div>
\t</div>
";
        $context["boundaryMap"] = ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        // line 106
        echo $context["forms"]->macro_field(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Boundary Restriction", "simplemap"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Restrict the address search to within a specific rectangular boundary", "simplemap")],         // line 109
(isset($context["boundaryMap"]) || array_key_exists("boundaryMap", $context) ? $context["boundaryMap"] : (function () { throw new Twig_Error_Runtime('Variable "boundaryMap" does not exist.', 109, $this->source); })()));
    }

    public function getTemplateName()
    {
        return "simplemap/field-settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 109,  169 => 106,  157 => 97,  150 => 92,  148 => 91,  142 => 88,  133 => 82,  124 => 76,  115 => 70,  107 => 64,  105 => 63,  104 => 62,  103 => 57,  99 => 55,  97 => 54,  96 => 53,  95 => 48,  87 => 43,  86 => 40,  81 => 38,  77 => 36,  66 => 28,  61 => 25,  59 => 24,  54 => 22,  50 => 21,  46 => 20,  42 => 19,  38 => 17,  36 => 16,  35 => 11,  31 => 9,  29 => 8,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{{ forms.lightswitchField({
\tlabel: \"Hide Map\"|t(\"simplemap\"),
\tinstructions: \"When on, the map will be hidden leaving just the address search field\"|t(\"simplemap\"),
\tid: 'hideMap',
\tname: 'hideMap',
\ton: field.hideMap
}) }}

{{ forms.lightswitchField({
\tlabel: \"Hide Lat/Lng\"|t(\"simplemap\"),
\tinstructions: \"When on, the latitude & longitude fields will be hidden\"|t(\"simplemap\"),
\tid: 'hideLatLng',
\tname: 'hideLatLng',
\ton: field.hideLatLng
}) }}

<input type=\"hidden\" id=\"lat\" name=\"lat\" value=\"{{ field.lat }}\">
<input type=\"hidden\" id=\"lng\" name=\"lng\" value=\"{{ field.lng }}\">
<input type=\"hidden\" id=\"zoom\" name=\"zoom\" value=\"{{ field.zoom }}\">
<input type=\"hidden\" id=\"height\" name=\"height\" value=\"{{ field.height }}\">

{% set settingsMap %}
\t<div
\t\tid=\"settingsMap\"
\t\tclass=\"simplemap-settings--settings-map\"
\t\tstyle=\"height:{{ field.height }}px\"
\t></div>
\t<div
\t\tid=\"settingsMapHeight\"
\t\tclass=\"simplemap-settings--resize\"
\t\ttitle=\"Drag to resize\"
\t></div>
{% endset %}
<div
\tid=\"settingsMapWrap\"
\tclass=\"simplemap-settings--wrap {{ field.hideMap ? 'hide' }}\"
>
\t{{ forms.field({
\t\tlabel: \"Configure Map\"|t(\"simplemap\"),
\t\tinstructions: \"Move, zoom, and resize the map\"|t(\"simplemap\"),
\t}, settingsMap) }}
</div>

<hr>

{{ forms.selectField({
\tlabel: \"Restrict by Country\"|t(\"simplemap\"),
\tinstructions: \"Restrict the address search to a specific country\"|t(\"simplemap\"),
\tid: 'countryRestriction',
\tname: 'countryRestriction',
\toptions: countries,
\tvalue: field.countryRestriction
}) }}

{{ forms.selectField({
\tlabel: \"Restrict by Type\"|t(\"simplemap\"),
\tinstructions: \"Restrict the address search to a specific type\"|t(\"simplemap\"),
\tid: 'typeRestriction',
\tname: 'typeRestriction',
\toptions: types,
\tvalue: field.typeRestriction
}) }}

<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionNELat\"
\tname=\"boundaryRestrictionNELat\"
\tvalue=\"{{ field.boundaryRestrictionNELat }}\"
>
<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionNELng\"
\tname=\"boundaryRestrictionNELng\"
\tvalue=\"{{ field.boundaryRestrictionNELng }}\"
>
<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionSWLat\"
\tname=\"boundaryRestrictionSWLat\"
\tvalue=\"{{ field.boundaryRestrictionSWLat }}\"
>
<input
\ttype=\"hidden\"
\tid=\"boundaryRestrictionSWLng\"
\tname=\"boundaryRestrictionSWLng\"
\tvalue=\"{{ field.boundaryRestrictionSWLng }}\"
>

{% set boundaryMap %}
\t<button
\t\tid=\"boundaryButton\"
\t\tclass=\"simplemap-settings--boundary-button\"
\t\ttype=\"button\"
\t>
\t\t{{ field.boundaryRestrictionNELat ? \"Clear\" : \"Draw\" }} Boundaries
\t</button>
\t<div class=\"simplemap-settings--boundary-map-wrap\">
\t\t<div
\t\t\tid=\"boundaryMap\"
\t\t\tclass=\"simplemap-settings--boundary-map\"
\t\t></div>
\t</div>
{% endset %}
{{ forms.field({
\tlabel: \"Boundary Restriction\"|t(\"simplemap\"),
\tinstructions: \"Restrict the address search to within a specific rectangular boundary\"|t(\"simplemap\"),
}, boundaryMap) }}", "simplemap/field-settings", "E:\\Code\\Craft\\metacell\\vendor\\ether\\simplemap\\src\\templates\\field-settings.twig");
    }
}
