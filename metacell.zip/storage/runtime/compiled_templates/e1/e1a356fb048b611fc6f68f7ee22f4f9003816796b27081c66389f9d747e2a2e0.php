<?php

/* __string_template__fafe04a84edfda7d8caeae41ab2fc30f3625dcc27b6fc48b72dd9c8200c286d1 */
class __TwigTemplate_8feaf4a8f028d7a79beb3034a2dd79ce4b4e8df30c94a9cc888fe7ef65b16d87 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "resources/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "slug", [])));
    }

    public function getTemplateName()
    {
        return "__string_template__fafe04a84edfda7d8caeae41ab2fc30f3625dcc27b6fc48b72dd9c8200c286d1";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("resources/{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__fafe04a84edfda7d8caeae41ab2fc30f3625dcc27b6fc48b72dd9c8200c286d1", "");
    }
}
