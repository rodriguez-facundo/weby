<?php

/* _components/sectionTitle/default.twig */
class __TwigTemplate_af98b62d5c8f29b078c6199de8168854480e23115739f1142a9b00e4a812e328 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"component-container\">
    <div class=\"section-title\">
        <div class=\"container\">
            <h2>
                ";
        // line 5
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 5, $this->source); })()), "heading", []), "html", null, true);
        echo "
            </h2>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/sectionTitle/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 5,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"component-container\">
    <div class=\"section-title\">
        <div class=\"container\">
            <h2>
                {{ component.heading }}
            </h2>
        </div>
    </div>
</div>", "_components/sectionTitle/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\sectionTitle\\default.twig");
    }
}
