<?php

/* video-embedder/VideoField/inputEmbed.twig */
class __TwigTemplate_74398db2d4a06eea58b89d089df243b203090b98d4f9087c36b15569054b1f65 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "video-embedder/VideoField/inputEmbed.twig", 1);
        // line 2
        echo "
";
        // line 3
        if ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 3, $this->source); })())) {
            // line 4
            echo "\t";
            $context["embed"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 4, $this->source); })()), "videoEmbedder", []), "embed", [0 => (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 4, $this->source); })()), 1 => ["autoplay" => 0, "rel" => 0, "theme" => "dark"]], "method");
            // line 5
            echo "    ";
            if (twig_length_filter($this->env, (isset($context["embed"]) || array_key_exists("embed", $context) ? $context["embed"] : (function () { throw new Twig_Error_Runtime('Variable "embed" does not exist.', 5, $this->source); })()))) {
                // line 6
                echo "\t\t";
                echo twig_escape_filter($this->env, (isset($context["embed"]) || array_key_exists("embed", $context) ? $context["embed"] : (function () { throw new Twig_Error_Runtime('Variable "embed" does not exist.', 6, $this->source); })()), "html", null, true);
                echo "
\t";
            }
        }
    }

    public function getTemplateName()
    {
        return "video-embedder/VideoField/inputEmbed.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  36 => 6,  33 => 5,  30 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{% if value %}
\t{% set embed = craft.videoEmbedder.embed(value, {autoplay: 0, rel: 0, theme: 'dark'}) %}
    {% if embed | length %}
\t\t{{ embed }}
\t{% endif %}
{% endif %}
", "video-embedder/VideoField/inputEmbed.twig", "E:\\Code\\Craft\\metacell\\vendor\\mikestecker\\craft-videoembedder\\src\\templates\\VideoField\\inputEmbed.twig");
    }
}
