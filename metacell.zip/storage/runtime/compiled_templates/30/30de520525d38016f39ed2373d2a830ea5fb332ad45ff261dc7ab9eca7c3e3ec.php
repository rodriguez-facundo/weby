<?php

/* _components/offices/default.twig */
class __TwigTemplate_19a6bda3a2d0605e2b70118e3b31f59177d340a167f28d5546a410bcaa74419d extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"component-container\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 2, $this->source); })()), "offices", []), "all", [], "method"));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["office"]) {
            // line 3
            echo "        ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["loop"], "index", []) % 2 == 1)) {
                // line 4
                echo "            <div class=\"offices right\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-6\">
                            <div class=\"text-wrapper\">
                                <div class=\"text\">
                                    <p>
                                        ";
                // line 11
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "addressLine1", []), "html", null, true);
                echo "
                                        <br/>
                                        ";
                // line 13
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "addressLine2", []), "html", null, true);
                echo "
                                        <br/>
                                        ";
                // line 15
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "country", []), "html", null, true);
                echo "
                                        <br/>
                                        ";
                // line 17
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "phone", []), "html", null, true);
                echo "
                                    </p>
                                    <a class=\"btn-secondary\" href=\"#\">Get directions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"map\">
                    <iframe allowfullscreen=\"\" frameborder=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d915.238070515975!2d23.318760284460645!3d42.68934977106903!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40aa85126712c8c3%3A0x874524c8258213f5!2z0J3QlNCa!5e0!3m2!1sbg!2sbg!4v1548424910507\" style=\"border:0\"></iframe>
                </div>
            </div>
            ";
            } else {
                // line 30
                echo "            <div class=\"offices\">
                <div class=\"map\">
                    <iframe allowfullscreen=\"\" frameborder=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d915.238070515975!2d23.318760284460645!3d42.68934977106903!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40aa85126712c8c3%3A0x874524c8258213f5!2z0J3QlNCa!5e0!3m2!1sbg!2sbg!4v1548424910507\" style=\"border:0\"></iframe>
                </div>
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-6\">
                            <div class=\"text-wrapper\">
                                <div class=\"text\">
                                    <p>
                                        ";
                // line 40
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "addressLine1", []), "html", null, true);
                echo "
                                        <br/>
                                        ";
                // line 42
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "addressLine2", []), "html", null, true);
                echo "
                                        <br/>
                                        ";
                // line 44
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "country", []), "html", null, true);
                echo "
                                        <br/>
                                        ";
                // line 46
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["office"], "phone", []), "html", null, true);
                echo "
                                    </p>
                                    <a class=\"btn-secondary\" href=\"#\">Get directions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        ";
            }
            // line 56
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['office'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 57
        echo "</div>";
    }

    public function getTemplateName()
    {
        return "_components/offices/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 57,  126 => 56,  113 => 46,  108 => 44,  103 => 42,  98 => 40,  86 => 30,  70 => 17,  65 => 15,  60 => 13,  55 => 11,  46 => 4,  43 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"component-container\">
    {% for office in component.offices.all() %}
        {% if loop.index is odd %}
            <div class=\"offices right\">
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-6\">
                            <div class=\"text-wrapper\">
                                <div class=\"text\">
                                    <p>
                                        {{ office.addressLine1 }}
                                        <br/>
                                        {{ office.addressLine2 }}
                                        <br/>
                                        {{ office.country }}
                                        <br/>
                                        {{ office.phone }}
                                    </p>
                                    <a class=\"btn-secondary\" href=\"#\">Get directions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class=\"map\">
                    <iframe allowfullscreen=\"\" frameborder=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d915.238070515975!2d23.318760284460645!3d42.68934977106903!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40aa85126712c8c3%3A0x874524c8258213f5!2z0J3QlNCa!5e0!3m2!1sbg!2sbg!4v1548424910507\" style=\"border:0\"></iframe>
                </div>
            </div>
            {% else %}
            <div class=\"offices\">
                <div class=\"map\">
                    <iframe allowfullscreen=\"\" frameborder=\"0\" src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d915.238070515975!2d23.318760284460645!3d42.68934977106903!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x40aa85126712c8c3%3A0x874524c8258213f5!2z0J3QlNCa!5e0!3m2!1sbg!2sbg!4v1548424910507\" style=\"border:0\"></iframe>
                </div>
                <div class=\"container\">
                    <div class=\"row\">
                        <div class=\"col-6\">
                            <div class=\"text-wrapper\">
                                <div class=\"text\">
                                    <p>
                                        {{ office.addressLine1 }}
                                        <br/>
                                        {{ office.addressLine2 }}
                                        <br/>
                                        {{ office.country }}
                                        <br/>
                                        {{ office.phone }}
                                    </p>
                                    <a class=\"btn-secondary\" href=\"#\">Get directions</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        {% endif %}
    {% endfor %}
</div>", "_components/offices/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\offices\\default.twig");
    }
}
