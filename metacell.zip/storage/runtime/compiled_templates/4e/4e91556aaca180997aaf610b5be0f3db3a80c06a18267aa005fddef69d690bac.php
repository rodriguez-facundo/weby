<?php

/* _includes/forms/editableTable */
class __TwigTemplate_30187f14552a9ef48a2d30aebe00a54ab78b7cd2e2b11f272e4a466e1ae2bc4c extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["static"] = (($context["static"]) ?? (false));
        // line 2
        $context["cols"] = (($context["cols"]) ?? ([]));
        // line 3
        $context["rows"] = (($context["rows"]) ?? ([]));
        // line 4
        $context["initJs"] = ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 4, $this->source); })()) && (($context["initJs"]) ?? (true)));
        // line 5
        $context["minRows"] = (($context["minRows"]) ?? (null));
        // line 6
        $context["maxRows"] = (($context["maxRows"]) ?? (null));
        // line 7
        $context["staticRows"] = (((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 7, $this->source); })()) || (($context["staticRows"]) ?? (false))) || ((((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new Twig_Error_Runtime('Variable "minRows" does not exist.', 7, $this->source); })()) == 1) && ((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new Twig_Error_Runtime('Variable "maxRows" does not exist.', 7, $this->source); })()) == 1)) && (twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new Twig_Error_Runtime('Variable "rows" does not exist.', 7, $this->source); })())) == 1)));
        // line 8
        $context["fixedRows"] = ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new Twig_Error_Runtime('Variable "staticRows" does not exist.', 8, $this->source); })()) && (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new Twig_Error_Runtime('Variable "minRows" does not exist.', 8, $this->source); })()) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new Twig_Error_Runtime('Variable "minRows" does not exist.', 8, $this->source); })()) == (isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new Twig_Error_Runtime('Variable "maxRows" does not exist.', 8, $this->source); })()))) && ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new Twig_Error_Runtime('Variable "minRows" does not exist.', 8, $this->source); })()) == twig_length_filter($this->env, (isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new Twig_Error_Runtime('Variable "rows" does not exist.', 8, $this->source); })())))));
        // line 9
        echo "
";
        // line 10
        if ( !(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 10, $this->source); })())) {
            // line 11
            echo "    <input type=\"hidden\" name=\"";
            echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 11, $this->source); })()), "html", null, true);
            echo "\" value=\"\">
";
        }
        // line 13
        echo "
<table id=\"";
        // line 14
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 14, $this->source); })()), "html", null, true);
        echo "\" class=\"shadow-box editable\"";
        // line 15
        if (        $this->hasBlock("attr", $context, $blocks)) {
            echo " ";
            $this->displayBlock("attr", $context, $blocks);
        }
        echo ">
    <thead>
        <tr>
            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new Twig_Error_Runtime('Variable "cols" does not exist.', 18, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["col"]) {
            // line 19
            switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "type", [])) {
                case "time":
                {
                    // line 21
                    craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 21, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\timepicker\\TimepickerAsset"], "method");
                    break;
                }
                case "template":
                {
                    // line 23
                    craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 23, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\vue\\VueAsset"], "method");
                    break;
                }
            }
            // line 25
            echo "                <th scope=\"col\" class=\"";
            echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [])) : ("")), "html", null, true);
            echo "\">";
            // line 26
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "heading", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "heading", []))) {
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "heading", []), "html", null, true);
            } else {
                echo "&nbsp;";
            }
            // line 27
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "info", [], "any", true, true)) {
                // line 28
                echo "<span class=\"info\">";
                echo $this->extensions['craft\web\twig\Extension']->markdownFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "info", []));
                echo "</span>";
            }
            // line 30
            echo "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['col'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "            ";
        if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new Twig_Error_Runtime('Variable "staticRows" does not exist.', 32, $this->source); })())) {
            // line 33
            echo "                <th colspan=\"";
            echo (((isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new Twig_Error_Runtime('Variable "fixedRows" does not exist.', 33, $this->source); })())) ? (1) : (2));
            echo "\"></th>
            ";
        }
        // line 35
        echo "        </tr>
    </thead>
    <tbody>
        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["rows"]) || array_key_exists("rows", $context) ? $context["rows"] : (function () { throw new Twig_Error_Runtime('Variable "rows" does not exist.', 38, $this->source); })()));
        foreach ($context['_seq'] as $context["rowId"] => $context["row"]) {
            // line 39
            echo "            <tr data-id=\"";
            echo twig_escape_filter($this->env, $context["rowId"], "html", null, true);
            echo "\">
                ";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new Twig_Error_Runtime('Variable "cols" does not exist.', 40, $this->source); })()));
            foreach ($context['_seq'] as $context["colId"] => $context["col"]) {
                // line 41
                echo "                    ";
                $context["cell"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["row"], $context["colId"], [], "array", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["row"], $context["colId"], [], "array")))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["row"], $context["colId"], [], "array")) : (null));
                // line 42
                echo "                    ";
                $context["value"] = ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "value", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new Twig_Error_Runtime('Variable "cell" does not exist.', 42, $this->source); })()), "value", [])) : ((isset($context["cell"]) || array_key_exists("cell", $context) ? $context["cell"] : (function () { throw new Twig_Error_Runtime('Variable "cell" does not exist.', 42, $this->source); })())));
                // line 43
                echo "                    ";
                if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "type", []) == "heading")) {
                    // line 44
                    echo "                        <th scope=\"row\" class=\"";
                    echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [])) : ("")))), "html", null, true);
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 44, $this->source); })());
                    echo "</th>
                    ";
                } elseif ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 45
$context["col"], "type", []) == "html")) {
                    // line 46
                    echo "                        <td class=\"";
                    echo twig_escape_filter($this->env, (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "class", [])) : ((((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [])) : ("")))), "html", null, true);
                    echo "\">";
                    echo (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 46, $this->source); })());
                    echo "</td>
                    ";
                } else {
                    // line 48
                    echo "                        ";
                    $context["hasErrors"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "hasErrors", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "hasErrors", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "hasErrors", [])) : (false));
                    // line 49
                    echo "                        ";
                    $context["cellName"] = ((((((isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 49, $this->source); })()) . "[") . $context["rowId"]) . "][") . $context["colId"]) . "]");
                    // line 50
                    echo "                        ";
                    $context["textual"] = twig_in_filter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "type", []), [0 => "color", 1 => "date", 2 => "multiline", 3 => "number", 4 => "singleline", 5 => "template", 6 => "time"]);
                    // line 51
                    echo "                        ";
                    $context["isCode"] = (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "code", [], "any", true, true) || (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "type", []) == "color"));
                    // line 52
                    echo "                        <td class=\"";
                    if ((isset($context["textual"]) || array_key_exists("textual", $context) ? $context["textual"] : (function () { throw new Twig_Error_Runtime('Variable "textual" does not exist.', 52, $this->source); })())) {
                        echo "textual";
                    }
                    echo " ";
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", [], "any", true, true)) {
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "class", []), "html", null, true);
                    }
                    echo " ";
                    if ((isset($context["isCode"]) || array_key_exists("isCode", $context) ? $context["isCode"] : (function () { throw new Twig_Error_Runtime('Variable "isCode" does not exist.', 52, $this->source); })())) {
                        echo "code";
                    }
                    echo " ";
                    if ((isset($context["hasErrors"]) || array_key_exists("hasErrors", $context) ? $context["hasErrors"] : (function () { throw new Twig_Error_Runtime('Variable "hasErrors" does not exist.', 52, $this->source); })())) {
                        echo "error";
                    }
                    echo "\"";
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "width", [], "any", true, true)) {
                        echo " width=\"";
                        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "width", []), "html", null, true);
                        echo "\"";
                    }
                    echo ">";
                    // line 53
                    switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "type", [])) {
                        case "checkbox":
                        {
                            // line 55
                            $this->loadTemplate("_includes/forms/checkbox", "_includes/forms/editableTable", 55)->display(["name" =>                             // line 56
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 56, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                             // line 57
$context["col"], "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "value", [])) : (1)), "checked" =>  !twig_test_empty(                            // line 58
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 58, $this->source); })())), "disabled" =>                             // line 59
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 59, $this->source); })())]);
                            break;
                        }
                        case "color":
                        {
                            // line 62
                            $this->loadTemplate("_includes/forms/color", "_includes/forms/editableTable", 62)->display(["name" =>                             // line 63
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 63, $this->source); })()), "value" =>                             // line 64
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 64, $this->source); })()), "small" => true, "disabled" =>                             // line 66
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 66, $this->source); })())]);
                            break;
                        }
                        case "date":
                        {
                            // line 69
                            $this->loadTemplate("_includes/forms/date", "_includes/forms/editableTable", 69)->display(["name" =>                             // line 70
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 70, $this->source); })()), "value" =>                             // line 71
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 71, $this->source); })()), "disabled" =>                             // line 72
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 72, $this->source); })())]);
                            break;
                        }
                        case "lightswitch":
                        {
                            // line 75
                            $this->loadTemplate("_includes/forms/lightswitch", "_includes/forms/editableTable", 75)->display(["name" =>                             // line 76
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 76, $this->source); })()), "on" =>                             // line 77
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 77, $this->source); })()), "value" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                             // line 78
$context["col"], "value", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "value", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "value", [])) : (1)), "small" => true, "disabled" =>                             // line 80
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 80, $this->source); })())]);
                            // line 82
                            echo "                                ";
                            break;
                        }
                        case "select":
                        {
                            // line 83
                            $this->loadTemplate("_includes/forms/select", "_includes/forms/editableTable", 83)->display(["class" => "small", "name" =>                             // line 85
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 85, $this->source); })()), "options" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                             // line 86
($context["cell"] ?? null), "options", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "options", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["cell"] ?? null), "options", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "options", []))), "value" =>                             // line 87
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 87, $this->source); })()), "disabled" =>                             // line 88
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 88, $this->source); })())]);
                            break;
                        }
                        case "time":
                        {
                            // line 91
                            $this->loadTemplate("_includes/forms/time", "_includes/forms/editableTable", 91)->display(["name" =>                             // line 92
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 92, $this->source); })()), "value" =>                             // line 93
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 93, $this->source); })()), "disabled" =>                             // line 94
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 94, $this->source); })())]);
                            break;
                        }
                        case "template":
                        {
                            // line 97
                            $this->loadTemplate("_includes/forms/autosuggest", "_includes/forms/editableTable", 97)->display(["name" =>                             // line 98
(isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 98, $this->source); })()), "suggestions" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                             // line 99
(isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 99, $this->source); })()), "cp", []), "getTemplateSuggestions", [], "method"), "value" =>                             // line 100
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 100, $this->source); })()), "disabled" =>                             // line 101
(isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 101, $this->source); })())]);
                            break;
                        }
                        default:
                        {
                            // line 104
                            echo "<textarea name=\"";
                            echo twig_escape_filter($this->env, (isset($context["cellName"]) || array_key_exists("cellName", $context) ? $context["cellName"] : (function () { throw new Twig_Error_Runtime('Variable "cellName" does not exist.', 104, $this->source); })()), "html", null, true);
                            echo "\" rows=\"1\"";
                            if ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 104, $this->source); })())) {
                                echo " disabled";
                            }
                            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "placeholder", [], "any", true, true)) {
                                echo " placeholder=\"";
                                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["col"], "placeholder", []), "html", null, true);
                                echo "\"";
                            }
                            echo ">";
                            echo twig_escape_filter($this->env, (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 104, $this->source); })()), "html", null, true);
                            echo "</textarea>";
                        }
                    }
                    // line 106
                    echo "</td>
                    ";
                }
                // line 108
                echo "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['colId'], $context['col'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 109
            echo "                ";
            if ( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new Twig_Error_Runtime('Variable "staticRows" does not exist.', 109, $this->source); })())) {
                // line 110
                echo "                    <td class=\"thin action\"><a class=\"move icon\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Reorder", "app"), "html", null, true);
                echo "\"></a></td>
                    ";
                // line 111
                if ( !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new Twig_Error_Runtime('Variable "fixedRows" does not exist.', 111, $this->source); })())) {
                    echo "<td class=\"thin action\"><a class=\"delete icon\" title=\"";
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Delete", "app"), "html", null, true);
                    echo "\"></a></td>";
                }
                // line 112
                echo "                ";
            }
            // line 113
            echo "            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['rowId'], $context['row'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 115
        echo "    </tbody>
</table>
";
        // line 117
        if (( !(isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new Twig_Error_Runtime('Variable "staticRows" does not exist.', 117, $this->source); })()) &&  !(isset($context["fixedRows"]) || array_key_exists("fixedRows", $context) ? $context["fixedRows"] : (function () { throw new Twig_Error_Runtime('Variable "fixedRows" does not exist.', 117, $this->source); })()))) {
            // line 118
            echo "    <div class=\"btn add icon\">";
            echo twig_escape_filter($this->env, (((isset($context["addRowLabel"]) || array_key_exists("addRowLabel", $context))) ? ((isset($context["addRowLabel"]) || array_key_exists("addRowLabel", $context) ? $context["addRowLabel"] : (function () { throw new Twig_Error_Runtime('Variable "addRowLabel" does not exist.', 118, $this->source); })())) : ($this->extensions['craft\web\twig\Extension']->translateFilter("Add a row", "app"))), "html", null, true);
            echo "</div>
";
        }
        // line 120
        echo "
";
        // line 121
        if ((isset($context["initJs"]) || array_key_exists("initJs", $context) ? $context["initJs"] : (function () { throw new Twig_Error_Runtime('Variable "initJs" does not exist.', 121, $this->source); })())) {
            // line 122
            echo "    ";
            $context["jsId"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 122, $this->source); })())]), "js");
            // line 123
            echo "    ";
            $context["jsName"] = twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 123, $this->source); })())]), "js");
            // line 124
            echo "    ";
            $context["jsCols"] = $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["cols"]) || array_key_exists("cols", $context) ? $context["cols"] : (function () { throw new Twig_Error_Runtime('Variable "cols" does not exist.', 124, $this->source); })()));
            // line 125
            echo "    ";
            $context["defaultValues"] = (($context["defaultValues"]) ?? (null));
            // line 126
            echo "    ";
            ob_start();
            // line 127
            echo "        new Craft.EditableTable(\"";
            echo twig_escape_filter($this->env, (isset($context["jsId"]) || array_key_exists("jsId", $context) ? $context["jsId"] : (function () { throw new Twig_Error_Runtime('Variable "jsId" does not exist.', 127, $this->source); })()), "html", null, true);
            echo "\", \"";
            echo twig_escape_filter($this->env, (isset($context["jsName"]) || array_key_exists("jsName", $context) ? $context["jsName"] : (function () { throw new Twig_Error_Runtime('Variable "jsName" does not exist.', 127, $this->source); })()), "html", null, true);
            echo "\", ";
            echo (isset($context["jsCols"]) || array_key_exists("jsCols", $context) ? $context["jsCols"] : (function () { throw new Twig_Error_Runtime('Variable "jsCols" does not exist.', 127, $this->source); })());
            echo ", {
            defaultValues: ";
            // line 128
            echo (((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new Twig_Error_Runtime('Variable "defaultValues" does not exist.', 128, $this->source); })())) ? ($this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["defaultValues"]) || array_key_exists("defaultValues", $context) ? $context["defaultValues"] : (function () { throw new Twig_Error_Runtime('Variable "defaultValues" does not exist.', 128, $this->source); })()))) : ("{}"));
            echo ",
            staticRows: ";
            // line 129
            echo (((isset($context["staticRows"]) || array_key_exists("staticRows", $context) ? $context["staticRows"] : (function () { throw new Twig_Error_Runtime('Variable "staticRows" does not exist.', 129, $this->source); })())) ? ("true") : ("false"));
            echo ",
            minRows: ";
            // line 130
            echo twig_escape_filter($this->env, (((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new Twig_Error_Runtime('Variable "minRows" does not exist.', 130, $this->source); })())) ? ((isset($context["minRows"]) || array_key_exists("minRows", $context) ? $context["minRows"] : (function () { throw new Twig_Error_Runtime('Variable "minRows" does not exist.', 130, $this->source); })())) : ("null")), "html", null, true);
            echo ",
            maxRows: ";
            // line 131
            echo twig_escape_filter($this->env, (((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new Twig_Error_Runtime('Variable "maxRows" does not exist.', 131, $this->source); })())) ? ((isset($context["maxRows"]) || array_key_exists("maxRows", $context) ? $context["maxRows"] : (function () { throw new Twig_Error_Runtime('Variable "maxRows" does not exist.', 131, $this->source); })())) : ("null")), "html", null, true);
            echo "
        });
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
    }

    public function getTemplateName()
    {
        return "_includes/forms/editableTable";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  374 => 131,  370 => 130,  366 => 129,  362 => 128,  353 => 127,  350 => 126,  347 => 125,  344 => 124,  341 => 123,  338 => 122,  336 => 121,  333 => 120,  327 => 118,  325 => 117,  321 => 115,  314 => 113,  311 => 112,  305 => 111,  300 => 110,  297 => 109,  291 => 108,  287 => 106,  270 => 104,  264 => 101,  263 => 100,  262 => 99,  261 => 98,  260 => 97,  254 => 94,  253 => 93,  252 => 92,  251 => 91,  245 => 88,  244 => 87,  243 => 86,  242 => 85,  241 => 83,  235 => 82,  233 => 80,  232 => 78,  231 => 77,  230 => 76,  229 => 75,  223 => 72,  222 => 71,  221 => 70,  220 => 69,  214 => 66,  213 => 64,  212 => 63,  211 => 62,  205 => 59,  204 => 58,  203 => 57,  202 => 56,  201 => 55,  197 => 53,  173 => 52,  170 => 51,  167 => 50,  164 => 49,  161 => 48,  153 => 46,  151 => 45,  144 => 44,  141 => 43,  138 => 42,  135 => 41,  131 => 40,  126 => 39,  122 => 38,  117 => 35,  111 => 33,  108 => 32,  101 => 30,  96 => 28,  94 => 27,  88 => 26,  84 => 25,  79 => 23,  73 => 21,  69 => 19,  65 => 18,  56 => 15,  53 => 14,  50 => 13,  44 => 11,  42 => 10,  39 => 9,  37 => 8,  35 => 7,  33 => 6,  31 => 5,  29 => 4,  27 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{%- set static = static ?? false %}
{%- set cols = cols ?? [] %}
{%- set rows = rows ?? [] %}
{%- set initJs = not static and (initJs ?? true) -%}
{%- set minRows = minRows ?? null %}
{%- set maxRows = maxRows ?? null %}
{%- set staticRows = static or (staticRows ?? false) or (minRows == 1 and maxRows == 1 and rows|length == 1) %}
{%- set fixedRows = not staticRows and (minRows and minRows == maxRows and minRows == rows|length) %}

{% if not static %}
    <input type=\"hidden\" name=\"{{ name }}\" value=\"\">
{% endif %}

<table id=\"{{ id }}\" class=\"shadow-box editable\"
       {%- if block('attr') is defined %} {{ block('attr') }}{% endif %}>
    <thead>
        <tr>
            {% for col in cols %}
                {%- switch col.type %}
                    {%- case 'time' %}
                        {%- do view.registerAssetBundle('craft\\\\web\\\\assets\\\\timepicker\\\\TimepickerAsset') %}
                    {%- case 'template' %}
                        {%- do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\vue\\\\VueAsset\") %}
                {%- endswitch %}
                <th scope=\"col\" class=\"{{ col.class ?? '' }}\">
                    {%- if col.heading is defined and col.heading %}{{ col.heading }}{% else %}&nbsp;{% endif %}
                    {%- if col.info is defined -%}
                        <span class=\"info\">{{ col.info|md|raw }}</span>
                    {%- endif -%}
                </th>
            {% endfor %}
            {% if not staticRows %}
                <th colspan=\"{{ fixedRows ? 1 : 2 }}\"></th>
            {% endif %}
        </tr>
    </thead>
    <tbody>
        {% for rowId, row in rows %}
            <tr data-id=\"{{ rowId }}\">
                {% for colId, col in cols %}
                    {% set cell = row[colId] ?? null %}
                    {% set value = cell.value is defined ? cell.value : cell %}
                    {% if col.type == 'heading' %}
                        <th scope=\"row\" class=\"{{ cell.class ?? col.class ?? '' }}\">{{ value|raw }}</th>
                    {% elseif col.type == 'html' %}
                        <td class=\"{{ cell.class ?? col.class ?? '' }}\">{{ value|raw }}</td>
                    {% else %}
                        {% set hasErrors = cell.hasErrors ?? false %}
                        {% set cellName = name~'['~rowId~']['~colId~']' %}
                        {% set textual = (col.type in ['color', 'date', 'multiline', 'number', 'singleline', 'template', 'time']) %}
                        {% set isCode = col.code is defined or col.type == 'color' %}
                        <td class=\"{% if textual %}textual{% endif %} {% if col.class is defined %}{{ col.class }}{% endif %} {% if isCode %}code{% endif %} {% if hasErrors %}error{% endif %}\"{% if col.width is defined %} width=\"{{ col.width }}\"{% endif %}>
                            {%- switch col.type -%}
                                {%- case 'checkbox' -%}
                                    {% include \"_includes/forms/checkbox\" with {
                                        name: cellName,
                                        value:  col.value ?? 1,
                                        checked: value is not empty,
                                        disabled: static
                                    } only %}
                                {%- case 'color' -%}
                                    {% include \"_includes/forms/color\" with {
                                        name: cellName,
                                        value: value,
                                        small: true,
                                        disabled: static
                                    } only %}
                                {%- case 'date' -%}
                                    {% include \"_includes/forms/date\" with {
                                        name: cellName,
                                        value: value,
                                        disabled: static
                                    } only %}
                                {%- case 'lightswitch' -%}
                                    {% include \"_includes/forms/lightswitch\" with {
                                        name: cellName,
                                        on: value,
                                        value: col.value ?? 1,
                                        small: true,
                                        disabled: static
                                    } only %}
                                {% case 'select' -%}
                                    {% include \"_includes/forms/select\" with {
                                        class: 'small',
                                        name: cellName,
                                        options: cell.options ?? col.options,
                                        value: value,
                                        disabled: static
                                    } only %}
                                {%- case 'time' -%}
                                    {% include \"_includes/forms/time\" with {
                                        name: cellName,
                                        value: value,
                                        disabled: static
                                    } only %}
                                {%- case 'template' -%}
                                    {% include \"_includes/forms/autosuggest\" with {
                                        name: cellName,
                                        suggestions: craft.cp.getTemplateSuggestions(),
                                        value: value,
                                        disabled: static
                                    } only %}
                                {%- default -%}
                                    <textarea name=\"{{ cellName }}\" rows=\"1\"{% if static %} disabled{% endif %}{% if col.placeholder is defined %} placeholder=\"{{ col.placeholder }}\"{% endif %}>{{ value }}</textarea>
                            {%- endswitch -%}
                        </td>
                    {% endif %}
                {% endfor %}
                {% if not staticRows %}
                    <td class=\"thin action\"><a class=\"move icon\" title=\"{{ 'Reorder'|t('app') }}\"></a></td>
                    {% if not fixedRows %}<td class=\"thin action\"><a class=\"delete icon\" title=\"{{ 'Delete'|t('app') }}\"></a></td>{% endif %}
                {% endif %}
            </tr>
        {% endfor %}
    </tbody>
</table>
{% if not staticRows and not fixedRows %}
    <div class=\"btn add icon\">{{ addRowLabel is defined ? addRowLabel : \"Add a row\"|t('app') }}</div>
{% endif %}

{% if initJs %}
    {% set jsId = id|namespaceInputId|e('js') %}
    {% set jsName = name|namespaceInputName|e('js') %}
    {% set jsCols = cols|json_encode %}
    {% set defaultValues = defaultValues ?? null %}
    {% js %}
        new Craft.EditableTable(\"{{ jsId }}\", \"{{ jsName }}\", {{ jsCols|raw }}, {
            defaultValues: {{ defaultValues ? defaultValues|json_encode|raw : '{}' }},
            staticRows: {{ staticRows ? 'true' : 'false' }},
            minRows: {{ minRows ? minRows : 'null' }},
            maxRows: {{ maxRows ? maxRows : 'null' }}
        });
    {% endjs %}
{% endif %}
", "_includes/forms/editableTable", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\_includes\\forms\\editableTable.html");
    }
}
