<?php

/* typedlinkfield/_input-element */
class __TwigTemplate_530a8f9f188075c7ebad0276af56e8606e7d88623bae55ed991e480d825ece10 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_input-element", 1);
        // line 2
        echo "
<div class=\"linkfield--typeOption ";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 3, $this->source); })()), "html", null, true);
        echo (((isset($context["isSelected"]) || array_key_exists("isSelected", $context) ? $context["isSelected"] : (function () { throw new Twig_Error_Runtime('Variable "isSelected" does not exist.', 3, $this->source); })())) ? ("") : (" hidden"));
        echo "\">
  ";
        // line 4
        if ((isset($context["disabled"]) || array_key_exists("disabled", $context) ? $context["disabled"] : (function () { throw new Twig_Error_Runtime('Variable "disabled" does not exist.', 4, $this->source); })())) {
            // line 5
            echo "    <div class=\"elementselect\">
      <div class=\"elements\">
        ";
            // line 7
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["selectFieldOptions"]) || array_key_exists("selectFieldOptions", $context) ? $context["selectFieldOptions"] : (function () { throw new Twig_Error_Runtime('Variable "selectFieldOptions" does not exist.', 7, $this->source); })()), "elements", []));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["element"]) {
                // line 8
                echo "          ";
                $this->loadTemplate("_elements/element", "typedlinkfield/_input-element", 8)->display(array_merge($context, ["context" => "field", "size" => "small"]));
                // line 12
                echo "        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['element'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 13
            echo "      </div>
    </div>
  ";
        } else {
            // line 16
            echo "    ";
            if ((isset($context["queryFieldOptions"]) || array_key_exists("queryFieldOptions", $context) ? $context["queryFieldOptions"] : (function () { throw new Twig_Error_Runtime('Variable "queryFieldOptions" does not exist.', 16, $this->source); })())) {
                // line 17
                echo "      <div class=\"linkfield--elementRow\">
        <div class=\"linkfield--elementRowSelect\">
          ";
                // line 19
                echo $context["forms"]->macro_elementSelect((isset($context["selectFieldOptions"]) || array_key_exists("selectFieldOptions", $context) ? $context["selectFieldOptions"] : (function () { throw new Twig_Error_Runtime('Variable "selectFieldOptions" does not exist.', 19, $this->source); })()));
                echo "
        </div>
        <div class=\"linkfield--elementRowQuery\">
          ";
                // line 22
                echo $context["forms"]->macro_text((isset($context["queryFieldOptions"]) || array_key_exists("queryFieldOptions", $context) ? $context["queryFieldOptions"] : (function () { throw new Twig_Error_Runtime('Variable "queryFieldOptions" does not exist.', 22, $this->source); })()));
                echo "
        </div>
      </div>
    ";
            } else {
                // line 26
                echo "      ";
                echo $context["forms"]->macro_elementSelect((isset($context["selectFieldOptions"]) || array_key_exists("selectFieldOptions", $context) ? $context["selectFieldOptions"] : (function () { throw new Twig_Error_Runtime('Variable "selectFieldOptions" does not exist.', 26, $this->source); })()));
                echo "
    ";
            }
            // line 28
            echo "  ";
        }
        // line 29
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_input-element";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  107 => 29,  104 => 28,  98 => 26,  91 => 22,  85 => 19,  81 => 17,  78 => 16,  73 => 13,  59 => 12,  56 => 8,  39 => 7,  35 => 5,  33 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

<div class=\"linkfield--typeOption {{ linkTypeName }}{{ isSelected ? '' : ' hidden' }}\">
  {% if disabled %}
    <div class=\"elementselect\">
      <div class=\"elements\">
        {% for element in selectFieldOptions.elements %}
          {% include \"_elements/element\" with {
            context: 'field',
            size: 'small'
          } %}
        {% endfor %}
      </div>
    </div>
  {% else %}
    {% if queryFieldOptions %}
      <div class=\"linkfield--elementRow\">
        <div class=\"linkfield--elementRowSelect\">
          {{ forms.elementSelect(selectFieldOptions) }}
        </div>
        <div class=\"linkfield--elementRowQuery\">
          {{ forms.text(queryFieldOptions) }}
        </div>
      </div>
    {% else %}
      {{ forms.elementSelect(selectFieldOptions) }}
    {% endif %}
  {% endif %}
</div>
", "typedlinkfield/_input-element", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_input-element.twig");
    }
}
