<?php

/* typedlinkfield/_settings-site */
class __TwigTemplate_f75a3c9c1937cbc457c80460f48fb7ec80bafd2736ec4a8ed76a9a79313a5687 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_settings-site", 1);
        // line 2
        echo "
";
        // line 3
        echo $context["forms"]->macro_checkboxSelectField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Sites", "typedlinkfield"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select the available sites.", "typedlinkfield"), "id" => (("typeSettings-" .         // line 6
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 6, $this->source); })())) . "-sites"), "name" => (("typeSettings[" .         // line 7
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 7, $this->source); })())) . "][sites]"), "options" =>         // line 8
(isset($context["siteOptions"]) || array_key_exists("siteOptions", $context) ? $context["siteOptions"] : (function () { throw new Twig_Error_Runtime('Variable "siteOptions" does not exist.', 8, $this->source); })()), "values" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 9
($context["settings"] ?? null), "sites", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["settings"] ?? null), "sites", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["settings"] ?? null), "sites", [])) : (null)), "showAllOption" => true]);
        // line 11
        echo "
";
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_settings-site";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 11,  32 => 9,  31 => 8,  30 => 7,  29 => 6,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{{ forms.checkboxSelectField({
  label: 'Sites'|t('typedlinkfield'),
  instructions: 'Select the available sites.'|t('typedlinkfield'),
  id: 'typeSettings-'~linkTypeName~'-sites',
  name: 'typeSettings['~linkTypeName~'][sites]',
  options: siteOptions,
  values: settings.sites ?? null,
  showAllOption: true,
})}}
", "typedlinkfield/_settings-site", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_settings-site.twig");
    }
}
