<?php

/* _components/callToAction/defaulr.twig */
class __TwigTemplate_b320270441d9feb09ea5935d626027e9faed4dff684b20bdd2b779361cd6a0f8 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"component-container\">
    <div class=\"cta\">
        <div class=\"container content\">
            <div class=\"row\">
                <div class=\"col-8\">
                    <h2>
                        ";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 7, $this->source); })()), "heading", []), "html", null, true);
        echo "</h2>
                    <p>
                        ";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 9, $this->source); })()), "description", []), "html", null, true);
        echo "</p>
                </div>
                <div class=\"col-4\">
                    ";
        // line 12
        if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 12, $this->source); })()), "button", []), "isEmpty", [], "method")) {
            // line 13
            echo "                        <a class=\"btn-secondary\" href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 13, $this->source); })()), "button", []), "getUrl", [], "method"), "html", null, true);
            echo "\">
                            ";
            // line 14
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 14, $this->source); })()), "button", []), "getText", [], "method"), "html", null, true);
            echo "</a>
                    ";
        }
        // line 16
        echo "                </div>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/callToAction/defaulr.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 16,  49 => 14,  44 => 13,  42 => 12,  36 => 9,  31 => 7,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"component-container\">
    <div class=\"cta\">
        <div class=\"container content\">
            <div class=\"row\">
                <div class=\"col-8\">
                    <h2>
                        {{ component.heading }}</h2>
                    <p>
                        {{ component.description }}</p>
                </div>
                <div class=\"col-4\">
                    {% if not component.button.isEmpty() %}
                        <a class=\"btn-secondary\" href=\"{{ component.button.getUrl() }}\">
                            {{ component.button.getText() }}</a>
                    {% endif %}
                </div>
            </div>
        </div>
    </div>
</div>", "_components/callToAction/defaulr.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\callToAction\\defaulr.twig");
    }
}
