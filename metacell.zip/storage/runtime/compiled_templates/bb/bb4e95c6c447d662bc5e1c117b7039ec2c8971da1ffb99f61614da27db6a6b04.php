<?php

/* _macros/image */
class __TwigTemplate_acf1d87124f40872ffdf111c47501613d4accc11032a6844d99a1af38fef8419 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 33
        echo "        ";
        // line 53
        echo "    ";
    }

    // line 1
    public function macro_image($__image__ = null, $__options__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "image" => $__image__,
            "options" => $__options__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 2
            echo "    ";
            $context["class"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "class", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "class", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "class", [])) : (""));
            // line 3
            echo "    ";
            $context["mode"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "mode", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "mode", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "mode", [])) : ("crop"));
            // line 4
            echo "    ";
            $context["ratio"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "ratio", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "ratio", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "ratio", [])) : ((16 / 9)));
            // line 5
            echo "    ";
            $context["format"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "format", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "format", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "format", [])) : ("jpg"));
            // line 6
            echo "    ";
            $context["quality"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "quality", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "quality", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "quality", [])) : (80));
            // line 7
            echo "    ";
            $context["sizes"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "sizes", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "sizes", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "sizes", [])) : ("100vw"));
            // line 8
            echo "    ";
            $context["srcset"] = (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "srcset", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "srcset", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["options"] ?? null), "srcset", [])) : ([0 => ["width" => 1600], 1 => ["width" => 1200], 2 => ["width" => 960, "ratio" => (16 / 10), "jpegQuality" => 65], 3 => ["width" => 640, "ratio" => (16 / 10), "jpegQuality" => 65]]));
            // line 14
            echo "    ";
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 14, $this->source); })()), "getExtension", [], "method") != "svg")) {
                // line 15
                echo "        ";
                $context["transformedImages"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 15, $this->source); })()), "imager", []), "transformImage", [0 => (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 15, $this->source); })()), 1 =>                 // line 16
(isset($context["srcset"]) || array_key_exists("srcset", $context) ? $context["srcset"] : (function () { throw new Twig_Error_Runtime('Variable "srcset" does not exist.', 16, $this->source); })()), 2 => ["ratio" =>                 // line 18
(isset($context["ratio"]) || array_key_exists("ratio", $context) ? $context["ratio"] : (function () { throw new Twig_Error_Runtime('Variable "ratio" does not exist.', 18, $this->source); })()), "mode" =>                 // line 19
(isset($context["mode"]) || array_key_exists("mode", $context) ? $context["mode"] : (function () { throw new Twig_Error_Runtime('Variable "mode" does not exist.', 19, $this->source); })()), "format" =>                 // line 20
(isset($context["format"]) || array_key_exists("format", $context) ? $context["format"] : (function () { throw new Twig_Error_Runtime('Variable "format" does not exist.', 20, $this->source); })()), "allowUpscale" => false, "mode" => "crop", "jpegQuality" =>                 // line 23
(isset($context["quality"]) || array_key_exists("quality", $context) ? $context["quality"] : (function () { throw new Twig_Error_Runtime('Variable "quality" does not exist.', 23, $this->source); })()), "position" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 24
(isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 24, $this->source); })()), "getFocalPoint", [0 => true], "method"), "interlace" => true]], "method");
                // line 28
                echo "        <img class=\"lazyload ";
                echo twig_escape_filter($this->env, (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new Twig_Error_Runtime('Variable "class" does not exist.', 28, $this->source); })()), "html", null, true);
                echo "\" data-src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["transformedImages"]) || array_key_exists("transformedImages", $context) ? $context["transformedImages"] : (function () { throw new Twig_Error_Runtime('Variable "transformedImages" does not exist.', 28, $this->source); })()), 0, [], "array"), "url", []), "html", null, true);
                echo "\" srcset=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 28, $this->source); })()), "imager", []), "placeholder", [0 => ["width" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["transformedImages"]) || array_key_exists("transformedImages", $context) ? $context["transformedImages"] : (function () { throw new Twig_Error_Runtime('Variable "transformedImages" does not exist.', 28, $this->source); })()), 0, [], "array"), "width", []), "height" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["transformedImages"]) || array_key_exists("transformedImages", $context) ? $context["transformedImages"] : (function () { throw new Twig_Error_Runtime('Variable "transformedImages" does not exist.', 28, $this->source); })()), 0, [], "array"), "height", [])]], "method"), "html", null, true);
                echo "\" data-srcset=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 28, $this->source); })()), "imager", []), "srcset", [0 => (isset($context["transformedImages"]) || array_key_exists("transformedImages", $context) ? $context["transformedImages"] : (function () { throw new Twig_Error_Runtime('Variable "transformedImages" does not exist.', 28, $this->source); })())], "method"), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 28, $this->source); })()), "title", []), "html", null, true);
                echo "\">
            ";
            } else {
                // line 30
                echo "            <img class=\"lazyload ";
                echo twig_escape_filter($this->env, (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new Twig_Error_Runtime('Variable "class" does not exist.', 30, $this->source); })()), "html", null, true);
                echo "\" data-src=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 30, $this->source); })()), "url", []), "html", null, true);
                echo "\" data-srcset=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 30, $this->source); })()), "url", []), "html", null, true);
                echo "\" alt=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 30, $this->source); })()), "title", []), "html", null, true);
                echo "\">
            ";
            }
            // line 32
            echo "        ";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    // line 33
    public function macro_background($__image__ = null, ...$__varargs__)
    {
        $context = $this->env->mergeGlobals([
            "image" => $__image__,
            "varargs" => $__varargs__,
        ]);

        $blocks = [];

        ob_start();
        try {
            // line 34
            echo "            ";
            $context["transformedImages"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 34, $this->source); })()), "imager", []), "transformImage", [0 => (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 34, $this->source); })()), 1 => [0 => ["width" => 1600], 1 => ["width" => 1200], 2 => ["width" => 960, "ratio" => (16 / 10), "jpegQuality" => 65], 3 => ["width" => 640, "ratio" => (16 / 10), "jpegQuality" => 65]], 2 => ["format" => "jpg", "allowUpscale" => false, "mode" => "crop", "jpegQuality" => 80, "position" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 46
(isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 46, $this->source); })()), "getFocalPoint", [0 => true], "method"), "interlace" => true]], "method");
            // line 50
            echo "            style=\"background-image: url('";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["transformedImages"]) || array_key_exists("transformedImages", $context) ? $context["transformedImages"] : (function () { throw new Twig_Error_Runtime('Variable "transformedImages" does not exist.', 50, $this->source); })()), 1, [], "array"), "url", []), "html", null, true);
            echo "'); background-position:
            ";
            // line 51
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["image"]) || array_key_exists("image", $context) ? $context["image"] : (function () { throw new Twig_Error_Runtime('Variable "image" does not exist.', 51, $this->source); })()), "getFocalPoint", [0 => true], "method"), "html", null, true);
            echo "\"
        ";

            return ('' === $tmp = ob_get_contents()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
        } finally {
            ob_end_clean();
        }
    }

    public function getTemplateName()
    {
        return "_macros/image";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 51,  126 => 50,  124 => 46,  122 => 34,  110 => 33,  101 => 32,  89 => 30,  75 => 28,  73 => 24,  72 => 23,  71 => 20,  70 => 19,  69 => 18,  68 => 16,  66 => 15,  63 => 14,  60 => 8,  57 => 7,  54 => 6,  51 => 5,  48 => 4,  45 => 3,  42 => 2,  29 => 1,  25 => 53,  23 => 33,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% macro image(image, options) %}
    {% set class = options.class ?? '' %}
    {% set mode = options.mode ?? 'crop' %}
    {% set ratio = options.ratio ?? (16/9) %}
    {% set format = options.format ?? 'jpg' %}
    {% set quality = options.quality ?? 80 %}
    {% set sizes = options.sizes ?? '100vw' %}
    {% set srcset = options.srcset ?? [
    { width: 1600 },
    { width: 1200 },
    { width: 960, ratio: 16/10, jpegQuality: 65 },
    { width: 640, ratio: 16/10, jpegQuality: 65 },
  ] %}
    {% if image.getExtension() != \"svg\" %}
        {% set transformedImages = craft.imager.transformImage(image,
      srcset,
      {
        ratio: ratio,
        mode: mode,
        format: format,
        allowUpscale: false,
        mode: 'crop',
        jpegQuality: quality,
        position: image.getFocalPoint(true),
        interlace: true
      }
    ) %}
        <img class=\"lazyload {{ class }}\" data-src=\"{{ transformedImages[0].url }}\" srcset=\"{{ craft.imager.placeholder({ width: transformedImages[0].width, height: transformedImages[0].height }) }}\" data-srcset=\"{{ craft.imager.srcset(transformedImages) }}\" alt=\"{{ image.title }}\">
            {% else %}
            <img class=\"lazyload {{ class }}\" data-src=\"{{ image.url }}\" data-srcset=\"{{ image.url }}\" alt=\"{{ image.title }}\">
            {% endif %}
        {% endmacro %}
        {% macro background(image) %}
            {% set transformedImages = craft.imager.transformImage(image,
    [
      { width: 1600 },
      { width: 1200 },
      { width: 960, ratio: 16/10, jpegQuality: 65 },
      { width: 640, ratio: 16/10, jpegQuality: 65 },
    ],
    {
        format: 'jpg',
        allowUpscale: false,
        mode: 'crop',
        jpegQuality: 80,
        position: image.getFocalPoint(true),
        interlace: true
    }
  ) %}
            style=\"background-image: url('{{ transformedImages[1].url }}'); background-position:
            {{ image.getFocalPoint(true) }}\"
        {% endmacro %}
    ", "_macros/image", "E:\\Code\\Craft\\metacell\\templates\\_macros\\image.twig");
    }
}
