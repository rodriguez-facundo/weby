<?php

/* partials/_header */
class __TwigTemplate_b0acc9ee5672132e5efaebb0f42ad116b888b5f9ed176d25077b60e8f24749ec extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"header \">
    <div class=\"container\">
        <div class=\"header-inner\">
            <h1 class=\"logo\">
                <a href=\"#\">MetaCell</a>
            </h1>
            <nav>
                <a class=\"active\" href=\"#\">Our Company</a>
                <a href=\"#\">Our Platform</a>
                <a href=\"#\">Our Service</a>
                <a href=\"#\">Our Services</a>
                <a href=\"#\">Resources</a>
                <a href=\"#\">Joins Us</a>
                <a href=\"#\">Contact Us</a>
                <a class=\"btn-primary\" href=\"#\">Request a quote</a>
            </nav>
            <button class=\"menu-trigger\">
                <span class=\"triger-item\"></span>
                <span class=\"triger-item\"></span>
                <span class=\"triger-item\"></span>
            </button>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "partials/_header";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"header \">
    <div class=\"container\">
        <div class=\"header-inner\">
            <h1 class=\"logo\">
                <a href=\"#\">MetaCell</a>
            </h1>
            <nav>
                <a class=\"active\" href=\"#\">Our Company</a>
                <a href=\"#\">Our Platform</a>
                <a href=\"#\">Our Service</a>
                <a href=\"#\">Our Services</a>
                <a href=\"#\">Resources</a>
                <a href=\"#\">Joins Us</a>
                <a href=\"#\">Contact Us</a>
                <a class=\"btn-primary\" href=\"#\">Request a quote</a>
            </nav>
            <button class=\"menu-trigger\">
                <span class=\"triger-item\"></span>
                <span class=\"triger-item\"></span>
                <span class=\"triger-item\"></span>
            </button>
        </div>
    </div>
</div>", "partials/_header", "E:\\Code\\Craft\\metacell\\templates\\partials\\_header.twig");
    }
}
