<?php

/* _components/utilities/SystemReport */
class __TwigTemplate_b5393af750f3c15b184853d444a723bd7e9b8f052a26b0313ecf9f481a53a9e0 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"readable\">
    <h2>";
        // line 2
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Application Info", "app"), "html", null, true);
        echo "</h2>

    <table class=\"data fullwidth fixed-layout\" dir=\"ltr\">
        <tbody>
            ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["appInfo"]) || array_key_exists("appInfo", $context) ? $context["appInfo"] : (function () { throw new Twig_Error_Runtime('Variable "appInfo" does not exist.', 6, $this->source); })()));
        foreach ($context['_seq'] as $context["label"] => $context["value"]) {
            // line 7
            echo "                <tr>
                    <th class=\"light\">";
            // line 8
            echo twig_escape_filter($this->env, $context["label"], "html", null, true);
            echo "</th>
                    <td>";
            // line 9
            echo twig_escape_filter($this->env, $context["value"], "html", null, true);
            echo "</td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['label'], $context['value'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "        </tbody>
    </table>

    <h2>";
        // line 15
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Plugins", "app"), "html", null, true);
        echo "</h2>

    ";
        // line 17
        if (twig_length_filter($this->env, (isset($context["plugins"]) || array_key_exists("plugins", $context) ? $context["plugins"] : (function () { throw new Twig_Error_Runtime('Variable "plugins" does not exist.', 17, $this->source); })()))) {
            // line 18
            echo "        <table class=\"data fullwidth fixed-layout\" dir=\"ltr\">
            <tbody>
                ";
            // line 20
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["plugins"]) || array_key_exists("plugins", $context) ? $context["plugins"] : (function () { throw new Twig_Error_Runtime('Variable "plugins" does not exist.', 20, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["plugin"]) {
                // line 21
                echo "                    <tr>
                        <th class=\"light\">";
                // line 22
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["plugin"], "name", []), "html", null, true);
                echo "</th>
                        <td>";
                // line 23
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["plugin"], "version", []), "html", null, true);
                echo "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['plugin'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo "            </tbody>
        </table>
    ";
        } else {
            // line 29
            echo "        <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No plugins are enabled.", "app"), "html", null, true);
            echo "</p>
    ";
        }
        // line 31
        echo "
    <h2>";
        // line 32
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Modules", "app"), "html", null, true);
        echo "</h2>

    ";
        // line 34
        if (twig_length_filter($this->env, (isset($context["modules"]) || array_key_exists("modules", $context) ? $context["modules"] : (function () { throw new Twig_Error_Runtime('Variable "modules" does not exist.', 34, $this->source); })()))) {
            // line 35
            echo "        <table class=\"data fullwidth fixed-layout\" dir=\"ltr\">
            <tbody>
                ";
            // line 37
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["modules"]) || array_key_exists("modules", $context) ? $context["modules"] : (function () { throw new Twig_Error_Runtime('Variable "modules" does not exist.', 37, $this->source); })()));
            foreach ($context['_seq'] as $context["id"] => $context["class"]) {
                // line 38
                echo "                    <tr>
                        <th class=\"light\">";
                // line 39
                echo twig_escape_filter($this->env, $context["id"], "html", null, true);
                echo "</th>
                        <td>";
                // line 40
                echo twig_escape_filter($this->env, $context["class"], "html", null, true);
                echo "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['id'], $context['class'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 43
            echo "            </tbody>
        </table>
    ";
        } else {
            // line 46
            echo "        <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No modules are installed.", "app"), "html", null, true);
            echo "</p>
    ";
        }
        // line 48
        echo "
    <h2>";
        // line 49
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Requirements", "app"), "html", null, true);
        echo "</h2>

    <table class=\"data fullwidth\" dir=\"ltr\">
        <tbody>
        ";
        // line 53
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["requirements"]) || array_key_exists("requirements", $context) ? $context["requirements"] : (function () { throw new Twig_Error_Runtime('Variable "requirements" does not exist.', 53, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["requirement"]) {
            // line 54
            echo "            <tr>
                <td class=\"thin centeralign\">
                    ";
            // line 56
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "error", [])) {
                // line 57
                echo "                        <span class=\"error\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Failed", "app"), "html", null, true);
                echo "\" data-icon=\"error\"></span>
                    ";
            } elseif (craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 58
$context["requirement"], "warning", [])) {
                // line 59
                echo "                        <span class=\"warning\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Passed with warning", "app"), "html", null, true);
                echo "\" data-icon=\"alert\"></span>
                    ";
            } else {
                // line 61
                echo "                        <span class=\"success\" title=\"";
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Passed", "app"), "html", null, true);
                echo "\" data-icon=\"check\"></span>
                    ";
            }
            // line 63
            echo "                </td>
                <td>";
            // line 64
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "name", []), "html", null, true);
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "memo", [])) {
                echo " <span class=\"info\">";
                echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["requirement"], "memo", []);
                echo "</span>";
            }
            echo "</td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['requirement'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "        </tbody>
    </table>
</div>
";
    }

    public function getTemplateName()
    {
        return "_components/utilities/SystemReport";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  201 => 67,  187 => 64,  184 => 63,  178 => 61,  172 => 59,  170 => 58,  165 => 57,  163 => 56,  159 => 54,  155 => 53,  148 => 49,  145 => 48,  139 => 46,  134 => 43,  125 => 40,  121 => 39,  118 => 38,  114 => 37,  110 => 35,  108 => 34,  103 => 32,  100 => 31,  94 => 29,  89 => 26,  80 => 23,  76 => 22,  73 => 21,  69 => 20,  65 => 18,  63 => 17,  58 => 15,  53 => 12,  44 => 9,  40 => 8,  37 => 7,  33 => 6,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"readable\">
    <h2>{{ \"Application Info\"|t('app') }}</h2>

    <table class=\"data fullwidth fixed-layout\" dir=\"ltr\">
        <tbody>
            {% for label, value in appInfo %}
                <tr>
                    <th class=\"light\">{{ label }}</th>
                    <td>{{ value }}</td>
                </tr>
            {% endfor %}
        </tbody>
    </table>

    <h2>{{ \"Plugins\"|t('app') }}</h2>

    {% if plugins|length %}
        <table class=\"data fullwidth fixed-layout\" dir=\"ltr\">
            <tbody>
                {% for plugin in plugins %}
                    <tr>
                        <th class=\"light\">{{ plugin.name }}</th>
                        <td>{{ plugin.version }}</td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    {% else %}
        <p>{{ 'No plugins are enabled.'|t('app') }}</p>
    {% endif %}

    <h2>{{ 'Modules'|t('app') }}</h2>

    {% if modules|length %}
        <table class=\"data fullwidth fixed-layout\" dir=\"ltr\">
            <tbody>
                {% for id, class in modules %}
                    <tr>
                        <th class=\"light\">{{ id }}</th>
                        <td>{{ class }}</td>
                    </tr>
                {% endfor %}
            </tbody>
        </table>
    {% else %}
        <p>{{ 'No modules are installed.'|t('app') }}</p>
    {% endif %}

    <h2>{{ \"Requirements\"|t('app') }}</h2>

    <table class=\"data fullwidth\" dir=\"ltr\">
        <tbody>
        {% for requirement in requirements %}
            <tr>
                <td class=\"thin centeralign\">
                    {% if requirement.error %}
                        <span class=\"error\" title=\"{{ 'Failed'|t('app') }}\" data-icon=\"error\"></span>
                    {% elseif requirement.warning %}
                        <span class=\"warning\" title=\"{{ 'Passed with warning'|t('app') }}\" data-icon=\"alert\"></span>
                    {% else %}
                        <span class=\"success\" title=\"{{ 'Passed'|t('app') }}\" data-icon=\"check\"></span>
                    {% endif %}
                </td>
                <td>{{ requirement.name }}{% if requirement.memo %} <span class=\"info\">{{ requirement.memo|raw }}</span>{% endif %}</td>
            </tr>
        {% endfor %}
        </tbody>
    </table>
</div>
", "_components/utilities/SystemReport", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\_components\\utilities\\SystemReport.html");
    }
}
