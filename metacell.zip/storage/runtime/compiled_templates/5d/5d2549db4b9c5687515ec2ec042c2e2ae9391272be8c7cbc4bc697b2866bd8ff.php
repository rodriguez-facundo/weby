<?php

/* _components/pageTitle/default.twig */
class __TwigTemplate_3b64f48b37cfadb206b4e2e19b772a9cf29ccd7c7fac2b5ad0560681d177fad2 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"component-container\">
    <div class=\"page-title\">
        <div class=\"spacing-both-lg\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-6\">
                        <h1>";
        // line 7
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 7, $this->source); })()), "heading", []), "html", null, true);
        echo "</h1>
                    </div>
                    <div class=\"col-6\">
                        <h4>";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 10, $this->source); })()), "description", []), "html", null, true);
        echo "</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/pageTitle/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 10,  31 => 7,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"component-container\">
    <div class=\"page-title\">
        <div class=\"spacing-both-lg\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-6\">
                        <h1>{{ component.heading }}</h1>
                    </div>
                    <div class=\"col-6\">
                        <h4>{{ component.description }}</h4>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>", "_components/pageTitle/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\pageTitle\\default.twig");
    }
}
