<?php

/* super-table/row/fields */
class __TwigTemplate_9b820d0c3a2f550c268085214f9b3f832b75bb89aed060dab2630c6215844144 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        if ( !(isset($context["element"]) || array_key_exists("element", $context))) {
            $context["element"] = null;
        }
        // line 2
        if ( !(isset($context["namespace"]) || array_key_exists("namespace", $context))) {
            $context["namespace"] = "fields";
        }
        // line 3
        echo "
";
        // line 4
        $_namespace = (isset($context["namespace"]) || array_key_exists("namespace", $context) ? $context["namespace"] : (function () { throw new Twig_Error_Runtime('Variable "namespace" does not exist.', 4, $this->source); })());
        if ($_namespace) {
            $_originalNamespace = Craft::$app->getView()->getNamespace();
            Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
            ob_start();
            try {
                // line 5
                echo "    ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 5, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                    // line 6
                    echo "        ";
                    $context["translatable"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getIsTranslatable", [], "method");
                    // line 7
                    echo "
        ";
                    // line 8
                    if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new Twig_Error_Runtime('Variable "translatable" does not exist.', 8, $this->source); })())) {
                        // line 9
                        echo "            ";
                        switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "translationMethod", [])) {
                            case "site":
                            {
                                // line 11
                                echo "                ";
                                $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site.", "app");
                                // line 12
                                echo "            ";
                                break;
                            }
                            case "siteGroup":
                            {
                                // line 13
                                echo "                ";
                                $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site group.", "app");
                                // line 14
                                echo "            ";
                                break;
                            }
                            case "language":
                            {
                                // line 15
                                echo "                ";
                                $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each language.", "app");
                                // line 16
                                echo "            ";
                                break;
                            }
                        }
                        // line 17
                        echo "        ";
                    }
                    // line 18
                    echo "
        <tr data-id=\"\">
            <td class=\"thin rowHeader\">
                <span class=\"heading-text ";
                    // line 21
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "required", [])) {
                        echo "required";
                    }
                    echo "\">
                    ";
                    // line 22
                    echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", []), "site"), "html", null, true);
                    echo "

                    ";
                    // line 24
                    if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", [])) {
                        // line 25
                        echo "                        <span class=\"info\">";
                        echo $this->extensions['craft\web\twig\Extension']->markdownFilter($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", []), "site"));
                        echo "</span>
                    ";
                    }
                    // line 27
                    echo "
                    ";
                    // line 28
                    if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new Twig_Error_Runtime('Variable "translatable" does not exist.', 28, $this->source); })())) {
                        // line 29
                        echo "                        <span class=\"extralight\" data-icon=\"language\" title=\"";
                        echo twig_escape_filter($this->env, (($context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app"))), "html", null, true);
                        echo "\"></span>
                    ";
                    }
                    // line 31
                    echo "                </span>
            </td>

            <td>
                ";
                    // line 35
                    $this->loadTemplate("super-table/field", "super-table/row/fields", 35)->display(["field" =>                     // line 36
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 37
$context["field"], "required", []), "element" =>                     // line 38
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new Twig_Error_Runtime('Variable "element" does not exist.', 38, $this->source); })()), "static" => ((                    // line 39
(isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 39, $this->source); })())) : (null))]);
                    // line 41
                    echo "            </td>

            ";
                    // line 43
                    if ( !(isset($context["staticField"]) || array_key_exists("staticField", $context) ? $context["staticField"] : (function () { throw new Twig_Error_Runtime('Variable "staticField" does not exist.', 43, $this->source); })())) {
                        // line 44
                        echo "                <td class=\"thin placeholder\"></td>
            ";
                    }
                    // line 46
                    echo "        </tr>
    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
            } catch (Exception $e) {
                ob_end_clean();

                throw $e;
            }
            echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
            Craft::$app->getView()->setNamespace($_originalNamespace);
        } else {
            // line 5
            echo "    ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["fields"]) || array_key_exists("fields", $context) ? $context["fields"] : (function () { throw new Twig_Error_Runtime('Variable "fields" does not exist.', 5, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 6
                echo "        ";
                $context["translatable"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "getIsTranslatable", [], "method");
                // line 7
                echo "
        ";
                // line 8
                if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new Twig_Error_Runtime('Variable "translatable" does not exist.', 8, $this->source); })())) {
                    // line 9
                    echo "            ";
                    switch (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "translationMethod", [])) {
                        case "site":
                        {
                            // line 11
                            echo "                ";
                            $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site.", "app");
                            // line 12
                            echo "            ";
                            break;
                        }
                        case "siteGroup":
                        {
                            // line 13
                            echo "                ";
                            $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each site group.", "app");
                            // line 14
                            echo "            ";
                            break;
                        }
                        case "language":
                        {
                            // line 15
                            echo "                ";
                            $context["translationDescription"] = $this->extensions['craft\web\twig\Extension']->translateFilter("This field is translated for each language.", "app");
                            // line 16
                            echo "            ";
                            break;
                        }
                    }
                    // line 17
                    echo "        ";
                }
                // line 18
                echo "
        <tr data-id=\"\">
            <td class=\"thin rowHeader\">
                <span class=\"heading-text ";
                // line 21
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "required", [])) {
                    echo "required";
                }
                echo "\">
                    ";
                // line 22
                echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "name", []), "site"), "html", null, true);
                echo "

                    ";
                // line 24
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", [])) {
                    // line 25
                    echo "                        <span class=\"info\">";
                    echo $this->extensions['craft\web\twig\Extension']->markdownFilter($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["field"], "instructions", []), "site"));
                    echo "</span>
                    ";
                }
                // line 27
                echo "
                    ";
                // line 28
                if ((isset($context["translatable"]) || array_key_exists("translatable", $context) ? $context["translatable"] : (function () { throw new Twig_Error_Runtime('Variable "translatable" does not exist.', 28, $this->source); })())) {
                    // line 29
                    echo "                        <span class=\"extralight\" data-icon=\"language\" title=\"";
                    echo twig_escape_filter($this->env, (($context["translationDescription"]) ?? ($this->extensions['craft\web\twig\Extension']->translateFilter("This field is translatable.", "app"))), "html", null, true);
                    echo "\"></span>
                    ";
                }
                // line 31
                echo "                </span>
            </td>

            <td>
                ";
                // line 35
                $this->loadTemplate("super-table/field", "super-table/row/fields", 35)->display(["field" =>                 // line 36
$context["field"], "required" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 37
$context["field"], "required", []), "element" =>                 // line 38
(isset($context["element"]) || array_key_exists("element", $context) ? $context["element"] : (function () { throw new Twig_Error_Runtime('Variable "element" does not exist.', 38, $this->source); })()), "static" => ((                // line 39
(isset($context["static"]) || array_key_exists("static", $context))) ? ((isset($context["static"]) || array_key_exists("static", $context) ? $context["static"] : (function () { throw new Twig_Error_Runtime('Variable "static" does not exist.', 39, $this->source); })())) : (null))]);
                // line 41
                echo "            </td>

            ";
                // line 43
                if ( !(isset($context["staticField"]) || array_key_exists("staticField", $context) ? $context["staticField"] : (function () { throw new Twig_Error_Runtime('Variable "staticField" does not exist.', 43, $this->source); })())) {
                    // line 44
                    echo "                <td class=\"thin placeholder\"></td>
            ";
                }
                // line 46
                echo "        </tr>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        unset($_originalNamespace, $_namespace);
    }

    public function getTemplateName()
    {
        return "super-table/row/fields";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  264 => 46,  260 => 44,  258 => 43,  254 => 41,  252 => 39,  251 => 38,  250 => 37,  249 => 36,  248 => 35,  242 => 31,  236 => 29,  234 => 28,  231 => 27,  225 => 25,  223 => 24,  218 => 22,  212 => 21,  207 => 18,  204 => 17,  199 => 16,  196 => 15,  190 => 14,  187 => 13,  181 => 12,  178 => 11,  173 => 9,  171 => 8,  168 => 7,  165 => 6,  160 => 5,  145 => 46,  141 => 44,  139 => 43,  135 => 41,  133 => 39,  132 => 38,  131 => 37,  130 => 36,  129 => 35,  123 => 31,  117 => 29,  115 => 28,  112 => 27,  106 => 25,  104 => 24,  99 => 22,  93 => 21,  88 => 18,  85 => 17,  80 => 16,  77 => 15,  71 => 14,  68 => 13,  62 => 12,  59 => 11,  54 => 9,  52 => 8,  49 => 7,  46 => 6,  41 => 5,  34 => 4,  31 => 3,  27 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% if element is not defined %}{% set element = null %}{% endif %}
{% if namespace is not defined %}{% set namespace = 'fields' %}{% endif %}

{% namespace namespace %}
    {% for field in fields %}
        {% set translatable = field.getIsTranslatable() %}

        {% if translatable %}
            {% switch field.translationMethod %}
            {% case 'site' %}
                {% set translationDescription = 'This field is translated for each site.'|t('app') %}
            {% case 'siteGroup' %}
                {% set translationDescription = 'This field is translated for each site group.'|t('app') %}
            {% case 'language' %}
                {% set translationDescription = 'This field is translated for each language.'|t('app') %}
            {% endswitch %}
        {% endif %}

        <tr data-id=\"\">
            <td class=\"thin rowHeader\">
                <span class=\"heading-text {% if field.required %}required{% endif %}\">
                    {{ field.name | t('site') }}

                    {% if field.instructions %}
                        <span class=\"info\">{{ field.instructions | t('site') | md | raw }}</span>
                    {% endif %}

                    {% if translatable %}
                        <span class=\"extralight\" data-icon=\"language\" title=\"{{ translationDescription ?? 'This field is translatable.' | t('app') }}\"></span>
                    {% endif %}
                </span>
            </td>

            <td>
                {% include \"super-table/field\" with {
                    field:    field,
                    required: field.required,
                    element:  element,
                    static:   (static is defined ? static : null)
                } only %}
            </td>

            {% if not staticField %}
                <td class=\"thin placeholder\"></td>
            {% endif %}
        </tr>
    {% endfor %}
{% endnamespace %}", "super-table/row/fields", "E:\\Code\\Craft\\metacell\\vendor\\verbb\\super-table\\src\\templates\\row\\fields.html");
    }
}
