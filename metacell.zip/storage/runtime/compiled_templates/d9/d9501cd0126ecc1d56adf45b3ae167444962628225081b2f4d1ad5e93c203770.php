<?php

/* template-select/_components/fields/_settings */
class __TwigTemplate_4b76d9e8595b7c1a83d590ae1852beb6cc423102c3ec0cf40a7a653f66fb75ca extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 14
        echo "
";
        // line 15
        $context["forms"] = $this->loadTemplate("_includes/forms", "template-select/_components/fields/_settings", 15);
        // line 16
        echo "
";
        // line 17
        echo $context["forms"]->macro_textField(["label" => "Limit to subfolder", "instructions" => "Optional path of the sub folder, i.e. _subfolder/_", "id" => "limitToSubfolder", "name" => "limitToSubfolder", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 22
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 22, $this->source); })()), "limitToSubfolder", [], "array")]);
        // line 23
        echo "
";
    }

    public function getTemplateName()
    {
        return "template-select/_components/fields/_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 23,  32 => 22,  31 => 17,  28 => 16,  26 => 15,  23 => 14,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
/**
 * Template Select plugin for Craft CMS
 *
 *  Field Settings
 *
 * @author    Superbig
 * @copyright Copyright (c) 2017 Superbig
 * @link      https://superbig.co
 * @package   TemplateSelect
 * @since     2.0.0
 */
#}

{% import \"_includes/forms\" as forms %}

{{ forms.textField({
    label: 'Limit to subfolder',
    instructions: 'Optional path of the sub folder, i.e. _subfolder/_',
    id: 'limitToSubfolder',
    name: 'limitToSubfolder',
    value: field['limitToSubfolder']})
}}
", "template-select/_components/fields/_settings", "E:\\Code\\Craft\\metacell\\vendor\\superbig\\craft3-templateselect\\src\\templates\\_components\\fields\\_settings.twig");
    }
}
