<?php

/* _components/leadImage/default.twig */
class __TwigTemplate_687830aee7db2b3ef2cb356d6e8729b84ddd4848152e43ecff6755d17292904c extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/leadImage/default.twig", 1);
        // line 2
        echo "<div class=\"component-container\">
    <div class=\"lead-image\">
        <div class=\"container\">
            <div class=\"row background-grid\">
                <div class=\"col-6\">
                    <div class=\"text-wrapper\">
                        <h1>
                            ";
        // line 9
        echo nl2br(twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 9, $this->source); })()), "headingColor1", []), "html", null, true));
        echo "<span class=\"text-blue\">
                                ";
        // line 10
        echo nl2br(twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 10, $this->source); })()), "headingColor2", []), "html", null, true));
        echo "</span>
                        </h1>
                        <p>
                            ";
        // line 13
        echo nl2br(twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 13, $this->source); })()), "description", []), "html", null, true));
        echo "
                        </p>
                        ";
        // line 15
        if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 15, $this->source); })()), "button", []), "isEmpty", [], "method")) {
            // line 16
            echo "                            <a class=\"btn-primary\" href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 16, $this->source); })()), "button", []), "getUrl", [], "method"), "html", null, true);
            echo "\">
                                ";
            // line 17
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 17, $this->source); })()), "button", []), "getText", [], "method"), "html", null, true);
            echo "</a>
                        ";
        }
        // line 19
        echo "                    </div>
                </div>
                <div class=\"image-col\">
                    <div class=\"background-image\">
                        ";
        // line 23
        echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 23, $this->source); })()), "image", []), 0, [], "array"), ["ratio" => (3 / 2), "class" => "animation", "srcset" => [0 => ["width" => 900, "jpegQuality" => 65], 1 => ["width" => 600, "jpegQuality" => 65]]]);
        // line 32
        echo "
                    </div>
                </div>
            </div>
        </div>
        <nav class=\"nav\">
            ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 38, $this->source); })()), "bottomLinks", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 39
            echo "                <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["link"], "linkTo", []), "getUrl", [], "method"), "html", null, true);
            echo "\">
                    ";
            // line 40
            echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["link"], "image", []), 0, [], "array"), ["ratio" => (1 / 1), "srcset" => [0 => ["width" => 40, "jpegQuality" => 65]]]);
            // line 47
            echo "
                    <span class=\"link-text\">
                        ";
            // line 49
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["link"], "linkTo", []), "getText", [], "method"), "html", null, true);
            echo "
                    </span>
                </a>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 53
        echo "        </nav>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/leadImage/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  102 => 53,  92 => 49,  88 => 47,  86 => 40,  81 => 39,  77 => 38,  69 => 32,  67 => 23,  61 => 19,  56 => 17,  51 => 16,  49 => 15,  44 => 13,  38 => 10,  34 => 9,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}
<div class=\"component-container\">
    <div class=\"lead-image\">
        <div class=\"container\">
            <div class=\"row background-grid\">
                <div class=\"col-6\">
                    <div class=\"text-wrapper\">
                        <h1>
                            {{ component.headingColor1|nl2br }}<span class=\"text-blue\">
                                {{ component.headingColor2|nl2br }}</span>
                        </h1>
                        <p>
                            {{ component.description|nl2br }}
                        </p>
                        {% if not component.button.isEmpty() %}
                            <a class=\"btn-primary\" href=\"{{ component.button.getUrl() }}\">
                                {{ component.button.getText() }}</a>
                        {% endif %}
                    </div>
                </div>
                <div class=\"image-col\">
                    <div class=\"background-image\">
                        {{ imageMacros.image(component.image[0], {
                                ratio: (3/2),
                                class: \"animation\",
                                srcset: [
                                    { width: 900, jpegQuality: 65 },
                                    { width: 600, jpegQuality: 65 },
                                ]
                            }
                        )   
                    }}
                    </div>
                </div>
            </div>
        </div>
        <nav class=\"nav\">
            {% for link in component.bottomLinks.all() %}
                <a href=\"{{ link.linkTo.getUrl() }}\">
                    {{ imageMacros.image(link.image[0], {
                                ratio: (1/1),
                                srcset: [
                                    { width: 40, jpegQuality: 65 },
                                ]
                            }
                        )   
                    }}
                    <span class=\"link-text\">
                        {{ link.linkTo.getText() }}
                    </span>
                </a>
            {% endfor %}
        </nav>
    </div>
</div>", "_components/leadImage/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\leadImage\\default.twig");
    }
}
