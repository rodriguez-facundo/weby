<?php

/* _components/spotlight/left.twig */
class __TwigTemplate_13757ab0b0dd374c52d84853b429f507ad4f9d0f380591134c025729712885e8 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/spotlight/left.twig", 1);
        // line 2
        echo "<div class=\"component-container\">
    <div class=\"spotlight undefined\">
        <div class=\"background-image\">
            ";
        // line 5
        echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 5, $this->source); })()), "image", []), 0, [], "array"), ["ratio" => (1 / 1), "class" => "animation", "srcset" => [0 => ["width" => 1400], 1 => ["width" => 900, "jpegQuality" => 65], 2 => ["width" => 600, "jpegQuality" => 65]]]);
        // line 15
        echo "
        </div>
        <div class=\"spotlight-inner\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-6 text-wrapper\">
                        <div class=\"text-content\">
                            <h6>
                                ";
        // line 23
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 23, $this->source); })()), "subheading", []), "html", null, true);
        echo "</h6>
                            <h2>
                                ";
        // line 25
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 25, $this->source); })()), "heading", []), "html", null, true);
        echo "</h2>
                            <p>
                                ";
        // line 27
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 27, $this->source); })()), "description", []), "html", null, true);
        echo "
                            </p>
                            ";
        // line 29
        if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 29, $this->source); })()), "button", []), "isEmpty", [], "method")) {
            // line 30
            echo "                                <a class=\"btn-primary\" href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 30, $this->source); })()), "button", []), "getUrl", [], "method"), "html", null, true);
            echo "\">
                                    ";
            // line 31
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 31, $this->source); })()), "button", []), "getText", [], "method"), "html", null, true);
            echo "</a>
                            ";
        }
        // line 33
        echo "                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/spotlight/left.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 33,  64 => 31,  59 => 30,  57 => 29,  52 => 27,  47 => 25,  42 => 23,  32 => 15,  30 => 5,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}
<div class=\"component-container\">
    <div class=\"spotlight undefined\">
        <div class=\"background-image\">
            {{ imageMacros.image(component.image[0], {
                                ratio: (1/1),
                                class: \"animation\",
                                srcset: [
                                    { width: 1400 },
                                    { width: 900, jpegQuality: 65 },
                                    { width: 600, jpegQuality: 65 },
                                ]
                            }
                        )   
                    }}
        </div>
        <div class=\"spotlight-inner\">
            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"col-6 text-wrapper\">
                        <div class=\"text-content\">
                            <h6>
                                {{ component.subheading }}</h6>
                            <h2>
                                {{ component.heading }}</h2>
                            <p>
                                {{ component.description }}
                            </p>
                            {% if not component.button.isEmpty() %}
                                <a class=\"btn-primary\" href=\"{{ component.button.getUrl() }}\">
                                    {{ component.button.getText() }}</a>
                            {% endif %}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
    </div>
</div>", "_components/spotlight/left.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\spotlight\\left.twig");
    }
}
