<?php

/* simplemap/field-input */
class __TwigTemplate_ec139c3a6de2223b81310c223480d4aa5df7a61d95ee3ab6bc6bf2716b49d016 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "simplemap/field-input", 1);
        // line 2
        echo "
<div class=\"field simplemap--address-wrap\" id=\"";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 3, $this->source); })()), "html", null, true);
        echo "-address-field\">
\t<div class=\"input ltr simplemap--address-field\">
\t\t<input class=\"text simplemap--address fullwidth\" type=\"text\"
\t\t       name=\"";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 6, $this->source); })()), "html", null, true);
        echo "[address]\" id=\"";
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 6, $this->source); })()), "html", null, true);
        echo "-address\"
\t\t       autocomplete=\"off\" placeholder=\"Address\"
\t\t       value=\"";
        // line 8
        echo twig_escape_filter($this->env, ((( !(null === (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 8, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 8, $this->source); })()), "address", []))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 8, $this->source); })()), "address", [])) : ("")), "html", null, true);
        echo "\">

\t\t<div class=\"simplemap--lat-lng";
        // line 10
        echo ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 10, $this->source); })()), "hideLatLng", [])) ? (" hidden") : (""));
        echo "\">
\t\t\t<input class=\"text fullwidth\" type=\"number\" name=\"";
        // line 11
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 11, $this->source); })()), "html", null, true);
        echo "[lat]\"
\t\t\t       width=\"19\" id=\"";
        // line 12
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 12, $this->source); })()), "html", null, true);
        echo "-input-lat\" autocomplete=\"off\"
\t\t\t       placeholder=\"Lat\" step=\"any\"
\t\t\t       value=\"";
        // line 14
        echo twig_escape_filter($this->env, ((( !(null === (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 14, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["value"] ?? null), "lat", [], "any", true, true))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 14, $this->source); })()), "lat", [])) : ("")), "html", null, true);
        echo "\">

\t\t\t<input class=\"text fullwidth\" type=\"number\" name=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 16, $this->source); })()), "html", null, true);
        echo "[lng]\"
\t\t\t       width=\"19\" id=\"";
        // line 17
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 17, $this->source); })()), "html", null, true);
        echo "-input-lng\" autocomplete=\"off\"
\t\t\t       placeholder=\"Lng\" step=\"any\"
\t\t\t       value=\"";
        // line 19
        echo twig_escape_filter($this->env, ((( !(null === (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 19, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["value"] ?? null), "lng", [], "any", true, true))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 19, $this->source); })()), "lng", [])) : ("")), "html", null, true);
        echo "\">
\t\t</div>
\t</div>
</div>

";
        // line 24
        if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 24, $this->source); })()), "hideMap", [])) {
            // line 25
            echo "\t<div
\t\tid=\"";
            // line 26
            echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 26, $this->source); })()), "html", null, true);
            echo "\"
\t\tclass=\"simplemap--map\"
\t\tstyle=\"height:";
            // line 28
            echo twig_escape_filter($this->env, (isset($context["height"]) || array_key_exists("height", $context) ? $context["height"] : (function () { throw new Twig_Error_Runtime('Variable "height" does not exist.', 28, $this->source); })()), "html", null, true);
            echo "px\"
\t></div>
";
        }
        // line 31
        echo "
<input
\ttype=\"hidden\"
\tname=\"";
        // line 34
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 34, $this->source); })()), "html", null, true);
        echo "[zoom]\"
\tvalue=\"";
        // line 35
        echo twig_escape_filter($this->env, (((( !(null === (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 35, $this->source); })())) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["value"] ?? null), "zoom", [], "any", true, true)) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 35, $this->source); })()), "zoom", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 35, $this->source); })()), "zoom", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 35, $this->source); })()), "zoom", []))), "html", null, true);
        echo "\"
\tid=\"";
        // line 36
        echo twig_escape_filter($this->env, (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 36, $this->source); })()), "html", null, true);
        echo "-input-zoom\"
>";
    }

    public function getTemplateName()
    {
        return "simplemap/field-input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 36,  106 => 35,  102 => 34,  97 => 31,  91 => 28,  86 => 26,  83 => 25,  81 => 24,  73 => 19,  68 => 17,  64 => 16,  59 => 14,  54 => 12,  50 => 11,  46 => 10,  41 => 8,  34 => 6,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

<div class=\"field simplemap--address-wrap\" id=\"{{ id }}-address-field\">
\t<div class=\"input ltr simplemap--address-field\">
\t\t<input class=\"text simplemap--address fullwidth\" type=\"text\"
\t\t       name=\"{{ name }}[address]\" id=\"{{ id }}-address\"
\t\t       autocomplete=\"off\" placeholder=\"Address\"
\t\t       value=\"{{ value is not null and value.address ? value.address }}\">

\t\t<div class=\"simplemap--lat-lng{{ field.hideLatLng ? ' hidden' }}\">
\t\t\t<input class=\"text fullwidth\" type=\"number\" name=\"{{ name }}[lat]\"
\t\t\t       width=\"19\" id=\"{{ id }}-input-lat\" autocomplete=\"off\"
\t\t\t       placeholder=\"Lat\" step=\"any\"
\t\t\t       value=\"{{ value is not null and value.lat is defined ? value.lat }}\">

\t\t\t<input class=\"text fullwidth\" type=\"number\" name=\"{{ name }}[lng]\"
\t\t\t       width=\"19\" id=\"{{ id }}-input-lng\" autocomplete=\"off\"
\t\t\t       placeholder=\"Lng\" step=\"any\"
\t\t\t       value=\"{{ value is not null and value.lng is defined ? value.lng }}\">
\t\t</div>
\t</div>
</div>

{% if not field.hideMap %}
\t<div
\t\tid=\"{{ id }}\"
\t\tclass=\"simplemap--map\"
\t\tstyle=\"height:{{ height }}px\"
\t></div>
{% endif %}

<input
\ttype=\"hidden\"
\tname=\"{{ name }}[zoom]\"
\tvalue=\"{{ value is not null and value.zoom is defined and value.zoom is not null ? value.zoom : field.zoom }}\"
\tid=\"{{ id }}-input-zoom\"
>", "simplemap/field-input", "E:\\Code\\Craft\\metacell\\vendor\\ether\\simplemap\\src\\templates\\field-input.twig");
    }
}
