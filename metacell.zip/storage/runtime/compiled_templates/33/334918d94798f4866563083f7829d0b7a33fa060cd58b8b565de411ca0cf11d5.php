<?php

/* settings/fields/_edit */
class __TwigTemplate_a7dd361b34acc360fe541b7332288d97436277dbbf1f2040d92f1393b6c6c05d extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("_layouts/cp", "settings/fields/_edit", 1);
        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "_layouts/cp";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 2
        $context["fullPageForm"] = true;
        // line 4
        $context["forms"] = $this->loadTemplate("_includes/forms", "settings/fields/_edit", 4);
        // line 128
        if ((twig_test_empty((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 128, $this->source); })())) || twig_test_empty(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 128, $this->source); })()), "handle", [])))) {
            // line 129
            ob_start();
            // line 130
            echo "        new Craft.HandleGenerator('#name', '#handle');
    ";
            Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        }
        // line 134
        ob_start();
        // line 135
        echo "    Craft.supportedTranslationMethods = ";
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["supportedTranslationMethods"]) || array_key_exists("supportedTranslationMethods", $context) ? $context["supportedTranslationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "supportedTranslationMethods" does not exist.', 135, $this->source); })()));
        echo ";

    Craft.updateTranslationMethodSettings = function(type, container) {
        var \$container = \$(container);
        if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
            \$container.addClass('hidden');
        } else {
            \$container.removeClass('hidden');
            // Rebuild the options based on the field type's supported translation methods
            \$container.find('select').html(
                (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">";
        // line 145
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">";
        // line 146
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('siteGroup', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">";
        // line 147
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">";
        // line 148
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app"), "js"), "html", null, true);
        echo "</option>' : '') +
                (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">";
        // line 149
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app"), "js"), "html", null, true);
        echo "</option>' : '')
            );
        }
    }

    var \$fieldTypeInput = \$(\"#";
        // line 154
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["type"]), "js"), "html", null, true);
        echo "\"),
        \$translationSettings = \$(\"#";
        // line 155
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), ["translation-settings"]), "js"), "html", null, true);
        echo "\");

    \$fieldTypeInput.change(function(e) {
        Craft.updateTranslationMethodSettings(\$(this).val(), \$translationSettings);
    });
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_content($context, array $blocks = [])
    {
        // line 8
        echo "    <input type=\"hidden\" name=\"action\" value=\"fields/save-field\">
    ";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->redirectInputFunction("settings/fields/{groupId}"), "html", null, true);
        echo "
    ";
        // line 10
        if (((isset($context["fieldId"]) || array_key_exists("fieldId", $context)) && (isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new Twig_Error_Runtime('Variable "fieldId" does not exist.', 10, $this->source); })()))) {
            // line 11
            echo "        <input type=\"hidden\" name=\"fieldId\" value=\"";
            echo twig_escape_filter($this->env, (isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new Twig_Error_Runtime('Variable "fieldId" does not exist.', 11, $this->source); })()), "html", null, true);
            echo "\">
    ";
        }
        // line 13
        echo "
    ";
        // line 14
        echo $context["forms"]->macro_selectField(["first" => true, "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Group", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Which group should this field be displayed in?", "app"), "id" => "group", "name" => "group", "options" =>         // line 20
(isset($context["groupOptions"]) || array_key_exists("groupOptions", $context) ? $context["groupOptions"] : (function () { throw new Twig_Error_Runtime('Variable "groupOptions" does not exist.', 20, $this->source); })()), "value" =>         // line 21
(isset($context["groupId"]) || array_key_exists("groupId", $context) ? $context["groupId"] : (function () { throw new Twig_Error_Runtime('Variable "groupId" does not exist.', 21, $this->source); })())]);
        // line 22
        echo "

    ";
        // line 24
        echo $context["forms"]->macro_textField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Name", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What this field will be called in the CP.", "app"), "id" => "name", "name" => "name", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 29
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 29, $this->source); })()), "name", []), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 30
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 30, $this->source); })()), "getErrors", [0 => "name"], "method"), "required" => true, "autofocus" => true]);
        // line 33
        echo "

    ";
        // line 35
        echo $context["forms"]->macro_textField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Handle", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How you’ll refer to this field in the templates.", "app"), "id" => "handle", "class" => "code", "name" => "handle", "maxlength" => 64, "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 42
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 42, $this->source); })()), "handle", []), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 43
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 43, $this->source); })()), "getErrors", [0 => "handle"], "method"), "required" => true]);
        // line 45
        echo "

    ";
        // line 47
        echo $context["forms"]->macro_textareaField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Instructions", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Helper text to guide the author.", "app"), "id" => "instructions", "class" => "nicetext", "name" => "instructions", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 53
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 53, $this->source); })()), "instructions", []), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 54
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 54, $this->source); })()), "getErrors", [0 => "instructions"], "method")]);
        // line 55
        echo "

    ";
        // line 57
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Use this field’s values as search keywords?", "app"), "id" => "searchable", "name" => "searchable", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 61
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 61, $this->source); })()), "searchable", [])]);
        // line 62
        echo "

    ";
        // line 64
        echo $context["forms"]->macro_selectField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Field Type", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("What type of field is this?", "app"), "warning" => ((( !twig_test_empty(        // line 67
(isset($context["fieldId"]) || array_key_exists("fieldId", $context) ? $context["fieldId"] : (function () { throw new Twig_Error_Runtime('Variable "fieldId" does not exist.', 67, $this->source); })())) &&  !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 67, $this->source); })()), "hasErrors", [0 => "type"], "method"))) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Changing this may result in data loss.", "app")) : ("")), "id" => "type", "name" => "type", "options" =>         // line 70
(isset($context["fieldTypeOptions"]) || array_key_exists("fieldTypeOptions", $context) ? $context["fieldTypeOptions"] : (function () { throw new Twig_Error_Runtime('Variable "fieldTypeOptions" does not exist.', 70, $this->source); })()), "value" => get_class(        // line 71
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 71, $this->source); })())), "toggle" => true]);
        // line 73
        echo "

    ";
        // line 75
        echo (isset($context["missingFieldPlaceholder"]) || array_key_exists("missingFieldPlaceholder", $context) ? $context["missingFieldPlaceholder"] : (function () { throw new Twig_Error_Runtime('Variable "missingFieldPlaceholder" does not exist.', 75, $this->source); })());
        echo "

    ";
        // line 77
        if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 77, $this->source); })()), "app", []), "getIsMultiSite", [], "method")) {
            // line 78
            echo "        ";
            $context["translationMethods"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 78, $this->source); })()), "supportedTranslationMethods", []);
            // line 79
            echo "        ";
            if ((twig_length_filter($this->env, (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 79, $this->source); })())) > 1)) {
                // line 80
                echo "            <div id=\"translation-settings\">
                ";
                // line 81
                echo $context["forms"]->macro_selectField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Method", "app"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("How should this field’s values be translated?", "app"), "id" => "translation-method", "name" => "translationMethod", "options" => array_filter([0 => ((twig_in_filter("none",                 // line 87
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 87, $this->source); })()))) ? (["value" => "none", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Not translatable", "app")]) : ("")), 1 => ((twig_in_filter("site",                 // line 88
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 88, $this->source); })()))) ? (["value" => "site", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site", "app")]) : ("")), 2 => ((twig_in_filter("siteGroup",                 // line 89
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 89, $this->source); })()))) ? (["value" => "siteGroup", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each site group", "app")]) : ("")), 3 => ((twig_in_filter("language",                 // line 90
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 90, $this->source); })()))) ? (["value" => "language", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translate for each language", "app")]) : ("")), 4 => ((twig_in_filter("custom",                 // line 91
(isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 91, $this->source); })()))) ? (["value" => "custom", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom…", "app")]) : (""))]), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 93
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 93, $this->source); })()), "translationMethod", []), "toggle" => true, "targetPrefix" => "translation-method-"]);
                // line 96
                echo "

                ";
                // line 98
                if (twig_in_filter("custom", (isset($context["translationMethods"]) || array_key_exists("translationMethods", $context) ? $context["translationMethods"] : (function () { throw new Twig_Error_Runtime('Variable "translationMethods" does not exist.', 98, $this->source); })()))) {
                    // line 99
                    echo "                    <div id=\"translation-method-custom\" ";
                    if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 99, $this->source); })()), "translationMethod", []) != "custom")) {
                        echo "class=\"hidden\"";
                    }
                    echo ">
                        ";
                    // line 100
                    echo $context["forms"]->macro_textField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Translation Key Format", "app"), "instructions" => "Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.", "id" => "translation-key-format", "name" => "translationKeyFormat", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 105
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 105, $this->source); })()), "translationKeyFormat", []), "errors" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 106
(isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 106, $this->source); })()), "getErrors", [0 => "translationKeyFormat"], "method")]);
                    // line 107
                    echo "
                    </div>
                ";
                }
                // line 110
                echo "            </div>
        ";
            }
            // line 112
            echo "    ";
        }
        // line 113
        echo "
    <hr>

    ";
        // line 116
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["allFieldTypes"]) || array_key_exists("allFieldTypes", $context) ? $context["allFieldTypes"] : (function () { throw new Twig_Error_Runtime('Variable "allFieldTypes" does not exist.', 116, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["type"]) {
            // line 117
            echo "        ";
            $context["isCurrent"] = ($context["type"] == get_class((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 117, $this->source); })())));
            // line 118
            echo "        <div id=\"";
            echo twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('id')->getCallable(), [$context["type"]]), "html", null, true);
            echo "\"";
            if ( !(isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new Twig_Error_Runtime('Variable "isCurrent" does not exist.', 118, $this->source); })())) {
                echo " class=\"hidden\"";
            }
            echo ">
            ";
            // line 119
            $_namespace = (("types[" . $context["type"]) . "]");
            if ($_namespace) {
                $_originalNamespace = Craft::$app->getView()->getNamespace();
                Craft::$app->getView()->setNamespace(Craft::$app->getView()->namespaceInputName($_namespace));
                ob_start();
                try {
                    // line 120
                    echo "                ";
                    $context["_field"] = (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new Twig_Error_Runtime('Variable "isCurrent" does not exist.', 120, $this->source); })())) ? ((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 120, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 120, $this->source); })()), "app", []), "fields", []), "createField", [0 => $context["type"]], "method")));
                    // line 121
                    echo "                ";
                    echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["_field"]) || array_key_exists("_field", $context) ? $context["_field"] : (function () { throw new Twig_Error_Runtime('Variable "_field" does not exist.', 121, $this->source); })()), "getSettingsHtml", [], "method");
                    echo "
            ";
                } catch (Exception $e) {
                    ob_end_clean();

                    throw $e;
                }
                echo Craft::$app->getView()->namespaceInputs(ob_get_clean(), $_namespace);
                Craft::$app->getView()->setNamespace($_originalNamespace);
            } else {
                // line 120
                echo "                ";
                $context["_field"] = (((isset($context["isCurrent"]) || array_key_exists("isCurrent", $context) ? $context["isCurrent"] : (function () { throw new Twig_Error_Runtime('Variable "isCurrent" does not exist.', 120, $this->source); })())) ? ((isset($context["field"]) || array_key_exists("field", $context) ? $context["field"] : (function () { throw new Twig_Error_Runtime('Variable "field" does not exist.', 120, $this->source); })())) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 120, $this->source); })()), "app", []), "fields", []), "createField", [0 => $context["type"]], "method")));
                // line 121
                echo "                ";
                echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["_field"]) || array_key_exists("_field", $context) ? $context["_field"] : (function () { throw new Twig_Error_Runtime('Variable "_field" does not exist.', 121, $this->source); })()), "getSettingsHtml", [], "method");
                echo "
            ";
            }
            unset($_originalNamespace, $_namespace);
            // line 123
            echo "        </div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "settings/fields/_edit";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  275 => 123,  268 => 121,  265 => 120,  252 => 121,  249 => 120,  242 => 119,  233 => 118,  230 => 117,  226 => 116,  221 => 113,  218 => 112,  214 => 110,  209 => 107,  207 => 106,  206 => 105,  205 => 100,  198 => 99,  196 => 98,  192 => 96,  190 => 93,  189 => 91,  188 => 90,  187 => 89,  186 => 88,  185 => 87,  184 => 81,  181 => 80,  178 => 79,  175 => 78,  173 => 77,  168 => 75,  164 => 73,  162 => 71,  161 => 70,  160 => 67,  159 => 64,  155 => 62,  153 => 61,  152 => 57,  148 => 55,  146 => 54,  145 => 53,  144 => 47,  140 => 45,  138 => 43,  137 => 42,  136 => 35,  132 => 33,  130 => 30,  129 => 29,  128 => 24,  124 => 22,  122 => 21,  121 => 20,  120 => 14,  117 => 13,  111 => 11,  109 => 10,  105 => 9,  102 => 8,  99 => 7,  95 => 1,  86 => 155,  82 => 154,  74 => 149,  70 => 148,  66 => 147,  62 => 146,  58 => 145,  44 => 135,  42 => 134,  37 => 130,  35 => 129,  33 => 128,  31 => 4,  29 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"_layouts/cp\" %}
{% set fullPageForm = true %}

{% import \"_includes/forms\" as forms %}


{% block content %}
    <input type=\"hidden\" name=\"action\" value=\"fields/save-field\">
    {{ redirectInput('settings/fields/{groupId}') }}
    {% if fieldId is defined and fieldId %}
        <input type=\"hidden\" name=\"fieldId\" value=\"{{ fieldId }}\">
    {% endif %}

    {{ forms.selectField({
        first: true,
        label: \"Group\"|t('app'),
        instructions: \"Which group should this field be displayed in?\"|t('app'),
        id: 'group',
        name: 'group',
        options: groupOptions,
        value: groupId
    }) }}

    {{ forms.textField({
        label: \"Name\"|t('app'),
        instructions: \"What this field will be called in the CP.\"|t('app'),
        id: 'name',
        name: 'name',
        value: field.name,
        errors: field.getErrors('name'),
        required: true,
        autofocus: true
    }) }}

    {{ forms.textField({
        label: \"Handle\"|t('app'),
        instructions: \"How you’ll refer to this field in the templates.\"|t('app'),
        id: 'handle',
        class: 'code',
        name: 'handle',
        maxlength: 64,
        value: field.handle,
        errors: field.getErrors('handle'),
        required: true,
    }) }}

    {{ forms.textareaField({
        label: \"Instructions\"|t('app'),
        instructions: \"Helper text to guide the author.\"|t('app'),
        id: 'instructions',
        class: 'nicetext',
        name: 'instructions',
        value: field.instructions,
        errors: field.getErrors('instructions'),
    }) }}

    {{ forms.checkboxField({
        label: \"Use this field’s values as search keywords?\"|t('app'),
        id: 'searchable',
        name: 'searchable',
        checked: field.searchable
    }) }}

    {{ forms.selectField({
        label: \"Field Type\"|t('app'),
        instructions: \"What type of field is this?\"|t('app'),
        warning: (fieldId is not empty and not field.hasErrors('type') ? \"Changing this may result in data loss.\"|t('app')),
        id: 'type',
        name: 'type',
        options: fieldTypeOptions,
        value: className(field),
        toggle: true
    }) }}

    {{ missingFieldPlaceholder|raw }}

    {% if craft.app.getIsMultiSite() %}
        {% set translationMethods = field.supportedTranslationMethods %}
        {% if translationMethods|length > 1 %}
            <div id=\"translation-settings\">
                {{ forms.selectField({
                    label: \"Translation Method\"|t('app'),
                    instructions: \"How should this field’s values be translated?\"|t('app'),
                    id: 'translation-method',
                    name: 'translationMethod',
                    options: [
                        'none' in translationMethods ? { value: 'none', label: \"Not translatable\"|t('app') },
                        'site' in translationMethods ? { value: 'site', label: \"Translate for each site\"|t('app') },
                        'siteGroup' in translationMethods ? { value: 'siteGroup', label: \"Translate for each site group\"|t('app') },
                        'language' in translationMethods ? { value: 'language', label: \"Translate for each language\"|t('app') },
                        'custom' in translationMethods ? { value: 'custom', label: \"Custom…\"|t('app') }
                    ]|filter,
                    value: field.translationMethod,
                    toggle: true,
                    targetPrefix: 'translation-method-'
                }) }}

                {% if 'custom' in translationMethods %}
                    <div id=\"translation-method-custom\" {% if field.translationMethod != 'custom' %}class=\"hidden\"{% endif %}>
                        {{ forms.textField({
                            label: \"Translation Key Format\"|t('app'),
                            instructions: \"Template that defines the field’s custom “translation key” format. Field values will be copied to all sites that produce the same key. For example, to make the field translatable based on the first two characters of the site handle, you could enter `{site.handle[:2]}`.\",
                            id: 'translation-key-format',
                            name: 'translationKeyFormat',
                            value: field.translationKeyFormat,
                            errors: field.getErrors('translationKeyFormat')
                        }) }}
                    </div>
                {% endif %}
            </div>
        {% endif %}
    {% endif %}

    <hr>

    {% for type in allFieldTypes %}
        {% set isCurrent = (type == className(field)) %}
        <div id=\"{{ type|id }}\"{% if not isCurrent %} class=\"hidden\"{% endif %}>
            {% namespace 'types['~type~']' %}
                {% set _field = isCurrent ? field : craft.app.fields.createField(type) %}
                {{ _field.getSettingsHtml()|raw }}
            {% endnamespace %}
        </div>
    {% endfor %}
{% endblock %}


{% if field is empty or field.handle is empty %}
    {% js %}
        new Craft.HandleGenerator('#name', '#handle');
    {% endjs %}
{% endif %}

{% js %}
    Craft.supportedTranslationMethods = {{ supportedTranslationMethods|json_encode|raw }};

    Craft.updateTranslationMethodSettings = function(type, container) {
        var \$container = \$(container);
        if (!Craft.supportedTranslationMethods[type] || Craft.supportedTranslationMethods[type].length == 1) {
            \$container.addClass('hidden');
        } else {
            \$container.removeClass('hidden');
            // Rebuild the options based on the field type's supported translation methods
            \$container.find('select').html(
                (\$.inArray('none', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"none\">{{ \"Not translatable\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('site', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">{{ \"Translate for each site\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('siteGroup', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"site\">{{ \"Translate for each site group\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('language', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"language\">{{ \"Translate for each language\"|t('app')|e('js') }}</option>' : '') +
                (\$.inArray('custom', Craft.supportedTranslationMethods[type]) != -1 ? '<option value=\"custom\">{{ \"Custom…\"|t('app')|e('js') }}</option>' : '')
            );
        }
    }

    var \$fieldTypeInput = \$(\"#{{ 'type'|namespaceInputId|e('js') }}\"),
        \$translationSettings = \$(\"#{{ 'translation-settings'|namespaceInputId|e('js') }}\");

    \$fieldTypeInput.change(function(e) {
        Craft.updateTranslationMethodSettings(\$(this).val(), \$translationSettings);
    });
{% endjs %}
", "settings/fields/_edit", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\settings\\fields\\_edit.html");
    }
}
