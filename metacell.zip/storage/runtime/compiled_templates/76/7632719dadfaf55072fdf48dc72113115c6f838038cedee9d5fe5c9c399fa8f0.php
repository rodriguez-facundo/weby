<?php

/* typedlinkfield/_input-select */
class __TwigTemplate_ead4c809733767ff424b7cfb9d362615d63a816ba08a795c77d06b35b9e92732 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_input-select", 1);
        // line 2
        echo "
<div class=\"linkfield--typeOption ";
        // line 3
        echo twig_escape_filter($this->env, (isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 3, $this->source); })()), "html", null, true);
        echo (((isset($context["isSelected"]) || array_key_exists("isSelected", $context) ? $context["isSelected"] : (function () { throw new Twig_Error_Runtime('Variable "isSelected" does not exist.', 3, $this->source); })())) ? ("") : (" hidden"));
        echo "\">
  ";
        // line 4
        echo $context["forms"]->macro_select((isset($context["selectFieldOptions"]) || array_key_exists("selectFieldOptions", $context) ? $context["selectFieldOptions"] : (function () { throw new Twig_Error_Runtime('Variable "selectFieldOptions" does not exist.', 4, $this->source); })()));
        echo "
</div>
";
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_input-select";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

<div class=\"linkfield--typeOption {{ linkTypeName }}{{ isSelected ? '' : ' hidden' }}\">
  {{ forms.select(selectFieldOptions) }}
</div>
", "typedlinkfield/_input-select", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_input-select.twig");
    }
}
