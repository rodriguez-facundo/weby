<?php

/* _includes/forms/autosuggest */
class __TwigTemplate_ed014782dfe7aaefcb6de99ecfed7fe339ee335c65a77cc69764c4053ec6dcb3 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 1, $this->source); })()), "registerAssetBundle", [0 => "craft\\web\\assets\\vue\\VueAsset"], "method");
        // line 2
        echo "
";
        // line 3
        if (((($context["suggestEnvVars"]) ?? (false)) &&  !(isset($context["suggestions"]) || array_key_exists("suggestions", $context)))) {
            // line 4
            echo "    ";
            $context["suggestions"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["craft"]) || array_key_exists("craft", $context) ? $context["craft"] : (function () { throw new Twig_Error_Runtime('Variable "craft" does not exist.', 4, $this->source); })()), "cp", []), "getEnvSuggestions", [0 => (($context["suggestAliases"]) ?? (false))], "method");
        }
        // line 7
        $context["id"] = ((((isset($context["id"]) || array_key_exists("id", $context)) && (isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 7, $this->source); })()))) ? ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 7, $this->source); })())) : (("autosuggest" . twig_random($this->env))));
        // line 8
        $context["containerId"] = ((isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 8, $this->source); })()) . "-container");
        // line 10
        $context["class"] = twig_join_filter(array_filter([0 => "text", 1 => (((        // line 12
(isset($context["class"]) || array_key_exists("class", $context)) && (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new Twig_Error_Runtime('Variable "class" does not exist.', 12, $this->source); })()))) ? ((isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new Twig_Error_Runtime('Variable "class" does not exist.', 12, $this->source); })())) : (null)), 2 => (((        // line 13
(isset($context["size"]) || array_key_exists("size", $context)) && (isset($context["size"]) || array_key_exists("size", $context) ? $context["size"] : (function () { throw new Twig_Error_Runtime('Variable "size" does not exist.', 13, $this->source); })()))) ? (null) : ("fullwidth"))]), " ");
        // line 15
        echo "
<div id=\"";
        // line 16
        echo twig_escape_filter($this->env, (isset($context["containerId"]) || array_key_exists("containerId", $context) ? $context["containerId"] : (function () { throw new Twig_Error_Runtime('Variable "containerId" does not exist.', 16, $this->source); })()), "html", null, true);
        echo "\" class=\"autosuggest-container\">
    ";
        // line 29
        echo "
    <vue-autosuggest
            :suggestions=\"filteredOptions\"
            :getSuggestionValue=\"getSuggestionValue\"
            :input-props=\"inputProps\"
            :limit=\"limit\"
            @selected=\"onSelected\">
        <template slot-scope=\"{suggestion}\">
            {{suggestion.item.name || suggestion.item}}
            <span v-if=\"suggestion.item.hint\" class=\"light\">– {{suggestion.item.hint}}</span>
        </template>
    </vue-autosuggest>
    ";
        echo "
</div>

";
        // line 32
        ob_start();
        // line 33
        echo "new Vue({
    el: \"#";
        // line 34
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["containerId"]) || array_key_exists("containerId", $context) ? $context["containerId"] : (function () { throw new Twig_Error_Runtime('Variable "containerId" does not exist.', 34, $this->source); })())]), "js"), "html", null, true);
        echo "\",

    data() {
        return {
            selected: '',
            filteredOptions: [],
            suggestions: ";
        // line 40
        echo $this->extensions['craft\web\twig\Extension']->jsonEncodeFilter((isset($context["suggestions"]) || array_key_exists("suggestions", $context) ? $context["suggestions"] : (function () { throw new Twig_Error_Runtime('Variable "suggestions" does not exist.', 40, $this->source); })()));
        echo ",
            inputProps: {
                class: \"";
        // line 42
        echo twig_escape_filter($this->env, (isset($context["class"]) || array_key_exists("class", $context) ? $context["class"] : (function () { throw new Twig_Error_Runtime('Variable "class" does not exist.', 42, $this->source); })()), "html", null, true);
        echo "\",
                initialValue: \"";
        // line 43
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, (($context["value"]) ?? ("")), "js"), "html", null, true);
        echo "\",
                onInputChange: this.onInputChange,
                style: \"";
        // line 45
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, (($context["style"]) ?? ("")), "js"), "html", null, true);
        echo "\",
                id: \"";
        // line 46
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputId')->getCallable(), [(isset($context["id"]) || array_key_exists("id", $context) ? $context["id"] : (function () { throw new Twig_Error_Runtime('Variable "id" does not exist.', 46, $this->source); })())]), "js"), "html", null, true);
        echo "\",
                name: \"";
        // line 47
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, call_user_func_array($this->env->getFilter('namespaceInputName')->getCallable(), [(($context["name"]) ?? (""))]), "js"), "html", null, true);
        echo "\",
                size: \"";
        // line 48
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, (($context["size"]) ?? ("")), "js"), "html", null, true);
        echo "\",
                maxlength: \"";
        // line 49
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, (($context["maxlength"]) ?? ("")), "js"), "html", null, true);
        echo "\",
                autofocus: ";
        // line 50
        echo (((($context["autofocus"]) ?? (false))) ? ("true") : ("false"));
        echo ",
                title: \"";
        // line 51
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, (($context["title"]) ?? ("")), "js"), "html", null, true);
        echo "\",
                placeholder: \"";
        // line 52
        echo twig_escape_filter($this->env, twig_escape_filter($this->env, (($context["placeholder"]) ?? ("")), "js"), "html", null, true);
        echo "\"
            },
            limit: ";
        // line 54
        echo twig_escape_filter($this->env, (($context["limit"]) ?? (5)), "html", null, true);
        echo "
        };
    },

    methods: {
        onInputChange(text) {
            if (text === '' || text === undefined) {
                this.filteredOptions = this.suggestions;
                return;
            }

            text = text.toLowerCase();

            var filtered = [];
            var i, j, sectionFilter, item, name;
            var that = this;

            for (i = 0; i < this.suggestions.length; i++) {
                sectionFilter = [];
                for (j = 0; j < this.suggestions[i].data.length; j++) {
                    item = this.suggestions[i].data[j];
                    if (
                        (item.name || item).toLowerCase().indexOf(text) !== -1 ||
                        (item.hint && item.hint.toLowerCase().indexOf(text) !== -1)
                    ) {
                        sectionFilter.push(item.name ? item : {name: item});
                    }
                }
                if (sectionFilter.length) {
                    sectionFilter.sort(function(a, b) {
                        var scoreA = that.scoreItem(a, text);
                        var scoreB = that.scoreItem(b, text);
                        if (scoreA === scoreB) {
                            return 0;
                        }
                        return scoreA < scoreB ? 1 : -1;
                    });
                    filtered.push({
                        label: this.suggestions[i].label || null,
                        data: sectionFilter.slice(0, this.limit)
                    });
                }
            }

            this.filteredOptions = filtered;
        },
        scoreItem(item, text) {
            var score = 0;
            if (item.name.toLowerCase().indexOf(text) !== -1) {
                score += 100 + text.length / item.name.length;
            }
            if (item.hint && item.hint.toLowerCase().indexOf(text) !== -1) {
                score += text.length / item.hint.length;
            }
            return score;
        },
        onSelected(option) {
            this.selected = option.item;
        },
        getSuggestionValue(suggestion) {
            return suggestion.item.name || suggestion.item;
        }
    }
})
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
    }

    public function getTemplateName()
    {
        return "_includes/forms/autosuggest";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 54,  123 => 52,  119 => 51,  115 => 50,  111 => 49,  107 => 48,  103 => 47,  99 => 46,  95 => 45,  90 => 43,  86 => 42,  81 => 40,  72 => 34,  69 => 33,  67 => 32,  49 => 29,  45 => 16,  42 => 15,  40 => 13,  39 => 12,  38 => 10,  36 => 8,  34 => 7,  30 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% do view.registerAssetBundle(\"craft\\\\web\\\\assets\\\\vue\\\\VueAsset\") %}

{% if (suggestEnvVars ?? false) and suggestions is not defined %}
    {% set suggestions = craft.cp.getEnvSuggestions(suggestAliases ?? false) %}
{% endif %}

{%- set id = (id is defined and id ? id : 'autosuggest'~random()) %}
{%- set containerId = id ~ '-container' %}

{%- set class = [
    'text',
    (class is defined and class ? class : null),
    (size is defined and size ? null : 'fullwidth')
]|filter|join(' ') %}

<div id=\"{{ containerId }}\" class=\"autosuggest-container\">
    {% verbatim %}
    <vue-autosuggest
            :suggestions=\"filteredOptions\"
            :getSuggestionValue=\"getSuggestionValue\"
            :input-props=\"inputProps\"
            :limit=\"limit\"
            @selected=\"onSelected\">
        <template slot-scope=\"{suggestion}\">
            {{suggestion.item.name || suggestion.item}}
            <span v-if=\"suggestion.item.hint\" class=\"light\">– {{suggestion.item.hint}}</span>
        </template>
    </vue-autosuggest>
    {% endverbatim %}
</div>

{% js %}
new Vue({
    el: \"#{{ containerId|namespaceInputId|e('js') }}\",

    data() {
        return {
            selected: '',
            filteredOptions: [],
            suggestions: {{ suggestions|json_encode|raw }},
            inputProps: {
                class: \"{{ class }}\",
                initialValue: \"{{ (value ?? '')|e('js') }}\",
                onInputChange: this.onInputChange,
                style: \"{{ (style ?? '')|e('js') }}\",
                id: \"{{ id|namespaceInputId|e('js') }}\",
                name: \"{{ (name ?? '')|namespaceInputName|e('js') }}\",
                size: \"{{ (size ?? '')|e('js') }}\",
                maxlength: \"{{ (maxlength ?? '')|e('js') }}\",
                autofocus: {{ (autofocus ?? false) ? 'true' : 'false' }},
                title: \"{{ (title ?? '')|e('js') }}\",
                placeholder: \"{{ (placeholder ?? '')|e('js') }}\"
            },
            limit: {{ limit ?? 5 }}
        };
    },

    methods: {
        onInputChange(text) {
            if (text === '' || text === undefined) {
                this.filteredOptions = this.suggestions;
                return;
            }

            text = text.toLowerCase();

            var filtered = [];
            var i, j, sectionFilter, item, name;
            var that = this;

            for (i = 0; i < this.suggestions.length; i++) {
                sectionFilter = [];
                for (j = 0; j < this.suggestions[i].data.length; j++) {
                    item = this.suggestions[i].data[j];
                    if (
                        (item.name || item).toLowerCase().indexOf(text) !== -1 ||
                        (item.hint && item.hint.toLowerCase().indexOf(text) !== -1)
                    ) {
                        sectionFilter.push(item.name ? item : {name: item});
                    }
                }
                if (sectionFilter.length) {
                    sectionFilter.sort(function(a, b) {
                        var scoreA = that.scoreItem(a, text);
                        var scoreB = that.scoreItem(b, text);
                        if (scoreA === scoreB) {
                            return 0;
                        }
                        return scoreA < scoreB ? 1 : -1;
                    });
                    filtered.push({
                        label: this.suggestions[i].label || null,
                        data: sectionFilter.slice(0, this.limit)
                    });
                }
            }

            this.filteredOptions = filtered;
        },
        scoreItem(item, text) {
            var score = 0;
            if (item.name.toLowerCase().indexOf(text) !== -1) {
                score += 100 + text.length / item.name.length;
            }
            if (item.hint && item.hint.toLowerCase().indexOf(text) !== -1) {
                score += text.length / item.hint.length;
            }
            return score;
        },
        onSelected(option) {
            this.selected = option.item;
        },
        getSuggestionValue(suggestion) {
            return suggestion.item.name || suggestion.item;
        }
    }
})
{% endjs %}
", "_includes/forms/autosuggest", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\_includes\\forms\\autosuggest.html");
    }
}
