<?php

/* _components/logoSlider/default.twig */
class __TwigTemplate_683fc817a445ab4c9d54d17a3d24ffa5ba09938497c7428726c332916047dde2 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/logoSlider/default.twig", 1);
        // line 2
        echo "<div class=\"component-container\">
    <div class=\"logos-slider\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container slider-inner\">
            <div class=\"spacing-both\">
                <h5 class=\"title\">
                    ";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 10, $this->source); })()), "heading", []), "html", null, true);
        echo "
                </h5>
                <div class=\"swiper-container swiper-container-horizontal\">
                    <div class=\"swiper-wrapper\" style=\"transform: translate3d(-750px, 0px, 0px); transition-duration: 0ms;\">
                        ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 14, $this->source); })()), "items", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 15
            echo "                            <div class=\"swiper-slide slide\" style=\"width: 160px; margin-right: 90px;\">
                                ";
            // line 16
            echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "image", []), "one", [], "method"), ["ratio" => (2 / 1), "srcset" => [0 => ["width" => 160, "jpegQuality" => 85]]]);
            // line 23
            echo "
                                <p>
                                    ";
            // line 25
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["item"], "text", []), "html", null, true);
            echo "
                                </p>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 29
        echo "                    </div>
                    <div class=\"swiper-pagination swiper-pagination-clickable swiper-pagination-bullets\">
                        <span aria-label=\"Go to slide 1\" class=\"swiper-pagination-bullet\" role=\"button\" tabindex=\"0\"></span>
                        <span aria-label=\"Go to slide 2\" class=\"swiper-pagination-bullet\" role=\"button\" tabindex=\"0\"></span>
                        <span aria-label=\"Go to slide 3\" class=\"swiper-pagination-bullet\" role=\"button\" tabindex=\"0\"></span>
                        <span aria-label=\"Go to slide 4\" class=\"swiper-pagination-bullet swiper-pagination-bullet-active\" role=\"button\" tabindex=\"0\"></span>
                    </div>
                    <span aria-atomic=\"true\" aria-live=\"assertive\" class=\"swiper-notification\"></span>
                </div>
                <button class=\"swiper-button-next\"></button>
                <button class=\"swiper-button-prev\"></button>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/logoSlider/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 29,  55 => 25,  51 => 23,  49 => 16,  46 => 15,  42 => 14,  35 => 10,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}
<div class=\"component-container\">
    <div class=\"logos-slider\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container slider-inner\">
            <div class=\"spacing-both\">
                <h5 class=\"title\">
                    {{ component.heading }}
                </h5>
                <div class=\"swiper-container swiper-container-horizontal\">
                    <div class=\"swiper-wrapper\" style=\"transform: translate3d(-750px, 0px, 0px); transition-duration: 0ms;\">
                        {% for item in component.items.all() %}
                            <div class=\"swiper-slide slide\" style=\"width: 160px; margin-right: 90px;\">
                                {{ imageMacros.image(item.image.one(), {
                                                ratio: (2/1),
                                                srcset: [
                                                    { width: 160, jpegQuality: 85 },
                                                ]
                                            }
                                        )   
                                    }}
                                <p>
                                    {{ item.text }}
                                </p>
                            </div>
                        {% endfor %}
                    </div>
                    <div class=\"swiper-pagination swiper-pagination-clickable swiper-pagination-bullets\">
                        <span aria-label=\"Go to slide 1\" class=\"swiper-pagination-bullet\" role=\"button\" tabindex=\"0\"></span>
                        <span aria-label=\"Go to slide 2\" class=\"swiper-pagination-bullet\" role=\"button\" tabindex=\"0\"></span>
                        <span aria-label=\"Go to slide 3\" class=\"swiper-pagination-bullet\" role=\"button\" tabindex=\"0\"></span>
                        <span aria-label=\"Go to slide 4\" class=\"swiper-pagination-bullet swiper-pagination-bullet-active\" role=\"button\" tabindex=\"0\"></span>
                    </div>
                    <span aria-atomic=\"true\" aria-live=\"assertive\" class=\"swiper-notification\"></span>
                </div>
                <button class=\"swiper-button-next\"></button>
                <button class=\"swiper-button-prev\"></button>
            </div>
        </div>
    </div>
</div>", "_components/logoSlider/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\logoSlider\\default.twig");
    }
}
