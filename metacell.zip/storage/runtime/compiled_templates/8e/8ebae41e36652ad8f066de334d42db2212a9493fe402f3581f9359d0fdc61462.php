<?php

/* typedlinkfield/_settings */
class __TwigTemplate_80842ead89090342952d4d8bf4cdca49ff82eb149b98f5880974543ca230671f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_settings", 1);
        // line 2
        echo "
";
        // line 3
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", [0 => "typedlinkfield\\utilities\\CpAdminAssetBundle"], "method");
        // line 4
        $context["group"] = "";
        // line 5
        echo "
<div class=\"linkFieldAdmin\" id=\"";
        // line 6
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 6, $this->source); })()), "html", null, true);
        echo "\">
  <div class=\"linkFieldAdmin--tabs\">
    <div class=\"linkFieldAdmin--tabsRow selected\" data-name=\"_general\">
      <button class=\"linkFieldAdmin--tabsTab\">";
        // line 9
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("General settings", "typedlinkfield"), "html", null, true);
        echo "</button>
    </div>

    <div class=\"linkFieldAdmin--tabsRow all\">
      <div class=\"linkFieldAdmin--tabsLightswitch\">";
        // line 14
        echo $context["forms"]->macro_lightswitch(["name" => "allowedLinkNames[]", "on" =>         // line 16
(isset($context["allTypesAllowed"]) || array_key_exists("allTypesAllowed", $context) ? $context["allTypesAllowed"] : (function () { throw new Twig_Error_Runtime('Variable "allTypesAllowed" does not exist.', 16, $this->source); })()), "value" => "*"]);
        // line 19
        echo "</div>
      ";
        // line 20
        echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("Enable all", "typedlinkfield"), "html", null, true);
        echo "
    </div>";
        // line 23
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["linkTypes"]) || array_key_exists("linkTypes", $context) ? $context["linkTypes"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypes" does not exist.', 23, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["linkType"]) {
            // line 24
            if ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["linkType"], "group", []) != (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new Twig_Error_Runtime('Variable "group" does not exist.', 24, $this->source); })()))) {
                // line 25
                $context["group"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["linkType"], "group", []);
                // line 26
                echo "<div class=\"linkFieldAdmin--tabsGroup\">";
                echo twig_escape_filter($this->env, (isset($context["group"]) || array_key_exists("group", $context) ? $context["group"] : (function () { throw new Twig_Error_Runtime('Variable "group" does not exist.', 26, $this->source); })()), "html", null, true);
                echo "</div>";
            }
            // line 29
            echo "<div class=\"linkFieldAdmin--tabsRow\" data-name=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["linkType"], "name", []), "html", null, true);
            echo "\">
        <div class=\"linkFieldAdmin--tabsLightswitch";
            // line 30
            if ((isset($context["allTypesAllowed"]) || array_key_exists("allTypesAllowed", $context) ? $context["allTypesAllowed"] : (function () { throw new Twig_Error_Runtime('Variable "allTypesAllowed" does not exist.', 30, $this->source); })())) {
                echo " hidden";
            }
            echo "\">";
            // line 31
            echo $context["forms"]->macro_lightswitch(["name" => "allowedLinkNames[]", "on" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 33
$context["linkType"], "enabled", []), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),             // line 34
$context["linkType"], "name", [])]);
            // line 36
            echo "</div>

        <button class=\"linkFieldAdmin--tabsTab\">";
            // line 39
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["linkType"], "displayName", []), "html", null, true);
            // line 40
            echo "</button>
      </div>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['linkType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 43
        echo "</div>
  <div class=\"linkFieldAdmin--body\">
    <div class=\"linkFieldAdmin--bodyContent selected\" data-name=\"_general\">
      ";
        // line 46
        $this->loadTemplate("typedlinkfield/_settings-general", "typedlinkfield/_settings", 46)->display($context);
        // line 47
        echo "    </div>";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["linkTypes"]) || array_key_exists("linkTypes", $context) ? $context["linkTypes"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypes" does not exist.', 49, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["linkType"]) {
            // line 50
            echo "<div class=\"linkFieldAdmin--bodyContent\" data-name=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["linkType"], "name", []), "html", null, true);
            echo "\">";
            // line 51
            echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["linkType"], "settings", []);
            // line 52
            echo "</div>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['linkType'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 54
        echo "</div>
</div>

";
        // line 57
        ob_start();
        // line 58
        echo "  new LinkFieldAdmin(\"";
        echo twig_escape_filter($this->env, (isset($context["nameNs"]) || array_key_exists("nameNs", $context) ? $context["nameNs"] : (function () { throw new Twig_Error_Runtime('Variable "nameNs" does not exist.', 58, $this->source); })()), "html", null, true);
        echo "\");
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  130 => 58,  128 => 57,  123 => 54,  117 => 52,  115 => 51,  111 => 50,  107 => 49,  105 => 47,  103 => 46,  98 => 43,  91 => 40,  89 => 39,  85 => 36,  83 => 34,  82 => 33,  81 => 31,  76 => 30,  71 => 29,  66 => 26,  64 => 25,  62 => 24,  58 => 23,  54 => 20,  51 => 19,  49 => 16,  48 => 14,  41 => 9,  35 => 6,  32 => 5,  30 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_includes/forms' as forms %}

{% do view.registerAssetBundle('typedlinkfield\\\\utilities\\\\CpAdminAssetBundle') %}
{% set group = '' %}

<div class=\"linkFieldAdmin\" id=\"{{ name }}\">
  <div class=\"linkFieldAdmin--tabs\">
    <div class=\"linkFieldAdmin--tabsRow selected\" data-name=\"_general\">
      <button class=\"linkFieldAdmin--tabsTab\">{{ 'General settings'|t('typedlinkfield') }}</button>
    </div>

    <div class=\"linkFieldAdmin--tabsRow all\">
      <div class=\"linkFieldAdmin--tabsLightswitch\">
        {{- forms.lightswitch({
          name: 'allowedLinkNames[]',
          on: allTypesAllowed,
          value: '*',
        }) -}}
      </div>
      {{ 'Enable all'|t('typedlinkfield') }}
    </div>

    {%- for linkType in linkTypes -%}
      {%- if linkType.group != group -%}
        {%- set group = linkType.group -%}
        <div class=\"linkFieldAdmin--tabsGroup\">{{ group }}</div>
      {%- endif -%}

      <div class=\"linkFieldAdmin--tabsRow\" data-name=\"{{ linkType.name }}\">
        <div class=\"linkFieldAdmin--tabsLightswitch{% if allTypesAllowed %} hidden{% endif %}\">
          {{- forms.lightswitch({
            name: 'allowedLinkNames[]',
            on: linkType.enabled,
            value: linkType.name,
          }) -}}
        </div>

        <button class=\"linkFieldAdmin--tabsTab\">
          {{- linkType.displayName -}}
        </button>
      </div>
    {%- endfor -%}
  </div>
  <div class=\"linkFieldAdmin--body\">
    <div class=\"linkFieldAdmin--bodyContent selected\" data-name=\"_general\">
      {% include 'typedlinkfield/_settings-general' %}
    </div>

    {%- for linkType in linkTypes -%}
      <div class=\"linkFieldAdmin--bodyContent\" data-name=\"{{ linkType.name }}\">
        {{- linkType.settings|raw -}}
      </div>
    {%- endfor -%}
  </div>
</div>

{% js %}
  new LinkFieldAdmin(\"{{ nameNs }}\");
{% endjs %}
", "typedlinkfield/_settings", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_settings.twig");
    }
}
