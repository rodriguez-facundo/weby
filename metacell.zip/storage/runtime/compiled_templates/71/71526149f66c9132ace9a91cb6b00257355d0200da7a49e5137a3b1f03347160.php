<?php

/* typedlinkfield/_settings-general */
class __TwigTemplate_c84d261c5ab18d4d7cfd14aafdf7cf468af5a044fd7b910f1ed3e588d5c47b6b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_settings-general", 1);
        // line 2
        echo "
";
        // line 3
        echo $context["forms"]->macro_selectField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default link type", "typedlinkfield"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Select the preselected link type.", "typedlinkfield"), "id" => "defaultLinkName", "name" => "defaultLinkName", "options" =>         // line 8
(isset($context["linkNames"]) || array_key_exists("linkNames", $context) ? $context["linkNames"] : (function () { throw new Twig_Error_Runtime('Variable "linkNames" does not exist.', 8, $this->source); })()), "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 9
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 9, $this->source); })()), "defaultLinkName", [])]);
        // line 10
        echo "

";
        // line 12
        echo $context["forms"]->macro_textField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Default link text", "typedlinkfield"), "instructions" => $this->extensions['craft\web\twig\Extension']->translateFilter("Set the default value of the link text.", "typedlinkfield"), "name" => "defaultText", "value" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 16
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 16, $this->source); })()), "defaultText", [])]);
        // line 17
        echo "

";
        // line 19
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow custom link text", "typedlinkfield"), "name" => "allowCustomText", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 22
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 22, $this->source); })()), "allowCustomText", [])]);
        // line 23
        echo "

&nbsp;

";
        // line 27
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow links to open in new window", "typedlinkfield"), "name" => "allowTarget", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 30
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 30, $this->source); })()), "allowTarget", [])]);
        // line 31
        echo "

";
        // line 33
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Set link relation to \"noopener noreferrer\" when opening links in a new window", "typedlinkfield"), "name" => "autoNoReferrer", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 36
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 36, $this->source); })()), "autoNoReferrer", [])]);
        // line 37
        echo "

&nbsp;

";
        // line 41
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enable aria label support", "typedlinkfield"), "name" => "enableAriaLabel", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 44
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 44, $this->source); })()), "enableAriaLabel", [])]);
        // line 45
        echo "

";
        // line 47
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Enable title support", "typedlinkfield"), "name" => "enableTitle", "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 50
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 50, $this->source); })()), "enableTitle", [])]);
        // line 51
        echo "
";
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_settings-general";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 51,  76 => 50,  75 => 47,  71 => 45,  69 => 44,  68 => 41,  62 => 37,  60 => 36,  59 => 33,  55 => 31,  53 => 30,  52 => 27,  46 => 23,  44 => 22,  43 => 19,  39 => 17,  37 => 16,  36 => 12,  32 => 10,  30 => 9,  29 => 8,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_includes/forms' as forms %}

{{ forms.selectField({
  label: 'Default link type'|t('typedlinkfield'),
  instructions: 'Select the preselected link type.'|t('typedlinkfield'),
  id: 'defaultLinkName',
  name: 'defaultLinkName',
  options: linkNames,
  value: settings.defaultLinkName,
}) }}

{{ forms.textField({
  label: 'Default link text'|t('typedlinkfield'),
  instructions: 'Set the default value of the link text.'|t('typedlinkfield'),
  name: 'defaultText',
  value: settings.defaultText
}) }}

{{ forms.checkboxField({
  label: 'Allow custom link text'|t('typedlinkfield'),
  name: 'allowCustomText',
  checked: settings.allowCustomText
}) }}

&nbsp;

{{ forms.checkboxField({
  label: 'Allow links to open in new window'|t('typedlinkfield'),
  name: 'allowTarget',
  checked: settings.allowTarget
}) }}

{{ forms.checkboxField({
  label: 'Set link relation to \"noopener noreferrer\" when opening links in a new window'|t('typedlinkfield'),
  name: 'autoNoReferrer',
  checked: settings.autoNoReferrer
}) }}

&nbsp;

{{ forms.checkboxField({
  label: 'Enable aria label support'|t('typedlinkfield'),
  name: 'enableAriaLabel',
  checked: settings.enableAriaLabel
}) }}

{{ forms.checkboxField({
  label: 'Enable title support'|t('typedlinkfield'),
  name: 'enableTitle',
  checked: settings.enableTitle
}) }}
", "typedlinkfield/_settings-general", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_settings-general.twig");
    }
}
