<?php

/* __string_template__dc037687011e1f44c7e4f093b5ed6b09b0ceac184165cd60040cb83cd5886b0d */
class __TwigTemplate_bb0152de46b92b3f344cfd77f9a54ded95306f48a17a7d709121cb2ea9e103f3 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "settings/fields/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "groupId", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "groupId", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "groupId", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "groupId", [])));
    }

    public function getTemplateName()
    {
        return "__string_template__dc037687011e1f44c7e4f093b5ed6b09b0ceac184165cd60040cb83cd5886b0d";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("settings/fields/{{ (_variables.groupId ?? object.groupId)|raw }}", "__string_template__dc037687011e1f44c7e4f093b5ed6b09b0ceac184165cd60040cb83cd5886b0d", "");
    }
}
