<?php

/* _elements/element */
class __TwigTemplate_9ec268ff9ed3d492d96a037b824b6d4934a5927e3099de6266cbcc88a9267bdc extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo \Craft::$app->getView()->invokeHook("cp.elements.element", $context);

    }

    public function getTemplateName()
    {
        return "_elements/element";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% hook \"cp.elements.element\" %}
", "_elements/element", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\_elements\\element.html");
    }
}
