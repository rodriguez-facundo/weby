<?php

/* _components/text/fullWidth.twig */
class __TwigTemplate_ba4f2c4484d8cf714bef34b5a1e16e6650263b062988f12d46a3c93e19930761 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"container content\">
    <div class=\"row\">
        <div class=\"col-12 undefined\">
            ";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 4, $this->source); })()), "text", []), "html", null, true);
        echo "
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/text/fullWidth.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 4,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container content\">
    <div class=\"row\">
        <div class=\"col-12 undefined\">
            {{ component.text }}
        </div>
    </div>
</div>", "_components/text/fullWidth.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\text\\fullWidth.twig");
    }
}
