<?php

/* _components/resourcesSlider/default.twig */
class __TwigTemplate_c84499e7cdb31b161dbec379d9f39eac1461dd682942099f0df4859222ade59a extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/resourcesSlider/default.twig", 1);
        // line 2
        echo "
<div class=\"component-container\">
    <div class=\"resource-list\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content resources-slider\">
            <h2>
                ";
        // line 10
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 10, $this->source); })()), "heading", []), "html", null, true);
        echo "</h2>
            <div class=\"swiper-container swiper-container-horizontal\">
                <div class=\"swiper-wrapper\" style=\"transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;\">
                    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 13, $this->source); })()), "resources", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["resource"]) {
            // line 14
            echo "                        ";
            $context["resEntry"] = craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["resource"], "resource", []), "one", [], "method");
            // line 15
            echo "                        <div class=\"swiper-slide slide swiper-slide-active\" style=\"width: 200px; margin-right: 40px;\">
                            <div class=\"resource-card\">
                                <a class=\"image\" href=\"#\">
                                    ";
            // line 18
            echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["resEntry"]) || array_key_exists("resEntry", $context) ? $context["resEntry"] : (function () { throw new Twig_Error_Runtime('Variable "resEntry" does not exist.', 18, $this->source); })()), "image", []), 0, [], "array"), ["ratio" => (1 / 1), "class" => "rounded", "srcset" => [0 => ["width" => 200, "jpegQuality" => 65]]]);
            // line 26
            echo "
                                </a>
                                <h6 class=\"resource-type\">Event</h6>
                                <div class=\"date\">
                                    <i class=\"icon calendar\"></i>
                                    ";
            // line 31
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->dateFilter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["resEntry"]) || array_key_exists("resEntry", $context) ? $context["resEntry"] : (function () { throw new Twig_Error_Runtime('Variable "resEntry" does not exist.', 31, $this->source); })()), "postDate", []), "d.m.Y"), "html", null, true);
            echo "</div>
                                <h4>
                                    ";
            // line 33
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["resEntry"]) || array_key_exists("resEntry", $context) ? $context["resEntry"] : (function () { throw new Twig_Error_Runtime('Variable "resEntry" does not exist.', 33, $this->source); })()), "title", []), "html", null, true);
            echo "</h4>
                                <p>";
            // line 34
            echo twig_escape_filter($this->env, twig_slice($this->env, strip_tags(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["resEntry"]) || array_key_exists("resEntry", $context) ? $context["resEntry"] : (function () { throw new Twig_Error_Runtime('Variable "resEntry" does not exist.', 34, $this->source); })()), "description", [])), 0, 71), "html", null, true);
            echo "…</p>
                                <a class=\"button-learn-more\" href=\"#\">Learn more</a>
                                <br/>
                                ";
            // line 38
            echo "                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resource'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 41
        echo "                </div>
                <span aria-atomic=\"true\" aria-live=\"assertive\" class=\"swiper-notification\"></span>
            </div>
            <button class=\"swiper-button-next\"></button>
            <button class=\"swiper-button-prev\"></button>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/resourcesSlider/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 41,  77 => 38,  71 => 34,  67 => 33,  62 => 31,  55 => 26,  53 => 18,  48 => 15,  45 => 14,  41 => 13,  35 => 10,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}

<div class=\"component-container\">
    <div class=\"resource-list\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content resources-slider\">
            <h2>
                {{ component.heading }}</h2>
            <div class=\"swiper-container swiper-container-horizontal\">
                <div class=\"swiper-wrapper\" style=\"transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;\">
                    {% for resource in component.resources.all() %}
                        {% set resEntry = resource.resource.one() %}
                        <div class=\"swiper-slide slide swiper-slide-active\" style=\"width: 200px; margin-right: 40px;\">
                            <div class=\"resource-card\">
                                <a class=\"image\" href=\"#\">
                                    {{ imageMacros.image(resEntry.image[0], {
                                ratio: (1/1),
                                class: \"rounded\",
                                srcset: [
                                    { width: 200, jpegQuality: 65 },
                                ]
                            }
                        )   
                    }}
                                </a>
                                <h6 class=\"resource-type\">Event</h6>
                                <div class=\"date\">
                                    <i class=\"icon calendar\"></i>
                                    {{ resEntry.postDate | date(\"d.m.Y\") }}</div>
                                <h4>
                                    {{ resEntry.title }}</h4>
                                <p>{{ resEntry.description|striptags|slice(0,71)}}…</p>
                                <a class=\"button-learn-more\" href=\"#\">Learn more</a>
                                <br/>
                                {# <a class=\"button-download\" href=\"#\">Download Case Study</a> #}
                            </div>
                        </div>
                    {% endfor %}
                </div>
                <span aria-atomic=\"true\" aria-live=\"assertive\" class=\"swiper-notification\"></span>
            </div>
            <button class=\"swiper-button-next\"></button>
            <button class=\"swiper-button-prev\"></button>
        </div>
    </div>
</div>", "_components/resourcesSlider/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\resourcesSlider\\default.twig");
    }
}
