<?php

/* _components/image/default.twig */
class __TwigTemplate_d00cfc12f7c9b6d4b559326b26cb2b325df70769b15653ee63f1920f448cf40a extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/image/default.twig", 1);
        // line 2
        echo "<div class=\"image\">
    ";
        // line 3
        echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 3, $this->source); })()), "image", []), 0, [], "array"), ["ratio" => "", "srcset" => [0 => ["width" => 1600], 1 => ["width" => 1200], 2 => ["width" => 900, "jpegQuality" => 65], 3 => ["width" => 600, "jpegQuality" => 65]]]);
        // line 13
        echo "
</div>";
    }

    public function getTemplateName()
    {
        return "_components/image/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 13,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}
<div class=\"image\">
    {{ imageMacros.image(component.image[0], {
                ratio: \"\",
                srcset: [
                    { width: 1600 },
                    { width: 1200 },
                    { width: 900, jpegQuality: 65 },
                    { width: 600, jpegQuality: 65 },
                ]
            }
        )   
    }}
</div>", "_components/image/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\image\\default.twig");
    }
}
