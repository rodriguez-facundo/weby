<?php

/* homepage/_entry */
class __TwigTemplate_70440ae67e9c2abf48fcb26fc772829c8a53a7717a5953d4885cc8eb0de7e7df extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        // line 1
        $this->parent = $this->loadTemplate("partials/_main", "homepage/_entry", 1);
        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doGetParent(array $context)
    {
        return "partials/_main";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = [])
    {
        // line 3
        echo "    ";
        $this->loadTemplate("_components/include", "homepage/_entry", 3)->display($context);
    }

    public function getTemplateName()
    {
        return "homepage/_entry";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 3,  32 => 2,  15 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'partials/_main' %}
{% block content %}
    {% include '_components/include' %}
{% endblock %}", "homepage/_entry", "E:\\Code\\Craft\\metacell\\templates\\homepage\\_entry.twig");
    }
}
