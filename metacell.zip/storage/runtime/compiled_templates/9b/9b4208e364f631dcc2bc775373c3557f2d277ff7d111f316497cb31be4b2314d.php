<?php

/* typedlinkfield/_settings-input */
class __TwigTemplate_81457afe8d61a636b7691ec5aec2ba412fde84365dd6ded31e17b9b2ccc3817c extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_settings-input", 1);
        // line 2
        echo "
";
        // line 3
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Disable {elementName} input validation", "typedlinkfield", ["elementName" =>         // line 4
(isset($context["elementName"]) || array_key_exists("elementName", $context) ? $context["elementName"] : (function () { throw new Twig_Error_Runtime('Variable "elementName" does not exist.', 4, $this->source); })())]), "id" => (("typeSettings-" .         // line 5
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 5, $this->source); })())) . "-disableValidation"), "name" => (("typeSettings[" .         // line 6
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 6, $this->source); })())) . "][disableValidation]"), "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 7
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 7, $this->source); })()), "disableValidation", [])]);
        // line 8
        echo "

";
        // line 10
        echo $context["forms"]->macro_checkboxField(["label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Allow use of aliases", "typedlinkfield"), "id" => (("typeSettings-" .         // line 12
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 12, $this->source); })())) . "-allowAliases"), "name" => (("typeSettings[" .         // line 13
(isset($context["linkTypeName"]) || array_key_exists("linkTypeName", $context) ? $context["linkTypeName"] : (function () { throw new Twig_Error_Runtime('Variable "linkTypeName" does not exist.', 13, $this->source); })())) . "][allowAliases]"), "checked" => craft\helpers\Template::attribute($this->env, $this->getSourceContext(),         // line 14
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 14, $this->source); })()), "allowAliases", [])]);
        // line 15
        echo "
";
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_settings-input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 15,  41 => 14,  40 => 13,  39 => 12,  38 => 10,  34 => 8,  32 => 7,  31 => 6,  30 => 5,  29 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{{ forms.checkboxField({
  label: 'Disable {elementName} input validation'|t('typedlinkfield', { 'elementName': elementName }),
  id: 'typeSettings-'~linkTypeName~'-disableValidation',
  name: 'typeSettings['~linkTypeName~'][disableValidation]',
  checked: settings.disableValidation,
})}}

{{ forms.checkboxField({
  label: 'Allow use of aliases'|t('typedlinkfield'),
  id: 'typeSettings-'~linkTypeName~'-allowAliases',
  name: 'typeSettings['~linkTypeName~'][allowAliases]',
  checked: settings.allowAliases,
})}}
", "typedlinkfield/_settings-input", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_settings-input.twig");
    }
}
