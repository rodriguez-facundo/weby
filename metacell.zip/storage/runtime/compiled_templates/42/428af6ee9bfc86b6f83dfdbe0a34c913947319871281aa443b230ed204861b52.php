<?php

/* video-embedder/VideoField/settings */
class __TwigTemplate_32e79751236c5a835086db268e33ab0a0a474d1dd9d6d6f61c9a27b009375183 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 11
        echo "
";
        // line 12
        $context["forms"] = $this->loadTemplate("_includes/forms", "video-embedder/VideoField/settings", 12);
    }

    public function getTemplateName()
    {
        return "video-embedder/VideoField/settings";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 12,  23 => 11,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
/**
 * Video Embedder plugin for Craft CMS 3.x
 *
 * Craft plugin to generate an embed URL from a YouTube or Vimeo URL.
 *
 * @link      http://github.com/mikestecker
 * @copyright Copyright (c) 2017 Mike Stecker
 */
#}

{% import \"_includes/forms\" as forms %}
", "video-embedder/VideoField/settings", "E:\\Code\\Craft\\metacell\\vendor\\mikestecker\\craft-videoembedder\\src\\templates\\VideoField\\settings.twig");
    }
}
