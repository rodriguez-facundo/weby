<?php

/* __string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e */
class __TwigTemplate_1644644d2123d19e8d16578ffecebf7d5215b5b8aeae9fa9495d9311de6a9269 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "section", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "section", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "section", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "section", []))), "name", []);
    }

    public function getTemplateName()
    {
        return "__string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{{ (_variables.section ?? object.section).name|raw|raw }}", "__string_template__a234981ccadcdc12f959f62ce3e8b4527e536939c1d42a65bb7375021d22a03e", "");
    }
}
