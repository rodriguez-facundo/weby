<?php

/* __string_template__89ccc0dfe7ff325e4d6c7eecce3a689a8512514908017285752745c7b48b38da */
class __TwigTemplate_94dbbdfe09962775430e6ebe2240b5c6c266149d86b5bfcb7bf0c118d3854145 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "entries/resources/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "id", [])));
        echo "-";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "slug", [])));
    }

    public function getTemplateName()
    {
        return "__string_template__89ccc0dfe7ff325e4d6c7eecce3a689a8512514908017285752745c7b48b38da";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("entries/resources/{{ (_variables.id ?? object.id)|raw }}-{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__89ccc0dfe7ff325e4d6c7eecce3a689a8512514908017285752745c7b48b38da", "");
    }
}
