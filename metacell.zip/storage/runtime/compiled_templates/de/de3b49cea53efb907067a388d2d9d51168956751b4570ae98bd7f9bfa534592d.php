<?php

/* partials/_main */
class __TwigTemplate_929c2e3811e0fea298aafd9ba031acbff11ffb269f862ade16c8e716ced33b29 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'content' => [$this, 'block_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<!doctype html>
<html lang=\"en\">
    <head>
        ";
        // line 5
        echo "        <meta charset=\"utf-8\">
            <meta
                content=\"width=device-width, initial-scale=1, shrink-to-fit=no\" name=\"viewport\">
                ";
        // line 9
        echo "                <link
                    href=\"assets/css/app.css\" rel=\"stylesheet\">";
        // line 11
        echo "                ";
        call_user_func_array($this->env->getFunction('head')->getCallable(), []);
        echo "</head>
                <body>";
        // line 12
        call_user_func_array($this->env->getFunction('beginBody')->getCallable(), []);
        echo "
                    ";
        // line 13
        $this->loadTemplate("partials/_header", "partials/_main", 13)->display($context);
        // line 14
        echo "                    ";
        $this->displayBlock('content', $context, $blocks);
        // line 15
        echo "                    ";
        $this->loadTemplate("partials/_footer", "partials/_main", 15)->display($context);
        // line 16
        echo "                    ";
        echo "<script async=\"\" src=\"assets/js/lazysizes.min.js\"> </script>
                ";
        // line 17
        call_user_func_array($this->env->getFunction('endBody')->getCallable(), []);
        echo "</body>
            </html>
        ";
    }

    // line 14
    public function block_content($context, array $blocks = [])
    {
    }

    public function getTemplateName()
    {
        return "partials/_main";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 14,  58 => 17,  54 => 16,  51 => 15,  48 => 14,  46 => 13,  42 => 12,  37 => 11,  34 => 9,  29 => 5,  24 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!doctype html>
<html lang=\"en\">
    <head>
        {# Required meta tags #}
        <meta charset=\"utf-8\">
            <meta
                content=\"width=device-width, initial-scale=1, shrink-to-fit=no\" name=\"viewport\">
                {# CSS #}
                <link
                    href=\"assets/css/app.css\" rel=\"stylesheet\">{# {% hook \"seo\" %} #}
                </head>
                <body>
                    {% include 'partials/_header' %}
                    {% block content %}{% endblock %}
                    {% include 'partials/_footer' %}{#  JavaScript  #}
                    {# <script src=\"{{ mix('js/app.js') }}\"></script> #}<script async=\"\" src=\"assets/js/lazysizes.min.js\"> </script>
                </body>
            </html>
        ", "partials/_main", "E:\\Code\\Craft\\metacell\\templates\\partials\\_main.twig");
    }
}
