<?php

/* video-embedder/VideoField/input */
class __TwigTemplate_9323cc4b45f5ecc16b51a441408e5c4b37308517ca6a105bbfe66c9543f91456 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 11
        echo "
";
        // line 12
        $context["forms"] = $this->loadTemplate("_includes/forms", "video-embedder/VideoField/input", 12);
        // line 13
        echo "
<div class=\"video-embedder-container\">

    <div class=\"video-embedder-urlContainer flex\">
        <div class=\"texticon search icon clearable flex-grow\">
            ";
        // line 18
        echo $context["forms"]->macro_text(["id" =>         // line 19
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 19, $this->source); })()), "name" =>         // line 20
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 20, $this->source); })()), "type" => "url", "placeholder" => "Only YouTube and Vimeo supported.", "value" => ((        // line 23
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 23, $this->source); })())) ? ((isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 23, $this->source); })())) : ("")), "class" => "video-embedder-url"]);
        // line 25
        echo "
        </div>
    </div>

    <div class=\"video-embedder-previewContainer\">
        ";
        // line 30
        $this->loadTemplate("video-embedder/VideoField/inputEmbed.twig", "video-embedder/VideoField/input", 30)->display(["name" =>         // line 31
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 31, $this->source); })()), "value" =>         // line 32
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 32, $this->source); })())]);
        // line 34
        echo "    </div>

</div>



";
    }

    public function getTemplateName()
    {
        return "video-embedder/VideoField/input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 34,  49 => 32,  48 => 31,  47 => 30,  40 => 25,  38 => 23,  37 => 20,  36 => 19,  35 => 18,  28 => 13,  26 => 12,  23 => 11,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
/**
 * Video Embedder plugin for Craft CMS 3.x
 *
 * Craft plugin to generate an embed URL from a YouTube or Vimeo URL.
 *
 * @link      http://github.com/mikestecker
 * @copyright Copyright (c) 2017 Mike Stecker
 */
#}

{% import \"_includes/forms\" as forms %}

<div class=\"video-embedder-container\">

    <div class=\"video-embedder-urlContainer flex\">
        <div class=\"texticon search icon clearable flex-grow\">
            {{ forms.text({
                id: name,
                name: name,
                type: 'url',
                placeholder: 'Only YouTube and Vimeo supported.',
                value: value ? value,
                class: 'video-embedder-url'
            }) }}
        </div>
    </div>

    <div class=\"video-embedder-previewContainer\">
        {% include 'video-embedder/VideoField/inputEmbed.twig' with {
            name: name,
            value: value
        } only %}
    </div>

</div>



", "video-embedder/VideoField/input", "E:\\Code\\Craft\\metacell\\vendor\\mikestecker\\craft-videoembedder\\src\\templates\\VideoField\\input.twig");
    }
}
