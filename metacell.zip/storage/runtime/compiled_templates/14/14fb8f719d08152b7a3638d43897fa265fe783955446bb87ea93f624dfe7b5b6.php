<?php

/* _components/team/default.twig */
class __TwigTemplate_a377090cf64024b5f3b3a0db358998a7b918585700077e505d22390e76096b8b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/team/default.twig", 1);
        // line 2
        echo "<div class=\"component-container\">
    <div class=\"team\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content\">
            <div class=\"team-inner\">
                <div class=\"flex-row\">
                    ";
        // line 10
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 10, $this->source); })()), "team", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["member"]) {
            // line 11
            echo "                        <div class=\"flex-col-large\">
                            <div class=\"team-member \">
                                ";
            // line 13
            echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["member"], "image", []), "one", [], "method"), ["ratio" => (1 / 1), "class" => "rounded", "srcset" => [0 => ["width" => 250, "jpegQuality" => 85]]]);
            // line 21
            echo "
                                <div class=\"team-member-contacts\">
                                    ";
            // line 23
            if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["member"], "linketin", []), "isEmpty", [], "method")) {
                // line 24
                echo "                                        <a href=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["member"], "linketin", []), "getUrl", [], "method"), "html", null, true);
                echo "\">
                                            <i class=\"icon linkedin\"></i>
                                        </a>
                                    ";
            }
            // line 28
            echo "                                    ";
            if ( !craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["member"], "email", []), "isEmpty", [], "method")) {
                // line 29
                echo "                                        <a href=\"";
                echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["member"], "email", []), "getUrl", [], "method"), "html", null, true);
                echo "\">
                                            <i class=\"icon email\"></i>
                                        </a>
                                    ";
            }
            // line 33
            echo "                                </div>
                                <h6>
                                    ";
            // line 35
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["member"], "title", []), "html", null, true);
            echo "
                                </h6>
                                <div class=\"team-member-description\">
                                    ";
            // line 38
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["member"], "description", []), "html", null, true);
            echo "
                                </div>
                                <a class=\"button-expand\" href=\"#\">Expand</a>
                            </div>
                        </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['member'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 44
        echo "                </div>
            </div>
        </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "_components/team/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  92 => 44,  80 => 38,  74 => 35,  70 => 33,  62 => 29,  59 => 28,  51 => 24,  49 => 23,  45 => 21,  43 => 13,  39 => 11,  35 => 10,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}
<div class=\"component-container\">
    <div class=\"team\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content\">
            <div class=\"team-inner\">
                <div class=\"flex-row\">
                    {% for member in component.team.all() %}
                        <div class=\"flex-col-large\">
                            <div class=\"team-member \">
                                {{ imageMacros.image(member.image.one(), {
                                            ratio: (1/1),
                                            class: \"rounded\",
                                            srcset: [
                                                { width: 250, jpegQuality: 85 },
                                            ]
                                        }
                                    )   
                                }}
                                <div class=\"team-member-contacts\">
                                    {% if not member.linketin.isEmpty() %}
                                        <a href=\"{{ member.linketin.getUrl() }}\">
                                            <i class=\"icon linkedin\"></i>
                                        </a>
                                    {% endif %}
                                    {% if not member.email.isEmpty() %}
                                        <a href=\"{{ member.email.getUrl() }}\">
                                            <i class=\"icon email\"></i>
                                        </a>
                                    {% endif %}
                                </div>
                                <h6>
                                    {{ member.title }}
                                </h6>
                                <div class=\"team-member-description\">
                                    {{ member.description }}
                                </div>
                                <a class=\"button-expand\" href=\"#\">Expand</a>
                            </div>
                        </div>
                    {% endfor %}
                </div>
            </div>
        </div>
    </div>
", "_components/team/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\team\\default.twig");
    }
}
