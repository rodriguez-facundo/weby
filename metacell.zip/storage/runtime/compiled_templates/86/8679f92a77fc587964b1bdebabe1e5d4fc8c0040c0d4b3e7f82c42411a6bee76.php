<?php

/* template-select/_components/fields/_input */
class __TwigTemplate_c7bc0f12037927044927b82659352aeaced561b3d6522ddde1235cfb1b873ae4 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 14
        echo "
";
        // line 15
        $context["forms"] = $this->loadTemplate("_includes/forms", "template-select/_components/fields/_input", 15);
        // line 16
        echo "
";
        // line 17
        echo $context["forms"]->macro_selectField(["label" => "", "id" =>         // line 19
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 19, $this->source); })()), "name" =>         // line 20
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 20, $this->source); })()), "options" =>         // line 21
(isset($context["templates"]) || array_key_exists("templates", $context) ? $context["templates"] : (function () { throw new Twig_Error_Runtime('Variable "templates" does not exist.', 21, $this->source); })()), "value" =>         // line 22
(isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 22, $this->source); })())]);
        // line 23
        echo "
";
    }

    public function getTemplateName()
    {
        return "template-select/_components/fields/_input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 23,  35 => 22,  34 => 21,  33 => 20,  32 => 19,  31 => 17,  28 => 16,  26 => 15,  23 => 14,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
/**
 * Template Select plugin for Craft CMS 3.x
 *
 *  Field Input
 *
 * @author    Superbig
 * @copyright Copyright (c) 2017 Superbig
 * @link      https://superbig.co
 * @package   TemplateSelect
 * @since     2.0.0
 */
#}

{% import \"_includes/forms\" as forms %}

{{ forms.selectField({
        label: '',
        id: name,
        name: name,
        options: templates,
        value: value})
}}
", "template-select/_components/fields/_input", "E:\\Code\\Craft\\metacell\\vendor\\superbig\\craft3-templateselect\\src\\templates\\_components\\fields\\_input.twig");
    }
}
