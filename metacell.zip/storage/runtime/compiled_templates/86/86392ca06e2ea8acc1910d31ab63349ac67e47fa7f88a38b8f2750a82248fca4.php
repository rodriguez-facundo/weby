<?php

/* typedlinkfield/_input */
class __TwigTemplate_9bc293cc90b33e9715ffdcb642d66cc068cc6e6170b818f8fcdd790d5558a4f8 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["forms"] = $this->loadTemplate("_includes/forms", "typedlinkfield/_input", 1);
        // line 2
        echo "
";
        // line 3
        craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["view"]) || array_key_exists("view", $context) ? $context["view"] : (function () { throw new Twig_Error_Runtime('Variable "view" does not exist.', 3, $this->source); })()), "registerAssetBundle", [0 => "typedlinkfield\\utilities\\CpAssetBundle"], "method");
        // line 4
        echo "
";
        // line 5
        $context["type"] = (((isset($context["singleType"]) || array_key_exists("singleType", $context) ? $context["singleType"] : (function () { throw new Twig_Error_Runtime('Variable "singleType" does not exist.', 5, $this->source); })())) ? ((isset($context["singleType"]) || array_key_exists("singleType", $context) ? $context["singleType"] : (function () { throw new Twig_Error_Runtime('Variable "singleType" does not exist.', 5, $this->source); })())) : ((((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["value"] ?? null), "type", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 5, $this->source); })()), "type", []))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 5, $this->source); })()), "type", [])) : (null))));
        // line 6
        echo "
<div class=\"linkfield";
        // line 7
        if ((isset($context["hasSettings"]) || array_key_exists("hasSettings", $context) ? $context["hasSettings"] : (function () { throw new Twig_Error_Runtime('Variable "hasSettings" does not exist.', 7, $this->source); })())) {
            echo " withSettings";
        }
        echo "\" id=\"";
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 7, $this->source); })()), "html", null, true);
        echo "\">
  ";
        // line 8
        if ((twig_length_filter($this->env, (isset($context["linkNames"]) || array_key_exists("linkNames", $context) ? $context["linkNames"] : (function () { throw new Twig_Error_Runtime('Variable "linkNames" does not exist.', 8, $this->source); })())) == 0)) {
            // line 9
            echo "    <p>";
            echo twig_escape_filter($this->env, $this->extensions['craft\web\twig\Extension']->translateFilter("No link types available.", "typedlinkfield"), "html", null, true);
            echo "</p>
  ";
        } else {
            // line 11
            echo "    <div class=\"linkfield--field";
            if ((isset($context["hasSettings"]) || array_key_exists("hasSettings", $context) ? $context["hasSettings"] : (function () { throw new Twig_Error_Runtime('Variable "hasSettings" does not exist.', 11, $this->source); })())) {
                echo " field";
            }
            echo "\">
      ";
            // line 12
            if ((isset($context["singleType"]) || array_key_exists("singleType", $context) ? $context["singleType"] : (function () { throw new Twig_Error_Runtime('Variable "singleType" does not exist.', 12, $this->source); })())) {
                // line 13
                echo "        <input type=\"hidden\" id=\"";
                echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 13, $this->source); })()), "html", null, true);
                echo "-type\" name=\"";
                echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 13, $this->source); })()), "html", null, true);
                echo "[type]\" value=\"";
                echo twig_escape_filter($this->env, (isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 13, $this->source); })()), "html", null, true);
                echo "\" />
      ";
            } else {
                // line 15
                echo "        <div class=\"linkfield--type\">
          ";
                // line 16
                echo $context["forms"]->macro_select(["disabled" =>                 // line 17
(isset($context["isStatic"]) || array_key_exists("isStatic", $context) ? $context["isStatic"] : (function () { throw new Twig_Error_Runtime('Variable "isStatic" does not exist.', 17, $this->source); })()), "id" => (                // line 18
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 18, $this->source); })()) . "-Type"), "name" => (                // line 19
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 19, $this->source); })()) . "[type]"), "options" =>                 // line 20
(isset($context["linkNames"]) || array_key_exists("linkNames", $context) ? $context["linkNames"] : (function () { throw new Twig_Error_Runtime('Variable "linkNames" does not exist.', 20, $this->source); })()), "value" =>                 // line 21
(isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 21, $this->source); })())]);
                // line 22
                echo "
        </div>
      ";
            }
            // line 25
            echo "
      <div class=\"linkfield--typeOptions";
            // line 26
            if ((isset($context["singleType"]) || array_key_exists("singleType", $context) ? $context["singleType"] : (function () { throw new Twig_Error_Runtime('Variable "singleType" does not exist.', 26, $this->source); })())) {
                echo " single";
            }
            echo "\">
        ";
            // line 27
            echo (isset($context["linkInputs"]) || array_key_exists("linkInputs", $context) ? $context["linkInputs"] : (function () { throw new Twig_Error_Runtime('Variable "linkInputs" does not exist.', 27, $this->source); })());
            echo "
      </div>

      ";
            // line 30
            if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 30, $this->source); })()), "allowTarget", [])) {
                // line 31
                echo "        <div class=\"linkfield--target\">
          ";
                // line 32
                echo $context["forms"]->macro_checkboxField(["disabled" =>                 // line 33
(isset($context["isStatic"]) || array_key_exists("isStatic", $context) ? $context["isStatic"] : (function () { throw new Twig_Error_Runtime('Variable "isStatic" does not exist.', 33, $this->source); })()), "id" => (                // line 34
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 34, $this->source); })()) . "-Target"), "name" => (                // line 35
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 35, $this->source); })()) . "[target]"), "value" => "_blank", "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Open in new window?", "typedlinkfield"), "checked" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                 // line 38
($context["value"] ?? null), "target", [], "any", true, true) && (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 38, $this->source); })()), "target", []) == "_blank"))) ? (true) : (null))]);
                // line 39
                echo "
        </div>
      ";
            }
            // line 42
            echo "    </div>

    ";
            // line 44
            if ((isset($context["hasSettings"]) || array_key_exists("hasSettings", $context) ? $context["hasSettings"] : (function () { throw new Twig_Error_Runtime('Variable "hasSettings" does not exist.', 44, $this->source); })())) {
                // line 45
                echo "      <div class=\"linkfield--settings";
                echo ((((isset($context["type"]) || array_key_exists("type", $context) ? $context["type"] : (function () { throw new Twig_Error_Runtime('Variable "type" does not exist.', 45, $this->source); })()) == "")) ? (" hidden") : (""));
                echo "\">
        ";
                // line 46
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 46, $this->source); })()), "allowCustomText", [])) {
                    // line 47
                    echo "          ";
                    echo $context["forms"]->macro_textField(["disabled" =>                     // line 48
(isset($context["isStatic"]) || array_key_exists("isStatic", $context) ? $context["isStatic"] : (function () { throw new Twig_Error_Runtime('Variable "isStatic" does not exist.', 48, $this->source); })()), "id" => (                    // line 49
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 49, $this->source); })()) . "-customText"), "name" => (                    // line 50
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 50, $this->source); })()) . "[customText]"), "placeholder" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 51
(isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 51, $this->source); })()), "defaultText", []) == "")) ? ($this->extensions['craft\web\twig\Extension']->translateFilter("Custom link text", "typedlinkfield")) : ($this->extensions['craft\web\twig\Extension']->translateFilter(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 51, $this->source); })()), "defaultText", []), "site"))), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Custom link text", "typedlinkfield"), "value" => (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 53
($context["value"] ?? null), "customText", [], "any", true, true) && craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 53, $this->source); })()), "customText", []))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 53, $this->source); })()), "customText", [])) : (""))]);
                    // line 54
                    echo "
        ";
                }
                // line 56
                echo "
        ";
                // line 57
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 57, $this->source); })()), "enableAriaLabel", [])) {
                    // line 58
                    echo "          ";
                    echo $context["forms"]->macro_textField(["disabled" =>                     // line 59
(isset($context["isStatic"]) || array_key_exists("isStatic", $context) ? $context["isStatic"] : (function () { throw new Twig_Error_Runtime('Variable "isStatic" does not exist.', 59, $this->source); })()), "id" => (                    // line 60
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 60, $this->source); })()) . "-AriaLabel"), "name" => (                    // line 61
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 61, $this->source); })()) . "[ariaLabel]"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Aria label", "typedlinkfield"), "value" => ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 63
($context["value"] ?? null), "ariaLabel", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 63, $this->source); })()), "ariaLabel", [])) : (""))]);
                    // line 64
                    echo "
        ";
                }
                // line 66
                echo "
        ";
                // line 67
                if (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["settings"]) || array_key_exists("settings", $context) ? $context["settings"] : (function () { throw new Twig_Error_Runtime('Variable "settings" does not exist.', 67, $this->source); })()), "enableTitle", [])) {
                    // line 68
                    echo "          ";
                    echo $context["forms"]->macro_textField(["disabled" =>                     // line 69
(isset($context["isStatic"]) || array_key_exists("isStatic", $context) ? $context["isStatic"] : (function () { throw new Twig_Error_Runtime('Variable "isStatic" does not exist.', 69, $this->source); })()), "id" => (                    // line 70
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 70, $this->source); })()) . "-Title"), "name" => (                    // line 71
(isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 71, $this->source); })()) . "[title]"), "label" => $this->extensions['craft\web\twig\Extension']->translateFilter("Title", "typedlinkfield"), "value" => ((craft\helpers\Template::attribute($this->env, $this->getSourceContext(),                     // line 73
($context["value"] ?? null), "title", [], "any", true, true)) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["value"]) || array_key_exists("value", $context) ? $context["value"] : (function () { throw new Twig_Error_Runtime('Variable "value" does not exist.', 73, $this->source); })()), "title", [])) : (""))]);
                    // line 74
                    echo "
        ";
                }
                // line 76
                echo "      </div>
    ";
            }
            // line 78
            echo "  ";
        }
        // line 79
        echo "
  <input type=\"hidden\" id=\"";
        // line 80
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 80, $this->source); })()), "html", null, true);
        echo "-isCpFormData\" name=\"";
        echo twig_escape_filter($this->env, (isset($context["name"]) || array_key_exists("name", $context) ? $context["name"] : (function () { throw new Twig_Error_Runtime('Variable "name" does not exist.', 80, $this->source); })()), "html", null, true);
        echo "[isCpFormData]\" value=\"true\" />
</div>

";
        // line 83
        ob_start();
        // line 84
        echo "  new LinkField(\"";
        echo twig_escape_filter($this->env, (isset($context["nameNs"]) || array_key_exists("nameNs", $context) ? $context["nameNs"] : (function () { throw new Twig_Error_Runtime('Variable "nameNs" does not exist.', 84, $this->source); })()), "html", null, true);
        echo "\");
";
        Craft::$app->getView()->registerJs(ob_get_clean(), 3);
    }

    public function getTemplateName()
    {
        return "typedlinkfield/_input";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  196 => 84,  194 => 83,  186 => 80,  183 => 79,  180 => 78,  176 => 76,  172 => 74,  170 => 73,  169 => 71,  168 => 70,  167 => 69,  165 => 68,  163 => 67,  160 => 66,  156 => 64,  154 => 63,  153 => 61,  152 => 60,  151 => 59,  149 => 58,  147 => 57,  144 => 56,  140 => 54,  138 => 53,  137 => 51,  136 => 50,  135 => 49,  134 => 48,  132 => 47,  130 => 46,  125 => 45,  123 => 44,  119 => 42,  114 => 39,  112 => 38,  111 => 35,  110 => 34,  109 => 33,  108 => 32,  105 => 31,  103 => 30,  97 => 27,  91 => 26,  88 => 25,  83 => 22,  81 => 21,  80 => 20,  79 => 19,  78 => 18,  77 => 17,  76 => 16,  73 => 15,  63 => 13,  61 => 12,  54 => 11,  48 => 9,  46 => 8,  38 => 7,  35 => 6,  33 => 5,  30 => 4,  28 => 3,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import \"_includes/forms\" as forms %}

{% do view.registerAssetBundle('typedlinkfield\\\\utilities\\\\CpAssetBundle') %}

{% set type = singleType ? singleType : ( value.type is defined and value.type ? value.type : null) %}

<div class=\"linkfield{% if hasSettings %} withSettings{% endif %}\" id=\"{{ name }}\">
  {% if linkNames|length == 0 %}
    <p>{{ 'No link types available.'|t('typedlinkfield') }}</p>
  {% else %}
    <div class=\"linkfield--field{% if hasSettings %} field{% endif %}\">
      {% if singleType %}
        <input type=\"hidden\" id=\"{{ name }}-type\" name=\"{{ name }}[type]\" value=\"{{ type }}\" />
      {% else %}
        <div class=\"linkfield--type\">
          {{ forms.select({
            disabled: isStatic,
            id: name~'-Type',
            name: name~'[type]',
            options: linkNames,
            value: type
          }) }}
        </div>
      {% endif %}

      <div class=\"linkfield--typeOptions{% if singleType %} single{% endif %}\">
        {{ linkInputs|raw }}
      </div>

      {% if settings.allowTarget %}
        <div class=\"linkfield--target\">
          {{ forms.checkboxField({
            disabled: isStatic,
            id: name~'-Target',
            name: name~'[target]',
            value: '_blank',
            label: 'Open in new window?'|t('typedlinkfield'),
            checked: value.target is defined and value.target == '_blank' ? true : null
          }) }}
        </div>
      {% endif %}
    </div>

    {% if hasSettings %}
      <div class=\"linkfield--settings{{ type == '' ? ' hidden' }}\">
        {% if settings.allowCustomText %}
          {{ forms.textField({
            disabled: isStatic,
            id: name~'-customText',
            name: name~'[customText]',
            placeholder: settings.defaultText == '' ? 'Custom link text'|t('typedlinkfield') : settings.defaultText|t('site'),
            label: 'Custom link text'|t('typedlinkfield'),
            value: value.customText is defined and value.customText ? value.customText
          }) }}
        {% endif %}

        {% if settings.enableAriaLabel %}
          {{ forms.textField({
            disabled: isStatic,
            id: name~'-AriaLabel',
            name: name~'[ariaLabel]',
            label: 'Aria label'|t('typedlinkfield'),
            value: value.ariaLabel is defined ? value.ariaLabel : \"\"
          }) }}
        {% endif %}

        {% if settings.enableTitle %}
          {{ forms.textField({
            disabled: isStatic,
            id: name~'-Title',
            name: name~'[title]',
            label: 'Title'|t('typedlinkfield'),
            value: value.title is defined ? value.title : \"\"
          }) }}
        {% endif %}
      </div>
    {% endif %}
  {% endif %}

  <input type=\"hidden\" id=\"{{ name }}-isCpFormData\" name=\"{{ name }}[isCpFormData]\" value=\"true\" />
</div>

{% js %}
  new LinkField(\"{{ nameNs }}\");
{% endjs %}
", "typedlinkfield/_input", "E:\\Code\\Craft\\metacell\\vendor\\sebastianlenz\\linkfield\\src\\templates\\_input.twig");
    }
}
