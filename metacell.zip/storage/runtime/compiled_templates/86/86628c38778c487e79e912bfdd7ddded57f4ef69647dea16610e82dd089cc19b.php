<?php

/* __string_template__5e17d9e7200b000ba81a7c6facf138850c4f05a6782c7d28a024588ae211f461 */
class __TwigTemplate_2a70408d095ce2af83c0d393476d5e5bec08032444f2dda64f29f1c0bb4dbb2f extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "entries/homepage/";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "id", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "id", [])));
        echo "-";
        echo (((craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [], "any", true, true) &&  !(null === craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])))) ? (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), ($context["_variables"] ?? null), "slug", [])) : (craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["object"]) || array_key_exists("object", $context) ? $context["object"] : (function () { throw new Twig_Error_Runtime('Variable "object" does not exist.', 1, $this->source); })()), "slug", [])));
    }

    public function getTemplateName()
    {
        return "__string_template__5e17d9e7200b000ba81a7c6facf138850c4f05a6782c7d28a024588ae211f461";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("entries/homepage/{{ (_variables.id ?? object.id)|raw }}-{{ (_variables.slug ?? object.slug)|raw }}", "__string_template__5e17d9e7200b000ba81a7c6facf138850c4f05a6782c7d28a024588ae211f461", "");
    }
}
