<?php

/* partials/_footer */
class __TwigTemplate_2a96d8c716756b288162456ce46e9d8ce80ba52ca5b27e0444957c7d26ac682b extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"component-container\">
    <div class=\"footer\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content\">
            <div class=\"row\">
                <div class=\"col-2\">
                    <h6>Navigate MetaCell</h6>
                    <nav>
                        <ul>
                            <li><a href=\"#\">Pharma Companies</a></li>
                            <li><a href=\"#\">Research and academia</a></li>
                        </ul>
                    </nav>
                </div>
                <div class=\"col-2\">
                    <h6>About MetaCell</h6>
                    <nav>
                        <ul>
                            <li><a href=\"#\">Our Company</a></li>
                            <li><a href=\"#\">Our Platform</a></li>
                            <li><a href=\"#\">Our Team</a></li>
                            <li><a href=\"#\">Our Portfolio</a></li>
                        </ul>
                    </nav>
                </div>
                <div class=\"col-2\">
                    <h6>Contact us</h6>
                    <nav>
                        <ul>
                            <li><a href=\"#\">Offline Locations</a></li>
                            <li><a href=\"#\">For Investors</a></li>
                            <li><a href=\"#\">For Media</a></li>
                        </ul>
                    </nav>
                </div>
                <div class=\"col-2\">
                    <h6>Subscribe to MetaCell</h6>
                    <form action=\"\">
                        <div class=\"form-group\">
                            <input placeholder=\"your email\" type=\"email\">
                                <div class=\"form-group checkbox\">
                                    <label class=\"control-label\">
                                        <input type=\"checkbox\">I agree to
                                            <a href=\"#\">terms</a>
                                        </label>
                                    </div>
                                    <button class=\"btn-primary\" type=\"submit\">Subscribe</button>
                                </div>
                            </form>
                        </div>
                        <div class=\"col-2\">
                            <h6>Follow us:</h6>
                            <div class=\"social-icons\">
                                <a class=\"icon twitter\" href=\"#\">Twitter</a>
                                <a class=\"icon linkedin\" href=\"#\">LinkedIn</a>
                                <a class=\"icon youtube\" href=\"#\">YouTube</a>
                            </div>
                            <h6>Join us:</h6>
                            <a class=\"btn-secondary\" href=\"#\">Send your CV</a>
                        </div>
                    </div>
                    <div class=\"copyright\">
                        <h1 class=\"logo\">
                            <a href=\"#\">MetaCell</a>
                        </h1>
                        <nav>
                            <a href=\"#\">Copyright</a>
                            <a href=\"#\">Terms of Use</a>
                            <a href=\"#\">Privacy policy</a>
                            <a href=\"#\">About Cookies</a>
                            <a href=\"#\">Contact Us</a>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    ";
    }

    public function getTemplateName()
    {
        return "partials/_footer";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"component-container\">
    <div class=\"footer\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content\">
            <div class=\"row\">
                <div class=\"col-2\">
                    <h6>Navigate MetaCell</h6>
                    <nav>
                        <ul>
                            <li><a href=\"#\">Pharma Companies</a></li>
                            <li><a href=\"#\">Research and academia</a></li>
                        </ul>
                    </nav>
                </div>
                <div class=\"col-2\">
                    <h6>About MetaCell</h6>
                    <nav>
                        <ul>
                            <li><a href=\"#\">Our Company</a></li>
                            <li><a href=\"#\">Our Platform</a></li>
                            <li><a href=\"#\">Our Team</a></li>
                            <li><a href=\"#\">Our Portfolio</a></li>
                        </ul>
                    </nav>
                </div>
                <div class=\"col-2\">
                    <h6>Contact us</h6>
                    <nav>
                        <ul>
                            <li><a href=\"#\">Offline Locations</a></li>
                            <li><a href=\"#\">For Investors</a></li>
                            <li><a href=\"#\">For Media</a></li>
                        </ul>
                    </nav>
                </div>
                <div class=\"col-2\">
                    <h6>Subscribe to MetaCell</h6>
                    <form action=\"\">
                        <div class=\"form-group\">
                            <input placeholder=\"your email\" type=\"email\">
                                <div class=\"form-group checkbox\">
                                    <label class=\"control-label\">
                                        <input type=\"checkbox\">I agree to
                                            <a href=\"#\">terms</a>
                                        </label>
                                    </div>
                                    <button class=\"btn-primary\" type=\"submit\">Subscribe</button>
                                </div>
                            </form>
                        </div>
                        <div class=\"col-2\">
                            <h6>Follow us:</h6>
                            <div class=\"social-icons\">
                                <a class=\"icon twitter\" href=\"#\">Twitter</a>
                                <a class=\"icon linkedin\" href=\"#\">LinkedIn</a>
                                <a class=\"icon youtube\" href=\"#\">YouTube</a>
                            </div>
                            <h6>Join us:</h6>
                            <a class=\"btn-secondary\" href=\"#\">Send your CV</a>
                        </div>
                    </div>
                    <div class=\"copyright\">
                        <h1 class=\"logo\">
                            <a href=\"#\">MetaCell</a>
                        </h1>
                        <nav>
                            <a href=\"#\">Copyright</a>
                            <a href=\"#\">Terms of Use</a>
                            <a href=\"#\">Privacy policy</a>
                            <a href=\"#\">About Cookies</a>
                            <a href=\"#\">Contact Us</a>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    ", "partials/_footer", "E:\\Code\\Craft\\metacell\\templates\\partials\\_footer.twig");
    }
}
