<?php

/* _elements/thumbsview/container */
class __TwigTemplate_ceccec6dddb1320b64467f61bc55f51d79e27223d2b4b492356271ac7151fb80 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<ul class=\"thumbsview\">
    ";
        // line 2
        $this->loadTemplate("_elements/thumbsview/elements", "_elements/thumbsview/container", 2)->display($context);
        // line 3
        echo "</ul>
<div class=\"clear\"></div>
";
    }

    public function getTemplateName()
    {
        return "_elements/thumbsview/container";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 3,  26 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<ul class=\"thumbsview\">
    {% include \"_elements/thumbsview/elements\" %}
</ul>
<div class=\"clear\"></div>
", "_elements/thumbsview/container", "E:\\Code\\Craft\\metacell\\vendor\\craftcms\\cms\\src\\templates\\_elements\\thumbsview\\container.html");
    }
}
