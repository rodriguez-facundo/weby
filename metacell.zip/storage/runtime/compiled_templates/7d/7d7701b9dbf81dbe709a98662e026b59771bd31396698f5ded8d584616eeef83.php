<?php

/* _components/navigation/default.twig */
class __TwigTemplate_918e8698085c48526986d5cee0ab85a6d166f3b0ff247cc2ea1a8f68c85b72b1 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        $context["imageMacros"] = $this->loadTemplate("_macros/image", "_components/navigation/default.twig", 1);
        // line 2
        echo "<div class=\"component-container\">
    <div class=\"navigation\">
        <div class=\"container\">
            <nav>
                ";
        // line 6
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 6, $this->source); })()), "links", []), "all", [], "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
            // line 7
            echo "                    <a href=\"";
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["link"], "linkTo", []), "getUrl", [], "method"), "html", null, true);
            echo "\">
                        <img alt=\"\" src=\"/static/images/icon-1.svg\"/>
                        ";
            // line 9
            echo $context["imageMacros"]->macro_image(craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["link"], "image", []), "one", [], "method"), ["ratio" => (1 / 1), "srcset" => [0 => ["width" => 40, "jpegQuality" => 80]]]);
            // line 16
            echo "
                        <span class=\"link-text\">";
            // line 17
            echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), craft\helpers\Template::attribute($this->env, $this->getSourceContext(), $context["link"], "linkTo", []), "getText", [], "method"), "html", null, true);
            echo "</span>
                    </a>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['link'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 20
        echo "            </nav>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/navigation/default.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 20,  46 => 17,  43 => 16,  41 => 9,  35 => 7,  31 => 6,  25 => 2,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% import '_macros/image' as imageMacros %}
<div class=\"component-container\">
    <div class=\"navigation\">
        <div class=\"container\">
            <nav>
                {% for link in component.links.all() %}
                    <a href=\"{{ link.linkTo.getUrl() }}\">
                        <img alt=\"\" src=\"/static/images/icon-1.svg\"/>
                        {{ imageMacros.image(link.image.one(), {
                                    ratio: (1/1),
                                    srcset: [
                                        { width: 40, jpegQuality: 80 },
                                    ]
                                }
                            )   
                        }}
                        <span class=\"link-text\">{{ link.linkTo.getText() }}</span>
                    </a>
                {% endfor %}
            </nav>
        </div>
    </div>
</div>", "_components/navigation/default.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\navigation\\default.twig");
    }
}
