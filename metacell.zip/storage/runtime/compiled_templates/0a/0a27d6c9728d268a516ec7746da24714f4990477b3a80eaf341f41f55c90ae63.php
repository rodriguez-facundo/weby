<?php

/* _components/text/shiftedCentered.twig */
class __TwigTemplate_8b4e746363559908d89a4e10fcfb863403f44746ad2a3f2590e1ad2e61725d68 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"container content\">
    <div class=\"row\">
        <div class=\"shift-2 text-centered\">
            ";
        // line 4
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 4, $this->source); })()), "text", []), "html", null, true);
        echo "
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/text/shiftedCentered.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 4,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"container content\">
    <div class=\"row\">
        <div class=\"shift-2 text-centered\">
            {{ component.text }}
        </div>
    </div>
</div>", "_components/text/shiftedCentered.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\text\\shiftedCentered.twig");
    }
}
