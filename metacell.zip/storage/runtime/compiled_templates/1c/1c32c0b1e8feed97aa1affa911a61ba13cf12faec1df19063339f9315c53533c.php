<?php

/* _components/text/shifted.twig */
class __TwigTemplate_0483608edcf911e58616166434d72359cff7c95f42a11e15402d04c6144ebf69 extends craft\web\twig\Template
{
    private $source;

    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        // line 1
        echo "<div class=\"component-container\">
    <div class=\"text\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content\">
            <div class=\"row\">
                <div class=\"shift-2 undefined\">
                    ";
        // line 9
        echo twig_escape_filter($this->env, craft\helpers\Template::attribute($this->env, $this->getSourceContext(), (isset($context["component"]) || array_key_exists("component", $context) ? $context["component"] : (function () { throw new Twig_Error_Runtime('Variable "component" does not exist.', 9, $this->source); })()), "text", []), "html", null, true);
        echo "
                </div>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "_components/text/shifted.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  33 => 9,  23 => 1,);
    }

    public function getSourceContext()
    {
        return new Twig_Source("<div class=\"component-container\">
    <div class=\"text\">
        <div class=\"grid-bg-wrapper container\">
            <div class=\"background-grid\"></div>
        </div>
        <div class=\"container content\">
            <div class=\"row\">
                <div class=\"shift-2 undefined\">
                    {{ component.text }}
                </div>
            </div>
        </div>
    </div>
</div>", "_components/text/shifted.twig", "E:\\Code\\Craft\\metacell\\templates\\_components\\text\\shifted.twig");
    }
}
