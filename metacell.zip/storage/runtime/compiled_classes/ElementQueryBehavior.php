<?php // vsOKm7OZo3pJN
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

/**
 * Element Query behavior
 *
 * This class provides attributes for all the unique custom field handles.
 *
 * @method self address(mixed $value) Sets the [[address]] property
 * @method self addressLine1(mixed $value) Sets the [[addressLine1]] property
 * @method self addressLine2(mixed $value) Sets the [[addressLine2]] property
 * @method self bottomLinks(mixed $value) Sets the [[bottomLinks]] property
 * @method self button(mixed $value) Sets the [[button]] property
 * @method self country(mixed $value) Sets the [[country]] property
 * @method self description(mixed $value) Sets the [[description]] property
 * @method self downloadLink(mixed $value) Sets the [[downloadLink]] property
 * @method self email(mixed $value) Sets the [[email]] property
 * @method self heading(mixed $value) Sets the [[heading]] property
 * @method self headingColor1(mixed $value) Sets the [[headingColor1]] property
 * @method self headingColor2(mixed $value) Sets the [[headingColor2]] property
 * @method self image(mixed $value) Sets the [[image]] property
 * @method self items(mixed $value) Sets the [[items]] property
 * @method self layoutComponents(mixed $value) Sets the [[layoutComponents]] property
 * @method self linketin(mixed $value) Sets the [[linketin]] property
 * @method self links(mixed $value) Sets the [[links]] property
 * @method self linkTo(mixed $value) Sets the [[linkTo]] property
 * @method self logo(mixed $value) Sets the [[logo]] property
 * @method self offices(mixed $value) Sets the [[offices]] property
 * @method self partners(mixed $value) Sets the [[partners]] property
 * @method self phone(mixed $value) Sets the [[phone]] property
 * @method self resource(mixed $value) Sets the [[resource]] property
 * @method self resources(mixed $value) Sets the [[resources]] property
 * @method self subheading(mixed $value) Sets the [[subheading]] property
 * @method self team(mixed $value) Sets the [[team]] property
 * @method self template(mixed $value) Sets the [[template]] property
 * @method self text(mixed $value) Sets the [[text]] property
 * @method self videoLink(mixed $value) Sets the [[videoLink]] property
 */
class ElementQueryBehavior extends ContentBehavior
{
    // Public Methods
    // =========================================================================

    /**
     * @inheritdoc
     */
    public function __call($name, $params)
    {
        if (isset(self::$fieldHandles[$name]) && count($params) === 1) {
            $this->$name = $params[0];
            return $this->owner;
        }
        return parent::__call($name, $params);
    }

    /**
     * @inheritdoc
     */
    public function hasMethod($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::hasMethod($name);
    }
}
