<?php // vsOKm7OZo3pJN
/**
 * @link http://craftcms.com/
 * @copyright Copyright (c) Pixel & Tonic, Inc.
 * @license http://craftcms.com/license
 */

namespace craft\behaviors;

use yii\base\Behavior;

/**
 * Content behavior
 *
 * This class provides attributes for all the unique custom field handles.
 */
class ContentBehavior extends Behavior
{
    // Static
    // =========================================================================

    /**
     * @var string[] List of supported field handles.
     */
    public static $fieldHandles = [
        'address' => true,
        'addressLine1' => true,
        'addressLine2' => true,
        'bottomLinks' => true,
        'button' => true,
        'country' => true,
        'description' => true,
        'downloadLink' => true,
        'email' => true,
        'heading' => true,
        'headingColor1' => true,
        'headingColor2' => true,
        'image' => true,
        'items' => true,
        'layoutComponents' => true,
        'linketin' => true,
        'links' => true,
        'linkTo' => true,
        'logo' => true,
        'offices' => true,
        'partners' => true,
        'phone' => true,
        'resource' => true,
        'resources' => true,
        'subheading' => true,
        'team' => true,
        'template' => true,
        'text' => true,
        'videoLink' => true,
    ];

    // Properties
    // =========================================================================

    /**
     * @var mixed Value for field with the handle “address”.
     */
    public $address;

    /**
     * @var mixed Value for field with the handle “addressLine1”.
     */
    public $addressLine1;

    /**
     * @var mixed Value for field with the handle “addressLine2”.
     */
    public $addressLine2;

    /**
     * @var mixed Value for field with the handle “bottomLinks”.
     */
    public $bottomLinks;

    /**
     * @var mixed Value for field with the handle “button”.
     */
    public $button;

    /**
     * @var mixed Value for field with the handle “country”.
     */
    public $country;

    /**
     * @var mixed Value for field with the handle “description”.
     */
    public $description;

    /**
     * @var mixed Value for field with the handle “downloadLink”.
     */
    public $downloadLink;

    /**
     * @var mixed Value for field with the handle “email”.
     */
    public $email;

    /**
     * @var mixed Value for field with the handle “heading”.
     */
    public $heading;

    /**
     * @var mixed Value for field with the handle “headingColor1”.
     */
    public $headingColor1;

    /**
     * @var mixed Value for field with the handle “headingColor2”.
     */
    public $headingColor2;

    /**
     * @var mixed Value for field with the handle “image”.
     */
    public $image;

    /**
     * @var mixed Value for field with the handle “items”.
     */
    public $items;

    /**
     * @var mixed Value for field with the handle “layoutComponents”.
     */
    public $layoutComponents;

    /**
     * @var mixed Value for field with the handle “linketin”.
     */
    public $linketin;

    /**
     * @var mixed Value for field with the handle “links”.
     */
    public $links;

    /**
     * @var mixed Value for field with the handle “linkTo”.
     */
    public $linkTo;

    /**
     * @var mixed Value for field with the handle “logo”.
     */
    public $logo;

    /**
     * @var mixed Value for field with the handle “offices”.
     */
    public $offices;

    /**
     * @var mixed Value for field with the handle “partners”.
     */
    public $partners;

    /**
     * @var mixed Value for field with the handle “phone”.
     */
    public $phone;

    /**
     * @var mixed Value for field with the handle “resource”.
     */
    public $resource;

    /**
     * @var mixed Value for field with the handle “resources”.
     */
    public $resources;

    /**
     * @var mixed Value for field with the handle “subheading”.
     */
    public $subheading;

    /**
     * @var mixed Value for field with the handle “team”.
     */
    public $team;

    /**
     * @var mixed Value for field with the handle “template”.
     */
    public $template;

    /**
     * @var mixed Value for field with the handle “text”.
     */
    public $text;

    /**
     * @var mixed Value for field with the handle “videoLink”.
     */
    public $videoLink;

    /**
     * @var array Additional custom field values we don’t know about yet.
     */
    private $_customFieldValues = [];

    // Magic Property Methods
    // =========================================================================

    /**
     * @inheritdoc
     */
    public function __isset($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::__isset($name);
    }

    /**
     * @inheritdoc
     */
    public function __get($name)
    {
        if (isset(self::$fieldHandles[$name])) {
            return $this->_customFieldValues[$name] ?? null;
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        if (isset(self::$fieldHandles[$name])) {
            $this->_customFieldValues[$name] = $value;
            return;
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public function canGetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canGetProperty($name, $checkVars);
    }

    /**
     * @inheritdoc
     */
    public function canSetProperty($name, $checkVars = true)
    {
        if ($checkVars && isset(self::$fieldHandles[$name])) {
            return true;
        }
        return parent::canSetProperty($name, $checkVars);
    }
}
